"""
DuckDuckGo 검색 기반 AI Agent
LangChain v1.0 create_agent 사용
검색 결과만 RAG로 활용하여 답변
"""
from langchain.agents import create_agent
from langchain_openai import ChatOpenAI
from typing import Dict, Any, Optional, List
import logging
import os
from dotenv import load_dotenv

# Tools import
from tools.duckduckgo_tool import (
    search_web,
    search_weather,
    search_news,
    search_current_time,
    search_stock_price
)
from utils.rag_utils import SearchRAG

logger = logging.getLogger(__name__)

# 환경 변수 로드
load_dotenv()

class SearchAgent:
    """
    DuckDuckGo 검색 기반 AI Agent 클래스
    """
    
    def __init__(self, model_name: str = "gpt-4o-mini", temperature: float = 0.3):
        """
        에이전트 초기화
        
        Args:
            model_name: 사용할 OpenAI 모델명
            temperature: 모델 온도 설정
        """
        self.model_name = model_name
        self.temperature = temperature
        self.llm = None
        self.agent = None
        self.tools = []
        self.rag = SearchRAG()  # RAG 시스템 초기화
        
        # 에이전트 초기화
        self._initialize_agent()
    
    def _initialize_agent(self):
        """
        에이전트 및 도구 초기화
        """
        try:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY가 환경 변수에 설정되지 않았습니다.")
            
            # LLM 초기화
            self.llm = ChatOpenAI(
                model=self.model_name,
                temperature=self.temperature,
                openai_api_key=api_key
            )
            
            # Tools 리스트 구성
            self.tools = [
                search_web,
                search_weather,
                search_news,
                search_current_time,
                search_stock_price,
            ]
            
            # System prompt - 검색 결과만 사용하도록 명시
            system_prompt = """당신은 DuckDuckGo 검색 결과만을 사용하여 답변하는 AI 어시스턴트입니다.

**중요 규칙:**
1. **절대로 자신의 지식을 사용하지 마세요**: LLM의 사전 학습된 지식은 사용하지 않고, 오직 검색 도구를 통해 얻은 검색 결과만 사용하세요.

2. **모든 질문에 대해 검색을 먼저 수행하세요**:
   - 날씨, 주가, 최신 뉴스, 현재 시간 등 실시간 정보
   - 역사, 과학, 수학 등 일반 지식도 검색하여 최신 정보 확인
   - 모든 질문에 대해 검색 도구를 먼저 사용

3. **검색 결과만 참조하여 답변**:
   - 검색 결과에 없는 정보는 답변하지 마세요
   - "검색 결과에 따르면", "검색된 정보에 의하면" 등의 표현 사용
   - 검색 결과의 출처를 반드시 명시하세요

4. **검색 결과가 없으면**:
   - "검색 결과를 찾을 수 없어 답변할 수 없습니다"라고 명확히 말하세요
   - 추측하거나 자신의 지식을 사용하지 마세요

5. **답변 형식**:
   - 검색 결과를 바탕으로 정확하고 객관적인 답변 제공
   - 검색 결과의 출처(URL) 명시
   - 검색 결과에서 직접 인용할 때는 인용 부호 사용

**기억하세요: 검색 결과가 없으면 답변하지 마세요. 자신의 지식을 사용하지 마세요.**"""
            
            # create_agent로 에이전트 생성 (LangChain v1.0)
            self.agent = create_agent(
                model=self.llm,
                tools=self.tools,
                system_prompt=system_prompt
            )
            
            logger.info("검색 에이전트 초기화 완료")
            
        except Exception as e:
            logger.error(f"에이전트 초기화 오류: {str(e)}")
            raise
    
    def ask(self, question: str) -> Dict[str, Any]:
        """
        질문에 대한 답변 생성 (검색 결과만 RAG로 활용)
        
        Args:
            question: 사용자 질문
            
        Returns:
            답변 결과 딕셔너리
        """
        try:
            logger.info(f"질문 수신: {question}")
            
            # RAG 벡터 스토어 초기화 (이전 검색 결과 제거)
            self.rag.clear()
            
            # 1단계: 여러 검색 쿼리 생성 (3개 정도)
            search_queries = self._generate_search_queries(question)
            
            # 2단계: 각 검색 쿼리로 검색 수행
            all_search_results = []
            for i, search_query in enumerate(search_queries[:3], 1):  # 최대 3개 검색
                logger.info(f"검색 {i}/{min(len(search_queries), 3)}: {search_query}")
                search_result = self._execute_search(search_query, question)
                
                if search_result and "검색 결과가 없습니다" not in search_result:
                    all_search_results.append(search_result)
                    # 각 검색 결과를 RAG에 추가
                    self.rag.add_search_results(search_result, search_query)
            
            if not all_search_results:
                return {
                    "question": question,
                    "answer": "죄송합니다. 검색 결과를 찾을 수 없어 답변할 수 없습니다. 다른 검색어로 시도해주세요.",
                    "status": "no_results",
                    "search_result": "검색 결과 없음"
                }
            
            # 모든 검색 결과 통합
            combined_search_result = "\n\n---\n\n".join(all_search_results)
            
            # 3단계: RAG를 통해 검색 결과만 참조하여 답변 생성
            # 여러 검색 결과를 사용하므로 더 많은 컨텍스트 가져오기
            context = self.rag.search_relevant_context(question, k=5)
            
            # 4단계: 검색 결과만 사용하여 답변 생성
            prompt = f"""다음 검색 결과만을 사용하여 사용자의 질문에 답변하세요.

**중요**: 
- 검색 결과에 없는 정보는 절대 답변하지 마세요
- 자신의 지식이나 추측을 사용하지 마세요
- 검색 결과만 참조하여 답변하세요

=== 검색 결과 ===
{context}

=== 사용자 질문 ===
{question}

=== 답변 ===
검색 결과에 따르면:"""

            messages = [
                {"role": "user", "content": prompt}
            ]
            
            result = self.agent.invoke({"messages": messages})
            
            # 결과 추출
            if isinstance(result, dict):
                if "messages" in result:
                    last_message = result["messages"][-1]
                    answer = last_message.content if hasattr(last_message, 'content') else str(last_message)
                else:
                    answer = str(result)
            else:
                answer = str(result)
            
            # 검색 결과 정보 추가
            answer_with_source = f"{answer}\n\n---\n*위 답변은 DuckDuckGo 검색 결과를 기반으로 작성되었습니다.*"
            
            logger.info("답변 생성 완료 (RAG 기반)")
            
            return {
                "question": question,
                "answer": answer_with_source,
                "search_result": combined_search_result,
                "search_count": len(all_search_results),
                "status": "success"
            }
            
        except Exception as e:
            error_msg = f"답변 생성 중 오류 발생: {str(e)}"
            logger.error(error_msg)
            return {
                "question": question,
                "answer": error_msg,
                "status": "error"
            }
    
    def _generate_search_queries(self, question: str) -> List[str]:
        """
        질문을 분석하여 여러 검색 쿼리 생성 (3개 정도)
        
        Args:
            question: 사용자 질문
            
        Returns:
            검색 쿼리 리스트
        """
        queries = []
        
        # 1. 원본 질문
        queries.append(question)
        
        # 2. 질문에서 핵심 키워드 추출하여 검색 쿼리 생성
        # 간단한 키워드 추출 (한글/영문 단어)
        import re
        words = re.findall(r'\b\w+\b', question)
        if len(words) > 2:
            # 핵심 키워드만으로 검색 쿼리 생성
            key_query = " ".join(words[:3])  # 처음 3개 단어
            if key_query != question:
                queries.append(key_query)
        
        # 3. 질문을 변형한 검색 쿼리
        # "무엇", "어떻게", "왜" 등의 질문어 제거하고 검색
        question_variants = [
            question.replace("무엇", "").replace("뭐", "").replace("what", "").strip(),
            question.replace("어떻게", "").replace("how", "").strip(),
            question.replace("왜", "").replace("why", "").strip(),
        ]
        
        for variant in question_variants:
            if variant and variant != question and len(variant) > 3:
                queries.append(variant)
                if len(queries) >= 3:
                    break
        
        # 중복 제거 및 최대 3개 반환
        unique_queries = []
        seen = set()
        for q in queries:
            if q not in seen and len(q.strip()) > 0:
                unique_queries.append(q)
                seen.add(q)
                if len(unique_queries) >= 3:
                    break
        
        logger.info(f"생성된 검색 쿼리 ({len(unique_queries)}개): {unique_queries}")
        return unique_queries
    
    def _execute_search(self, search_query: str, original_question: str) -> str:
        """
        검색 실행
        
        Args:
            search_query: 검색 쿼리
            original_question: 원본 질문
            
        Returns:
            검색 결과 문자열
        """
        try:
            # 질문 유형에 따라 적절한 검색 도구 선택
            question_lower = original_question.lower()
            
            if any(keyword in question_lower for keyword in ["날씨", "weather"]):
                # 날씨 검색
                location = original_question.replace("날씨", "").replace("weather", "").strip()
                return search_weather.invoke({"location": location})
            
            elif any(keyword in question_lower for keyword in ["주가", "stock", "주식"]):
                # 주가 검색
                ticker = self._extract_ticker(original_question)
                if ticker:
                    return search_stock_price.invoke({"ticker": ticker})
            
            elif any(keyword in question_lower for keyword in ["뉴스", "news"]):
                # 뉴스 검색
                return search_news.invoke({"query": search_query, "max_results": 5})
            
            elif any(keyword in question_lower for keyword in ["시간", "time", "현재", "지금"]):
                # 시간 검색
                location = None
                if "뉴욕" in original_question or "new york" in question_lower:
                    location = "뉴욕"
                elif "런던" in original_question or "london" in question_lower:
                    location = "런던"
                return search_current_time.invoke({"location": location})
            
            else:
                # 일반 웹 검색 (더 많은 결과 수집)
                return search_web.invoke({"query": search_query, "max_results": 8})
                
        except Exception as e:
            logger.error(f"검색 실행 오류: {str(e)}")
            return f"검색 중 오류 발생: {str(e)}"
    
    def _extract_ticker(self, question: str) -> Optional[str]:
        """
        질문에서 주식 티커 추출
        
        Args:
            question: 사용자 질문
            
        Returns:
            티커 심볼 또는 None
        """
        # 간단한 티커 추출 로직
        import re
        
        # 대문자 알파벳 2-5자 패턴 (예: AAPL, TSLA)
        ticker_pattern = r'\b[A-Z]{2,5}\b'
        matches = re.findall(ticker_pattern, question.upper())
        if matches:
            return matches[0]
        
        # 한글 회사명 매핑
        company_map = {
            "애플": "AAPL",
            "apple": "AAPL",
            "테슬라": "TSLA",
            "tesla": "TSLA",
            "마이크로소프트": "MSFT",
            "microsoft": "MSFT",
            "구글": "GOOGL",
            "google": "GOOGL",
            "삼성": "005930",
            "삼성전자": "005930"
        }
        
        for company, ticker in company_map.items():
            if company in question.lower():
                return ticker
        
        return None
    
    def is_search_needed(self, question: str) -> bool:
        """
        질문이 검색이 필요한지 판단
        
        Args:
            question: 사용자 질문
            
        Returns:
            검색 필요 여부
        """
        search_keywords = [
            "날씨", "weather",
            "주가", "stock", "주식",
            "뉴스", "news",
            "현재", "지금", "now", "current",
            "최신", "latest", "recent",
            "오늘", "today",
            "어제", "yesterday",
            "내일", "tomorrow",
            "환율", "exchange rate",
            "시간", "time"
        ]
        
        question_lower = question.lower()
        return any(keyword in question_lower for keyword in search_keywords)
