"""
DuckDuckGo 검색 Tool
날씨, 실시간 정보, LLM이 답할 수 없는 질문에 대한 검색 기능
"""
from langchain.tools import tool
try:
    from ddgs import DDGS
except ImportError:
    # 이전 버전 호환성
    try:
        from duckduckgo_search import DDGS
    except ImportError:
        raise ImportError("ddgs 패키지를 설치해주세요: pip install ddgs")
from typing import List, Dict, Optional
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def _execute_search(query: str, max_results: int = 5, search_type: str = "text"):
    """
    DDGS 검색 실행 헬퍼 함수
    
    Args:
        query: 검색 쿼리
        max_results: 최대 결과 수
        search_type: 검색 유형 ("text" 또는 "news")
        
    Returns:
        검색 결과 리스트
    """
    try:
        ddgs = DDGS()
        
        if search_type == "news":
            # 뉴스 검색
            try:
                results = list(ddgs.news(keywords=query, max_results=max_results))
            except Exception:
                # ddgs 패키지의 경우 다른 방식 시도
                results = []
                for result in ddgs.news(keywords=query, max_results=max_results):
                    results.append(result)
        else:
            # 일반 텍스트 검색
            try:
                results = list(ddgs.text(query, max_results=max_results))
            except Exception:
                # ddgs 패키지의 경우 다른 방식 시도
                results = []
                for result in ddgs.text(query, max_results=max_results):
                    results.append(result)
        
        return results
    except Exception as e:
        logger.error(f"검색 실행 오류: {str(e)}")
        return []

@tool
def search_web(query: str, max_results: int = 5) -> str:
    """
    DuckDuckGo를 사용하여 웹 검색을 수행합니다.
    날씨, 뉴스, 실시간 정보 등 LLM이 답변할 수 없는 질문에 사용합니다.
    
    Args:
        query: 검색할 질문이나 키워드
        max_results: 최대 결과 수 (기본값: 5)
        
    Returns:
        검색 결과 요약 문자열
    """
    try:
        logger.info(f"웹 검색 시작: {query}")
        
        results = _execute_search(query, max_results, "text")
        
        if not results:
            return f"'{query}'에 대한 검색 결과가 없습니다."
        
        # 결과 포맷팅
        search_summary = f"=== 검색 결과: '{query}' ({len(results)}건) ===\n\n"
        
        for i, result in enumerate(results, 1):
            # 검색 결과 구조 확인 (디버깅용)
            logger.debug(f"검색 결과 {i} 구조: {result}")
            
            title = result.get('title', '제목 없음')
            snippet = result.get('body', '내용 없음')
            # URL은 여러 키에서 시도
            url = result.get('href', '') or result.get('url', '') or result.get('link', '')
            
            search_summary += f"[{i}] {title}\n"
            search_summary += f"    📄 내용: {snippet[:300]}...\n"
            if url:
                search_summary += f"    🔗 사이트: {url}\n"
            else:
                # URL이 없으면 사용 가능한 키 확인
                available_keys = list(result.keys())
                search_summary += f"    ⚠️ URL 정보 없음 (사용 가능한 키: {available_keys})\n"
            search_summary += "\n"
        
        logger.info(f"웹 검색 완료: {len(results)}건")
        return search_summary
        
    except Exception as e:
        error_msg = f"웹 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

@tool
def search_weather(location: str) -> str:
    """
    특정 지역의 날씨 정보를 검색합니다.
    
    Args:
        location: 지역명 (예: "서울 날씨", "New York weather")
        
    Returns:
        날씨 정보 문자열
    """
    try:
        logger.info(f"날씨 검색 시작: {location}")
        
        # 날씨 검색 쿼리 구성
        if "날씨" not in location and "weather" not in location.lower():
            query = f"{location} 날씨"
        else:
            query = location
        
        results = _execute_search(query, max_results=3, search_type="text")
        
        if not results:
            return f"'{location}'의 날씨 정보를 찾을 수 없습니다."
        
        # 날씨 정보 포맷팅
        weather_info = f"=== {location} 날씨 정보 ===\n\n"
        
        for i, result in enumerate(results, 1):
            title = result.get('title', '')
            snippet = result.get('body', '')
            url = result.get('href', '') or result.get('url', '') or result.get('link', '')
            
            weather_info += f"[{i}] {title}\n"
            weather_info += f"    📄 내용: {snippet}\n"
            if url:
                weather_info += f"    🔗 사이트: {url}\n"
            weather_info += "\n"
        
        logger.info(f"날씨 검색 완료: {location}")
        return weather_info
        
    except Exception as e:
        error_msg = f"날씨 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

@tool
def search_news(query: str, max_results: int = 5) -> str:
    """
    최신 뉴스를 검색합니다.
    
    Args:
        query: 검색할 뉴스 키워드
        max_results: 최대 결과 수
        
    Returns:
        뉴스 검색 결과 문자열
    """
    try:
        logger.info(f"뉴스 검색 시작: {query}")
        
        news_results = _execute_search(query, max_results, search_type="news")
        
        if not news_results:
            return f"'{query}'에 대한 뉴스 검색 결과가 없습니다."
        
        news_summary = f"=== 최신 뉴스: '{query}' ({len(news_results)}건) ===\n\n"
        
        for i, news in enumerate(news_results, 1):
            title = news.get('title', '제목 없음')
            body = news.get('body', '내용 없음')
            url = news.get('url', '') or news.get('href', '') or news.get('link', '')
            date = news.get('date', '')
            
            news_summary += f"[{i}] {title}\n"
            if date:
                news_summary += f"    📅 날짜: {date}\n"
            news_summary += f"    📄 내용: {body[:250]}...\n"
            if url:
                news_summary += f"    🔗 사이트: {url}\n"
            else:
                news_summary += f"    ⚠️ URL 정보 없음\n"
            news_summary += "\n"
        
        logger.info(f"뉴스 검색 완료: {len(news_results)}건")
        return news_summary
        
    except Exception as e:
        error_msg = f"뉴스 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

@tool
def search_current_time(location: Optional[str] = None) -> str:
    """
    현재 시간 정보를 반환합니다.
    
    Args:
        location: 지역명 (선택, 기본값: 시스템 시간)
        
    Returns:
        현재 시간 정보 문자열
    """
    try:
        current_time = datetime.now()
        
        if location:
            # 특정 지역의 시간 검색
            query = f"{location} 현재 시간"
            results = _execute_search(query, max_results=2, search_type="text")
            
            time_info = f"=== {location} 현재 시간 ===\n\n"
            if results:
                time_info += f"{results[0].get('body', '')}\n\n"
            time_info += f"시스템 시간: {current_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        else:
            time_info = f"=== 현재 시간 ===\n\n"
            time_info += f"{current_time.strftime('%Y년 %m월 %d일 %H시 %M분 %S초')}\n"
            time_info += f"({current_time.strftime('%A')})\n"
        
        return time_info
        
    except Exception as e:
        error_msg = f"시간 조회 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg

@tool
def search_stock_price(ticker: str) -> str:
    """
    주식 가격 정보를 검색합니다.
    
    Args:
        ticker: 주식 티커 심볼 (예: AAPL, TSLA, 005930)
        
    Returns:
        주식 가격 정보 문자열
    """
    try:
        logger.info(f"주식 가격 검색 시작: {ticker}")
        
        query = f"{ticker} 주가 stock price"
        results = _execute_search(query, max_results=3, search_type="text")
        
        if not results:
            return f"'{ticker}'의 주가 정보를 찾을 수 없습니다."
        
        stock_info = f"=== {ticker} 주가 정보 ===\n\n"
        
        for i, result in enumerate(results, 1):
            title = result.get('title', '')
            snippet = result.get('body', '')
            url = result.get('href', '') or result.get('url', '') or result.get('link', '')
            
            stock_info += f"[{i}] {title}\n"
            stock_info += f"    📄 내용: {snippet[:300]}...\n"
            if url:
                stock_info += f"    🔗 사이트: {url}\n"
            stock_info += "\n"
        
        logger.info(f"주식 가격 검색 완료: {ticker}")
        return stock_info
        
    except Exception as e:
        error_msg = f"주식 가격 검색 중 오류 발생: {str(e)}"
        logger.error(error_msg)
        return error_msg
