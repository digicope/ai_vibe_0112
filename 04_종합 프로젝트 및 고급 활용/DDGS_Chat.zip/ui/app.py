"""
Streamlit UI - DuckDuckGo 검색 기반 AI Agent
"""
import streamlit as st
import sys
from pathlib import Path
import logging
from datetime import datetime

# 프로젝트 루트 경로 추가
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from agent.search_agent import SearchAgent
from utils.logger import setup_logger

# 로거 설정
logger = setup_logger("streamlit_app")

# 페이지 설정
st.set_page_config(
    page_title="DuckDuckGo 검색 AI Agent",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 세션 상태 초기화
if 'agent' not in st.session_state:
    st.session_state.agent = None
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

def initialize_agent():
    """에이전트 초기화"""
    if st.session_state.agent is None:
        with st.spinner("AI 에이전트 초기화 중..."):
            try:
                st.session_state.agent = SearchAgent()
                return True
            except Exception as e:
                st.error(f"에이전트 초기화 실패: {str(e)}")
                return False
    return True

def main():
    """메인 UI"""
    
    # 헤더
    st.title("🔍 DuckDuckGo 검색 AI Agent")
    st.markdown("**실시간 정보 검색 및 답변 AI 어시스턴트**")
    st.markdown("---")
    
    # 사이드바
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # API 키 확인
        import os
        from dotenv import load_dotenv
        load_dotenv()
        
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            st.error("⚠️ OpenAI API 키가 설정되지 않았습니다.")
            st.info("`.env` 파일에 `OPENAI_API_KEY`를 설정해주세요.")
            st.stop()
        else:
            st.success("✅ API 키 설정 완료")
        
        st.markdown("---")
        st.markdown("### 📖 사용 방법")
        st.markdown("""
        1. 질문을 입력하세요
        2. 실시간 정보가 필요한 질문:
           - 날씨 (예: "서울 날씨")
           - 주가 (예: "AAPL 주가")
           - 뉴스 (예: "최신 AI 뉴스")
           - 현재 시간
        3. AI가 자동으로 검색하여 답변합니다
        """)
        
        st.markdown("---")
        st.markdown("### 💡 예시 질문")
        st.markdown("""
        - "서울 오늘 날씨는 어때?"
        - "애플 주가 알려줘"
        - "최신 AI 뉴스 보여줘"
        - "지금 몇 시야?"
        - "오늘 환율은?"
        """)
        
        # 채팅 기록 초기화
        if st.button("🗑️ 채팅 기록 지우기", use_container_width=True):
            st.session_state.chat_history = []
            st.rerun()
    
    # 메인 영역
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.header("💬 질문하기")
        
        # 채팅 기록 표시
        if st.session_state.chat_history:
            st.subheader("📜 대화 기록")
            for i, chat in enumerate(st.session_state.chat_history):
                with st.expander(f"질문 {i+1}: {chat['question'][:50]}...", expanded=False):
                    st.markdown(f"**질문:** {chat['question']}")
                    st.markdown(f"**답변:** {chat['answer']}")
                    st.markdown(f"*시간: {chat['timestamp']}*")
        
        # 질문 입력 폼
        with st.form("question_form", clear_on_submit=True):
            question = st.text_area(
                "질문을 입력하세요",
                placeholder="예: 서울 오늘 날씨는 어때?",
                height=100,
                help="날씨, 주가, 뉴스, 실시간 정보 등에 대해 질문하세요"
            )
            
            col_btn1, col_btn2 = st.columns([1, 4])
            with col_btn1:
                submitted = st.form_submit_button("🚀 질문하기", use_container_width=True)
    
    with col2:
        st.header("📊 빠른 검색")
        
        quick_questions = [
            "서울 날씨",
            "뉴욕 날씨",
            "AAPL 주가",
            "최신 AI 뉴스",
            "현재 시간",
            "오늘 환율"
        ]
        
        for q in quick_questions:
            if st.button(q, key=f"quick_{q}", use_container_width=True):
                question = q
                submitted = True
                break
    
    # 질문 처리
    if submitted and question:
        if not question.strip():
            st.warning("⚠️ 질문을 입력해주세요.")
        else:
            # 에이전트 초기화
            if not initialize_agent():
                st.stop()
            
            # 답변 생성
            with st.spinner("🔍 검색 및 답변 생성 중..."):
                try:
                    result = st.session_state.agent.ask(question)
                    
                    if result["status"] == "success":
                        # 채팅 기록에 추가
                        st.session_state.chat_history.append({
                            "question": question,
                            "answer": result["answer"],
                            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        })
                        
                        # 답변 표시
                        st.markdown("---")
                        st.subheader("💡 답변")
                        st.markdown(result["answer"])
                        
                        # 검색 필요 여부 표시
                        if st.session_state.agent.is_search_needed(question):
                            st.info("ℹ️ 이 질문은 DuckDuckGo 검색을 통해 실시간 정보를 가져왔습니다.")
                        
                        st.success("✅ 답변 완료!")
                    else:
                        st.error(f"❌ 오류: {result['answer']}")
                        
                except Exception as e:
                    st.error(f"❌ 오류 발생: {str(e)}")
                    logger.error(f"질문 처리 오류: {str(e)}")
    
    # 하단 정보
    st.markdown("---")
    st.markdown("""
    ### ℹ️ 안내
    - 이 AI Agent는 DuckDuckGo 검색을 활용하여 실시간 정보를 제공합니다
    - 날씨, 주가, 뉴스 등 최신 정보가 필요한 질문에 적합합니다
    - 일반 지식 질문도 답변할 수 있지만, 최신 정보가 필요하면 자동으로 검색합니다
    
    ### 🔧 기술 스택
    - **LLM**: OpenAI GPT-4o-mini
    - **검색**: DuckDuckGo Search
    - **프레임워크**: LangChain v1.0
    - **UI**: Streamlit
    """)

if __name__ == "__main__":
    main()
