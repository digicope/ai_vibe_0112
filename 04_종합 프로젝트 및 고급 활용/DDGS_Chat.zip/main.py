"""
메인 실행 파일 - DuckDuckGo 검색 AI Agent
"""
from agent.search_agent import SearchAgent
from utils.logger import setup_logger
import logging

logger = setup_logger("main")

def main():
    """
    메인 실행 함수
    """
    logger.info("DuckDuckGo 검색 AI Agent 시작")
    
    try:
        # 에이전트 초기화
        agent = SearchAgent()
        
        # 환영 메시지
        print("\n" + "="*60)
        print("🔍 DuckDuckGo 검색 AI Agent")
        print("="*60)
        print("\n실시간 정보 검색 및 답변 AI 어시스턴트입니다.")
        print("날씨, 주가, 뉴스 등 최신 정보를 검색하여 답변합니다.")
        print("\n종료하려면 'quit', 'exit', '종료'를 입력하세요.\n")
        
        while True:
            # 질문 입력
            question = input("\n질문: ").strip()
            
            if not question:
                continue
            
            # 종료 명령
            if question.lower() in ['quit', 'exit', '종료', 'q']:
                print("\n👋 안녕히 가세요!")
                break
            
            # 답변 생성
            print("\n🔍 검색 및 답변 생성 중...\n")
            result = agent.ask(question)
            
            if result["status"] == "success":
                print("="*60)
                print("답변:")
                print("="*60)
                print(result["answer"])
                print("="*60)
                
                # 검색 필요 여부 표시
                if agent.is_search_needed(question):
                    print("\nℹ️ 이 질문은 DuckDuckGo 검색을 통해 실시간 정보를 가져왔습니다.")
            else:
                print(f"❌ 오류: {result['answer']}")
        
    except KeyboardInterrupt:
        print("\n\n👋 프로그램을 종료합니다.")
    except Exception as e:
        logger.error(f"실행 중 오류 발생: {str(e)}")
        print(f"오류 발생: {str(e)}")

if __name__ == "__main__":
    main()
