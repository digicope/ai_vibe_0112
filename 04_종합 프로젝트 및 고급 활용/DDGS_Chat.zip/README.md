# 🔍 DuckDuckGo 검색 AI Agent

DuckDuckGo 검색을 활용하여 실시간 정보를 검색하고 답변하는 AI Agent입니다.

## 📋 프로젝트 개요

이 프로젝트는 LangChain v1.0과 OpenAI API를 사용하여, LLM이 답변할 수 없는 실시간 정보(날씨, 주가, 뉴스 등)를 DuckDuckGo 검색으로 찾아 **RAG(Retrieval-Augmented Generation) 방식으로만 답변**하는 AI Agent를 구현합니다.

**중요 특징**: LLM이 자신의 사전 학습된 지식을 사용하지 않고, **오직 검색 결과만을 RAG로 활용하여 답변**합니다.

## ✨ 주요 기능

### 1. 실시간 정보 검색
- **날씨 정보**: 특정 지역의 현재 날씨 검색
- **주가 정보**: 주식 티커의 현재 주가 검색
- **뉴스 검색**: 최신 뉴스 검색 및 요약
- **현재 시간**: 지역별 현재 시간 정보
- **일반 웹 검색**: 다양한 실시간 정보 검색

### 2. RAG 기반 답변 생성
- 검색 결과를 벡터 DB(Chroma)에 저장
- 검색 결과만 참조하여 답변 생성
- LLM의 사전 학습 지식은 사용하지 않음

### 3. 자동 검색 판단
- 질문 내용을 분석하여 적절한 검색 도구 자동 선택
- 모든 질문에 대해 검색을 먼저 수행

### 3. 사용자 인터페이스
- **Streamlit UI**: 웹 기반 대화형 인터페이스
- **CLI 모드**: 터미널에서 대화형으로 사용

## 🚀 시작하기

### 1. 설치

```bash
# 프로젝트 디렉토리로 이동
cd DDGS_Chat

# 가상 환경 생성 (권장)
python -m venv venv

# 가상 환경 활성화
# Windows
venv\Scripts\activate
# Linux/Mac
source venv/bin/activate

# 패키지 설치
pip install -r requirements.txt
```

### 2. 환경 변수 설정

프로젝트 루트 디렉토리에 `.env` 파일을 생성하고 OpenAI API 키를 설정합니다:

```bash
OPENAI_API_KEY=your_openai_api_key_here
```

### 3. 실행

#### Streamlit UI (권장)

```bash
streamlit run ui/app.py
```

브라우저에서 `http://localhost:8501`로 접속합니다.

#### CLI 모드

```bash
python main.py
```

## 📁 프로젝트 구조

```
DDGS_Chat/
├── agent/
│   ├── __init__.py
│   └── search_agent.py          # LangChain v1.0 기반 검색 에이전트
├── tools/
│   ├── __init__.py
│   └── duckduckgo_tool.py       # DuckDuckGo 검색 Tool들
├── utils/
│   ├── __init__.py
│   └── logger.py                # 로깅 유틸리티
├── ui/
│   ├── __init__.py
│   └── app.py                   # Streamlit UI
├── main.py                      # CLI 실행 파일
├── requirements.txt             # 패키지 의존성
└── README.md                    # 프로젝트 문서
```

## 💡 사용 예시

### 날씨 검색
```
질문: 서울 오늘 날씨는 어때?
```

### 주가 검색
```
질문: 애플 주가 알려줘
질문: AAPL 현재 주가는?
```

### 뉴스 검색
```
질문: 최신 AI 뉴스 보여줘
질문: 오늘 경제 뉴스
```

### 현재 시간
```
질문: 지금 몇 시야?
질문: 뉴욕 현재 시간
```

### 일반 검색
```
질문: 오늘 환율은?
질문: 최신 기술 트렌드
```

## 🔧 기술 스택

- **LLM**: OpenAI GPT-4o-mini
- **검색 엔진**: DuckDuckGo Search
- **프레임워크**: LangChain v1.0
- **UI**: Streamlit
- **언어**: Python 3.8+

## 🛠️ 주요 컴포넌트

### 1. SearchAgent
- LangChain v1.0의 `create_agent()` 사용
- 여러 검색 도구를 통합 관리
- 질문 분석 및 적절한 도구 선택
- **검색 결과만 RAG로 활용하여 답변**

### 2. SearchRAG (utils/rag_utils.py)
- 검색 결과를 Chroma 벡터 DB에 저장
- 유사도 검색을 통한 관련 컨텍스트 추출
- 검색 결과만 참조하여 답변 생성

### 3. DuckDuckGo Tools
- `search_web`: 일반 웹 검색
- `search_weather`: 날씨 정보 검색
- `search_news`: 뉴스 검색
- `search_current_time`: 현재 시간 조회
- `search_stock_price`: 주가 정보 검색

### 4. Streamlit UI
- 대화형 웹 인터페이스
- 채팅 기록 관리
- 빠른 검색 버튼

## 📝 특징

1. **RAG 기반 답변**: 검색 결과만을 벡터 DB에 저장하고 참조하여 답변
2. **LLM 지식 사용 안 함**: 사전 학습된 지식은 사용하지 않고 검색 결과만 사용
3. **실시간 정보**: 날씨, 주가, 뉴스 등 최신 정보 제공
4. **다양한 검색 도구**: 목적에 맞는 검색 도구 자동 선택
5. **사용자 친화적 UI**: Streamlit 기반 직관적인 인터페이스

## 🔄 작동 방식

1. **질문 수신**: 사용자 질문을 받습니다
2. **검색 수행**: DuckDuckGo로 검색을 수행합니다
3. **RAG 저장**: 검색 결과를 Chroma 벡터 DB에 저장합니다
4. **컨텍스트 검색**: 질문과 관련된 검색 결과를 유사도 검색으로 추출합니다
5. **답변 생성**: 검색 결과만 참조하여 답변을 생성합니다 (LLM 지식 사용 안 함)

## ⚠️ 주의사항

1. **API 키 보안**: `.env` 파일은 Git에 커밋하지 마세요
2. **검색 제한**: DuckDuckGo 검색은 무료이지만 과도한 요청 시 제한될 수 있습니다
3. **정보 정확성**: 검색 결과는 참고용이며, 중요한 결정은 공식 출처를 확인하세요

## 🤝 기여

버그 리포트 및 기능 제안은 이슈로 등록해주세요.

## 📄 라이선스

이 프로젝트는 교육용 목적으로 제작되었습니다.

---

**만든이**: AI Agent Development Team  
**마지막 업데이트**: 2024년
