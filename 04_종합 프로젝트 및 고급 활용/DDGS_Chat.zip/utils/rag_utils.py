"""
RAG 유틸리티 - 검색 결과를 벡터 DB에 저장하고 검색
"""
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    try:
        from langchain.text_splitter import RecursiveCharacterTextSplitter
    except ImportError:
        from langchain_core.text_splitter import RecursiveCharacterTextSplitter

# Document import - LangChain v1.0 경로
try:
    from langchain_core.documents import Document
except ImportError:
    try:
        from langchain.schema import Document
    except ImportError:
        from langchain.documents import Document
from typing import List, Optional
import logging
import os
from dotenv import load_dotenv

logger = logging.getLogger(__name__)
load_dotenv()

class SearchRAG:
    """
    검색 결과를 RAG로 활용하는 클래스
    """
    
    def __init__(self):
        """RAG 시스템 초기화"""
        try:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                raise ValueError("OPENAI_API_KEY가 설정되지 않았습니다.")
            
            # Embeddings 초기화
            self.embeddings = OpenAIEmbeddings(openai_api_key=api_key)
            
            # 텍스트 분할기
            self.text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=1000,
                chunk_overlap=200
            )
            
            # 임시 벡터 스토어 (메모리 기반)
            self.vector_store = None
            self.current_documents = []
            
            logger.info("RAG 시스템 초기화 완료")
            
        except Exception as e:
            logger.error(f"RAG 초기화 오류: {str(e)}")
            raise
    
    def add_search_results(self, search_results: str, query: str = "") -> None:
        """
        검색 결과를 벡터 DB에 추가
        
        Args:
            search_results: 검색 결과 문자열
            query: 원본 검색 쿼리
        """
        try:
            # 검색 결과를 Document로 변환
            doc = Document(
                page_content=search_results,
                metadata={"query": query, "source": "duckduckgo_search"}
            )
            
            # 텍스트 분할
            splits = self.text_splitter.split_documents([doc])
            
            # 벡터 스토어 생성 또는 업데이트
            if self.vector_store is None:
                self.vector_store = Chroma.from_documents(
                    documents=splits,
                    embedding=self.embeddings
                )
            else:
                # 기존 벡터 스토어에 추가
                self.vector_store.add_documents(splits)
            
            self.current_documents.extend(splits)
            
            logger.info(f"검색 결과 {len(splits)}개 청크 추가 완료")
            
        except Exception as e:
            logger.error(f"검색 결과 추가 오류: {str(e)}")
            raise
    
    def search_relevant_context(self, question: str, k: int = 3) -> str:
        """
        질문과 관련된 검색 결과 컨텍스트 검색
        
        Args:
            question: 사용자 질문
            k: 반환할 문서 수
            
        Returns:
            관련 컨텍스트 문자열
        """
        try:
            if self.vector_store is None or len(self.current_documents) == 0:
                return "검색 결과가 없습니다. 먼저 검색을 수행해주세요."
            
            # 유사도 검색
            docs = self.vector_store.similarity_search(question, k=k)
            
            if not docs:
                return "관련 검색 결과를 찾을 수 없습니다."
            
            # 컨텍스트 구성
            context = "=== 검색 결과 기반 컨텍스트 ===\n\n"
            for i, doc in enumerate(docs, 1):
                context += f"[검색 결과 {i}]\n"
                context += f"{doc.page_content}\n\n"
            
            return context
            
        except Exception as e:
            logger.error(f"컨텍스트 검색 오류: {str(e)}")
            return f"컨텍스트 검색 중 오류 발생: {str(e)}"
    
    def clear(self):
        """벡터 스토어 초기화"""
        self.vector_store = None
        self.current_documents = []
        logger.info("RAG 벡터 스토어 초기화 완료")
