"""
기사 본문 추출 모듈
기사 링크를 입력받아 본문 텍스트를 추출합니다.
"""
import requests
from bs4 import BeautifulSoup
from typing import Optional
import logging
import re

logger = logging.getLogger(__name__)


class ArticleExtractor:
    """웹 기사의 본문을 추출하는 클래스"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
        }
        
        # 제거할 태그 목록 (메뉴, 스크립트, 광고 등)
        self.remove_tags = [
            'script', 'style', 'nav', 'header', 'footer', 
            'aside', 'advertisement', 'ad', 'ads', 'banner',
            'menu', 'navigation', 'sidebar', 'comment', 'comments'
        ]
    
    def extract_content(self, url: str) -> Optional[str]:
        """
        URL에서 기사 본문 추출
        대표적인 본문 영역을 우선 탐색하고, 실패 시 전체 텍스트에서 메뉴와 스크립트를 제거해 추출
        
        Args:
            url: 기사 URL
            
        Returns:
            기사 본문 텍스트 (추출 실패 시 None)
        """
        try:
            logger.info(f"기사 본문 추출 시작: {url}")
            
            # URL 유효성 검사
            if not url or not url.startswith(('http://', 'https://')):
                logger.warning(f"유효하지 않은 URL: {url}")
                return None
            
            # timeout 설정 (15초)
            response = requests.get(url, headers=self.headers, timeout=15)
            response.raise_for_status()
            response.encoding = response.apparent_encoding or 'utf-8'
            
            # 응답 크기 제한 (10MB)
            if len(response.content) > 10 * 1024 * 1024:
                logger.warning(f"응답 크기가 너무 큼 ({len(response.content)} bytes): {url}")
                return None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 1단계: 대표적인 본문 영역 우선 탐색
            try:
                content = self._extract_from_main_content(soup)
            except Exception as e:
                logger.warning(f"본문 영역 추출 실패: {e}")
                content = None
            
            # 2단계: 본문 영역 탐색 실패 시 대체 방법 사용
            if not content or len(content) < 100:
                try:
                    content = self._extract_from_alternative(soup)
                except Exception as e:
                    logger.warning(f"대체 방법 추출 실패: {e}")
            
            # 3단계: 최종 대체 방법 - 전체 텍스트에서 불필요한 요소 제거
            if not content or len(content) < 100:
                try:
                    content = self._extract_from_full_text(soup)
                except Exception as e:
                    logger.warning(f"전체 텍스트 추출 실패: {e}")
            
            # 텍스트 정리
            if content:
                try:
                    content = self._clean_text(content)
                except Exception as e:
                    logger.warning(f"텍스트 정리 실패: {e}")
                
            result = content if content and len(content) > 50 else None
            if result:
                logger.info(f"기사 본문 추출 성공: {len(result)}자")
            else:
                logger.warning(f"기사 본문 추출 실패: {url}")
            return result
            
        except requests.Timeout:
            logger.error(f"기사 본문 추출 타임아웃 ({url}): 요청 시간 초과")
            return None
        except requests.RequestException as e:
            logger.error(f"기사 본문 추출 요청 중 오류 ({url}): {e}", exc_info=True)
            return None
        except Exception as e:
            logger.error(f"기사 본문 추출 중 예상치 못한 오류 ({url}): {e}", exc_info=True)
            return None
    
    def _extract_from_main_content(self, soup: BeautifulSoup) -> Optional[str]:
        """대표적인 본문 영역에서 추출 시도"""
        # 네이버 뉴스 및 주요 언론사 본문 선택자
        main_content_selectors = [
            # 네이버 뉴스
            '#articleBodyContents',
            '#articleBody',
            '.news_end_body',
            '.article_body',
            # 일반적인 기사 본문
            'article',
            'article .article-body',
            'article .article_body',
            '.article-body',
            '.article_body',
            '.article-content',
            '.article-content-body',
            # 기타
            'div[itemprop="articleBody"]',
            '.article-view',
            '.post-content',
            '.entry-content',
            '#content-body',
            '.content-body'
        ]
        
        for selector in main_content_selectors:
            try:
                elements = soup.select(selector)
                if elements:
                    # 가장 큰 요소 선택 (본문일 가능성이 높음)
                    largest_element = max(elements, key=lambda x: len(x.get_text()))
                    content = largest_element.get_text(separator=' ', strip=True)
                    
                    # 스크립트와 스타일 태그 제거
                    for tag in largest_element.find_all(['script', 'style']):
                        tag.decompose()
                    
                    content = largest_element.get_text(separator=' ', strip=True)
                    
                    if len(content) > 100:  # 최소 길이 체크
                        logger.debug(f"본문 추출 성공 (선택자: {selector})")
                        return content
            except Exception as e:
                logger.debug(f"선택자 {selector} 추출 실패: {e}")
                continue
        
        return None
    
    def _extract_from_alternative(self, soup: BeautifulSoup) -> Optional[str]:
        """대체 방법으로 본문 추출 (p 태그 기반)"""
        try:
            # article 태그 내의 p 태그 우선
            article = soup.find('article')
            if article:
                paragraphs = article.find_all('p')
            else:
                paragraphs = soup.find_all('p')
            
            # 긴 텍스트를 가진 p 태그만 선택 (본문일 가능성 높음)
            content_paragraphs = []
            for p in paragraphs:
                text = p.get_text(strip=True)
                # 너무 짧거나 링크만 있는 경우 제외
                if len(text) > 30 and not p.find('a', href=True):
                    content_paragraphs.append(text)
            
            if content_paragraphs:
                content = ' '.join(content_paragraphs)
                if len(content) > 100:
                    logger.debug("대체 방법으로 본문 추출 성공 (p 태그)")
                    return content
        except Exception as e:
            logger.debug(f"대체 방법 추출 실패: {e}")
        
        return None
    
    def _extract_from_full_text(self, soup: BeautifulSoup) -> Optional[str]:
        """전체 텍스트에서 메뉴와 스크립트를 제거해 추출"""
        try:
            # 불필요한 태그 제거
            for tag_name in self.remove_tags:
                for tag in soup.find_all(tag_name):
                    tag.decompose()
            
            # 클래스나 ID에 특정 키워드가 포함된 요소 제거
            unwanted_classes = ['menu', 'nav', 'header', 'footer', 'ad', 'advertisement', 
                              'sidebar', 'comment', 'social', 'share', 'related']
            for class_name in unwanted_classes:
                for elem in soup.find_all(class_=re.compile(class_name, re.I)):
                    elem.decompose()
                for elem in soup.find_all(id=re.compile(class_name, re.I)):
                    elem.decompose()
            
            # body 태그에서 텍스트 추출
            body = soup.find('body')
            if body:
                content = body.get_text(separator=' ', strip=True)
            else:
                content = soup.get_text(separator=' ', strip=True)
            
            # 너무 짧은 줄 제거 (메뉴 항목 등)
            lines = [line.strip() for line in content.split('\n') if len(line.strip()) > 20]
            content = ' '.join(lines)
            
            if len(content) > 100:
                logger.debug("전체 텍스트에서 본문 추출 성공")
                return content
        except Exception as e:
            logger.debug(f"전체 텍스트 추출 실패: {e}")
        
        return None
    
    def _clean_text(self, text: str) -> str:
        """추출된 텍스트 정리"""
        # 연속된 공백 제거
        text = re.sub(r'\s+', ' ', text)
        # 연속된 줄바꿈 제거
        text = re.sub(r'\n\s*\n', '\n', text)
        # 앞뒤 공백 제거
        text = text.strip()
        return text
    
    def extract_multiple(self, urls: list) -> dict:
        """
        여러 URL의 본문을 일괄 추출
        
        Args:
            urls: URL 리스트
            
        Returns:
            {url: content} 형태의 딕셔너리
        """
        results = {}
        for url in urls:
            content = self.extract_content(url)
            if content:
                results[url] = content
        return results
