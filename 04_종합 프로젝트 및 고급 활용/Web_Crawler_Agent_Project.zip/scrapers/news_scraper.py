"""
뉴스 기사 수집을 위한 스크래퍼 모듈
네이버 뉴스 검색 결과 페이지를 크롤링합니다.
"""
import requests
from bs4 import BeautifulSoup
from typing import List, Dict
import logging
from datetime import datetime
import urllib.parse
import re

logger = logging.getLogger(__name__)


class NewsScraper:
    """뉴스 기사를 수집하는 클래스"""
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
        }
    
    def search_news(self, keyword: str, max_results: int = 5) -> List[Dict]:
        """
        키워드로 네이버 뉴스 검색
        
        Args:
            keyword: 검색할 키워드
            max_results: 최대 결과 수 (기본값: 5)
            
        Returns:
            뉴스 기사 리스트 (제목, 날짜, 언론사, 기사 링크 포함)
        """
        results = []
        try:
            # 네이버 뉴스 검색 URL 생성
            encoded_keyword = urllib.parse.quote(keyword)
            search_url = f"https://search.naver.com/search.naver?where=news&query={encoded_keyword}"
            
            logger.info(f"뉴스 검색 시작: {keyword} (최대 {max_results}개)")
            logger.info(f"검색 URL: {search_url}")
            
            # timeout 설정 (15초)
            response = requests.get(search_url, headers=self.headers, timeout=15)
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 디버깅: HTML 구조 확인
            logger.info(f"응답 상태 코드: {response.status_code}, 응답 길이: {len(response.text)}")
            
            # 모든 뉴스 링크를 직접 찾기 (가장 확실한 방법)
            all_links = soup.find_all('a', href=True)
            news_links = []
            seen_links = set()
            
            # 제외할 링크 패턴 (프로모션, 광고, 정적 페이지)
            exclude_patterns = [
                'channelPromotion',
                'static',
                'main/static',
                'promotion',
                'ad',
                'advertisement',
                'banner',
                'event',
                'subscribe',
                'ranking',
                'main/ranking'
            ]
            
            for link in all_links:
                href = link.get('href', '')
                
                # 기본 필터링: 네이버 뉴스 링크인지 확인
                if not ('news.naver.com' in href or 'n.news.naver.com' in href):
                    continue
                
                # 제외 패턴 확인
                should_exclude = False
                for pattern in exclude_patterns:
                    if pattern in href.lower():
                        should_exclude = True
                        break
                
                if should_exclude:
                    continue
                
                # 실제 뉴스 기사 링크인지 확인
                # 네이버 뉴스 기사는 보통 /article/ 또는 /mnews/article/ 경로를 포함
                # main/, static/, promotion 등은 제외
                if '/main/' in href or '/static/' in href:
                    continue
                
                # article이 포함되어 있으면 유효한 뉴스 기사
                # n.news.naver.com/mnews/article/... 형식도 허용
                has_article = '/article/' in href or '/mnews/article/' in href
                if not has_article:
                    continue
                
                # 중복 제거 (정규화된 URL로 비교)
                # URL 정규화 (쿼리 파라미터 제거하여 비교)
                normalized_href = href.split('?')[0] if '?' in href else href
                if normalized_href in seen_links or href in seen_links:
                    continue
                seen_links.add(normalized_href)
                seen_links.add(href)
                
                # 제목 추출 - 여러 방법 시도
                title = None
                
                # 방법 1: 링크 자체의 텍스트
                title = link.get_text(strip=True)
                
                # 방법 2: 부모 요소에서 제목 찾기 (news_tit 클래스 등)
                if not title or len(title) < 5:
                    parent = link.find_parent(['div', 'li', 'article'])
                    if parent:
                        # news_tit 클래스 찾기
                        title_elem = parent.find('a', class_='news_tit') or parent.find(class_='news_tit')
                        if title_elem:
                            title = title_elem.get_text(strip=True)
                        else:
                            # 다른 제목 요소 찾기
                            title_elem = parent.find(['h2', 'h3', 'h4', 'a'], class_=re.compile(r'title|tit|headline', re.I))
                            if title_elem:
                                title = title_elem.get_text(strip=True)
                
                # 방법 3: title 속성 확인
                if not title or len(title) < 5:
                    title_attr = link.get('title', '')
                    if title_attr and len(title_attr) > 5:
                        title = title_attr
                
                # 제목이 없는 경우 스킵
                if not title or len(title) < 3:
                    continue
                
                # 프로모션 관련 키워드가 제목에 포함된 경우 제외
                # 단, 실제 뉴스 기사 링크(/article/ 포함)는 예외
                promotion_keywords = ['선정언론사가 선정한', '구독하세요', '프로모션', '이벤트']
                if any(keyword in title for keyword in promotion_keywords):
                    # 링크 패턴으로 다시 확인
                    if '/article/' not in href and '/mnews/article/' not in href:
                        continue
                
                news_links.append({
                    'title': title,
                    'link': href,
                    'element': link
                })
            
            logger.info(f"찾은 뉴스 링크: {len(news_links)}개")
            
            # 각 뉴스 링크에서 정보 추출
            for news_data in news_links[:max_results]:
                try:
                    link = news_data['link']
                    title = news_data['title']
                    link_elem = news_data['element']
                    
                    # 링크 정규화
                    if link.startswith('//'):
                        link = 'https:' + link
                    elif link.startswith('/'):
                        link = 'https://news.naver.com' + link
                    elif not link.startswith('http'):
                        continue
                    
                    # 부모 요소에서 날짜와 언론사 찾기
                    parent = link_elem.find_parent(['div', 'li', 'article'])
                    date = '날짜 없음'
                    press = '언론사 없음'
                    
                    if parent:
                        # 날짜 찾기 - 여러 패턴 시도
                        date_elements = parent.find_all(['span', 'div', 'em'], class_=re.compile(r'info|date|time', re.I))
                        for date_elem in date_elements:
                            date_text = date_elem.get_text(strip=True)
                            # 날짜 패턴 찾기
                            date_match = re.search(r'(\d{4}\.\d{2}\.\d{2}|\d+시간\s*전|\d+일\s*전|\d+분\s*전|\d{2}:\d{2})', date_text)
                            if date_match:
                                date = date_match.group()
                                break
                        
                        # 언론사 찾기
                        press_elements = parent.find_all(['span', 'a', 'em'], class_=re.compile(r'press|info|press_name', re.I))
                        for press_elem in press_elements:
                            press_text = press_elem.get_text(strip=True)
                            if press_text and len(press_text) < 30 and len(press_text) > 1:
                                press = press_text
                                break
                        
                        # info 클래스에서 언론사와 날짜 함께 추출
                        if press == '언론사 없음' or date == '날짜 없음':
                            info_elem = parent.find(['span', 'div'], class_='info')
                            if info_elem:
                                info_text = info_elem.get_text(strip=True)
                                # "언론사명 · 날짜" 형식 파싱
                                if '·' in info_text:
                                    parts = [p.strip() for p in info_text.split('·')]
                                    if len(parts) >= 2:
                                        if press == '언론사 없음':
                                            press = parts[0]
                                        if date == '날짜 없음':
                                            date = parts[1]
                                else:
                                    # 공백으로 분리
                                    parts = info_text.split()
                                    if parts:
                                        if press == '언론사 없음' and len(parts[0]) < 20:
                                            press = parts[0]
                                        if date == '날짜 없음' and len(parts) > 1:
                                            # 날짜 패턴이 있는 부분 찾기
                                            for part in parts[1:]:
                                                if re.search(r'\d{4}\.\d{2}\.\d{2}|\d+시간|\d+일|\d+분', part):
                                                    date = part
                                                    break
                    
                    # 결과 추가
                    results.append({
                        'title': title,
                        'date': date,
                        'press': press,
                        'link': link,
                        'keyword': keyword,
                        'scraped_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    })
                    logger.info(f"기사 수집 성공: {title[:50]}...")
                    
                except Exception as e:
                    logger.error(f"기사 정보 추출 중 오류: {e}", exc_info=True)
                    continue
            
            # 여전히 결과가 없으면 추가 방법 시도
            if not results:
                logger.warning("직접 링크 방법으로 결과가 없어 추가 방법 시도")
                # news_wrap 클래스로 시도
                news_wraps = soup.find_all('div', class_='news_wrap')
                logger.info(f"news_wrap 요소: {len(news_wraps)}개")
                
                for wrap in news_wraps[:max_results]:
                    try:
                        # 제목과 링크
                        title_elem = wrap.find('a', class_='news_tit')
                        if not title_elem:
                            title_elem = wrap.find('a', href=re.compile(r'news\.naver\.com'))
                        
                        if title_elem:
                            title = title_elem.get_text(strip=True)
                            link = title_elem.get('href', '')
                            
                            if title and link:
                                # 링크 정규화
                                if link.startswith('//'):
                                    link = 'https:' + link
                                elif link.startswith('/'):
                                    link = 'https://news.naver.com' + link
                                
                                # 실제 뉴스 기사 링크인지 확인
                                exclude_patterns = ['channelPromotion', 'static', 'promotion', 'main/static']
                                if any(pattern in link.lower() for pattern in exclude_patterns):
                                    continue
                                
                                # /article/ 경로가 있는 링크 우선
                                if '/article/' not in link:
                                    # main/ 경로는 제외
                                    if '/main/' in link:
                                        continue
                                
                                # 날짜와 언론사
                                date = '날짜 없음'
                                press = '언론사 없음'
                                
                                info_elem = wrap.find('span', class_='info')
                                if info_elem:
                                    info_text = info_elem.get_text(strip=True)
                                    if '·' in info_text:
                                        parts = [p.strip() for p in info_text.split('·')]
                                        if len(parts) >= 2:
                                            press = parts[0]
                                            date = parts[1]
                                
                                results.append({
                                    'title': title,
                                    'date': date,
                                    'press': press,
                                    'link': link,
                                    'keyword': keyword,
                                    'scraped_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                                })
                                logger.info(f"news_wrap으로 기사 수집: {title[:50]}...")
                    except Exception as e:
                        logger.error(f"news_wrap 파싱 오류: {e}")
                        continue
                    
        except requests.RequestException as e:
            logger.error(f"뉴스 검색 요청 중 오류: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"뉴스 검색 중 오류: {e}", exc_info=True)
        
        logger.info(f"뉴스 검색 완료: {len(results)}개 수집")
        return results
    
    def get_real_estate_news(self, max_results: int = 5) -> List[Dict]:
        """
        부동산 관련 뉴스 수집
        
        Args:
            max_results: 최대 결과 수 (기본값: 5)
            
        Returns:
            부동산 뉴스 기사 리스트
        """
        keywords = ['부동산', '아파트', '전세', '매매', '부동산 정책']
        all_results = []
        
        for keyword in keywords:
            results = self.search_news(keyword, max_results=max_results // len(keywords) + 1)
            all_results.extend(results)
            
        # 중복 제거 (제목 기준)
        seen_titles = set()
        unique_results = []
        for item in all_results:
            if item['title'] not in seen_titles:
                seen_titles.add(item['title'])
                unique_results.append(item)
                
        return unique_results[:max_results]
