import os
import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path
from typing import List
import time
from dotenv import load_dotenv

# 기존 함수들 import
from app import (
    load_all_pdfs_from_data,
    create_or_load_faiss_index,
    search_relevant_documents,
    create_rag_prompt,
    generate_answer_with_llm
)
from openai import OpenAI

# 환경 변수 로드
load_dotenv()

# 페이지 설정
st.set_page_config(
    page_title="RAG 챗봇",
    page_icon="🤖",
    layout="wide"
)

# 세션 상태 초기화 (안전하게)
def init_session_state():
    """세션 상태 초기화"""
    defaults = {
        "messages": [],
        "index": None,
        "texts": None,
        "embeddings": None,
        "sample_questions": [],
        "input_question": "",
        "pdf_files": [],  # PDF 파일 목록
        "chunk_info": []  # 청크 정보 (어떤 PDF에서 왔는지)
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

# 세션 상태 초기화 실행
init_session_state()


def generate_sample_questions(texts: List[str], num_questions: int = 5) -> List[str]:
    """
    PDF 문서를 분석하여 샘플 질문을 생성합니다.
    
    Args:
        texts: 문서 텍스트 청크 리스트
        num_questions: 생성할 질문 개수
        
    Returns:
        샘플 질문 리스트
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    if not client.api_key:
        return []
    
    # 문서의 일부를 샘플로 사용 (너무 길면 잘라내기)
    sample_text = "\n\n".join(texts[:10])  # 처음 10개 청크만 사용
    if len(sample_text) > 5000:
        sample_text = sample_text[:5000]
    
    prompt = f"""다음 문서를 분석하여 사용자가 이 문서에 대해 물어볼 수 있는 {num_questions}개의 질문을 생성해주세요.
질문은 문서의 내용을 기반으로 구체적이고 실용적인 것이어야 합니다.

문서 내용:
{sample_text}

다음 형식으로 질문만 나열해주세요 (번호 없이):
1. 질문1
2. 질문2
...
"""
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        
        questions_text = response.choices[0].message.content
        # 질문들을 리스트로 변환
        questions = []
        for line in questions_text.split('\n'):
            line = line.strip()
            if not line:
                continue
            
            # 번호나 불릿 제거 (1., 2., -, • 등)
            question = line
            # 숫자로 시작하는 경우 제거
            if question and question[0].isdigit():
                # "1. " 또는 "1) " 같은 패턴 제거
                parts = question.split('.', 1)
                if len(parts) > 1:
                    question = parts[1].strip()
                else:
                    parts = question.split(')', 1)
                    if len(parts) > 1:
                        question = parts[1].strip()
            
            # 불릿 제거
            if question.startswith('-') or question.startswith('•'):
                question = question[1:].strip()
            
            # 질문으로 보이는 경우만 추가 (최소 길이 체크)
            if question and len(question) > 10 and '?' in question:
                questions.append(question)
            elif question and len(question) > 15:  # 물음표 없어도 충분히 길면 추가
                questions.append(question)
        
        # 기본 질문들도 추가
        default_questions = [
            "이 문서의 핵심 내용은 무엇인가?",
            "PDF에 언급된 주요 개념을 설명해줘",
            "이 문서에서 다루지 않은 내용은?",
            "이 문서의 목적은 무엇인가?",
            "문서에서 가장 중요한 부분은 어디인가?"
        ]
        
        # 생성된 질문과 기본 질문 합치기 (중복 제거)
        all_questions = list(dict.fromkeys(questions + default_questions))
        return all_questions[:num_questions + 5]  # 기본 질문 포함
        
    except Exception as e:
        st.error(f"샘플 질문 생성 중 오류: {e}")
        # 오류 발생 시 기본 질문 반환
        return [
            "이 문서의 핵심 내용은 무엇인가?",
            "PDF에 언급된 주요 개념을 설명해줘",
            "이 문서에서 다루지 않은 내용은?",
            "이 문서의 목적은 무엇인가?",
            "문서에서 가장 중요한 부분은 어디인가?"
        ]


def get_pdf_files_info(data_folder: str = "data"):
    """PDF 파일 목록과 정보를 가져옵니다."""
    data_path = Path(data_folder)
    pdf_files = list(data_path.glob("*.pdf"))
    
    pdf_info = []
    for pdf_file in pdf_files:
        try:
            file_size = pdf_file.stat().st_size / 1024  # KB
            pdf_info.append({
                "name": pdf_file.name,
                "path": str(pdf_file),
                "size_kb": round(file_size, 2)
            })
        except Exception as e:
            continue
    
    return pdf_info


def initialize_rag_system():
    """RAG 시스템 초기화"""
    try:
        with st.spinner("PDF 문서를 로드하고 벡터 인덱스를 준비하는 중..."):
            # PDF 파일 정보 수집 (항상 최신 정보 가져오기)
            pdf_files_info = get_pdf_files_info("data")
            st.session_state["pdf_files"] = pdf_files_info
            
            # 벡터 인덱스 경로 확인
            vectorstore_path = Path("vectorstore")
            index_path = vectorstore_path / "index.faiss"
            texts_path = vectorstore_path / "texts.pkl"
            
            # 기존 인덱스가 있으면 청크 정보만 업데이트
            if index_path.exists() and texts_path.exists():
                # 1. 기존 벡터 인덱스 로드
                chunks = load_all_pdfs_from_data("data", chunk_size=1000, chunk_overlap=200)
                index, texts, embeddings = create_or_load_faiss_index(chunks, "vectorstore")
            else:
                # 1. PDF 문서 로드 및 분할
                chunks = load_all_pdfs_from_data("data", chunk_size=1000, chunk_overlap=200)
                
                # 2. 벡터 인덱스 생성
                index, texts, embeddings = create_or_load_faiss_index(chunks, "vectorstore")
            
            # 청크 정보 생성 (간단한 인덱스 기반)
            chunk_info = []
            for i, chunk in enumerate(texts):
                chunk_info.append({
                    "chunk_id": i,
                    "length": len(chunk),
                    "preview": chunk[:100] + "..." if len(chunk) > 100 else chunk
                })
            st.session_state["chunk_info"] = chunk_info
            
            # 세션 상태에 저장
            st.session_state["index"] = index
            st.session_state["texts"] = texts
            st.session_state["embeddings"] = embeddings
            
            # 샘플 질문 생성 (기존 질문이 없을 때만)
            if not st.session_state.get("sample_questions"):
                with st.spinner("샘플 질문을 생성하는 중..."):
                    sample_questions = generate_sample_questions(texts, num_questions=5)
                    st.session_state["sample_questions"] = sample_questions
            
            return True
    except Exception as e:
        st.error(f"초기화 중 오류 발생: {e}")
        return False


def process_question(prompt: str):
    """질문을 처리하고 답변을 생성하는 함수"""
    # 사용자 메시지 추가
    if "messages" not in st.session_state:
        st.session_state["messages"] = []
    st.session_state["messages"].append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # 답변 생성
    with st.chat_message("assistant"):
        try:
            # 1단계: 벡터 검색으로 관련 문서 검색
            index = st.session_state.get("index")
            texts = st.session_state.get("texts")
            
            if index is None or texts is None:
                raise ValueError("벡터 인덱스가 로드되지 않았습니다. 시스템을 초기화하세요.")
            
            with st.spinner("🔍 관련 문서를 검색하는 중..."):
                relevant_docs = search_relevant_documents(
                    prompt, 
                    index, 
                    texts, 
                    k=3
                )
            
            # 2단계: 검색된 문서를 화면에 표시
            st.markdown("### 📚 검색된 관련 문서")
            st.caption(f"질문과 관련된 {len(relevant_docs)}개의 문서 청크를 찾았습니다.")
            
            # 전체 PDF 파일 목록 표시
            pdf_files = st.session_state.get("pdf_files", [])
            if pdf_files:
                st.markdown("**📁 RAG에 사용된 PDF 파일:**")
                pdf_list = ", ".join([pdf_info['name'] for pdf_info in pdf_files])
                st.markdown(f"`{pdf_list}`")
                st.markdown("")
            
            # 각 검색된 문서 표시
            for i, doc in enumerate(relevant_docs, 1):
                st.markdown(f"#### 📄 검색된 문서 {i}")
                
                # 문서 정보
                doc_length = len(doc)
                st.markdown(f"**문서 길이:** {doc_length}자")
                
                # 문서 내용 전체 표시 (접을 수 있게)
                with st.expander(f"문서 {i} 전체 내용 보기", expanded=(i == 1)):  # 첫 번째 문서는 기본적으로 펼침
                    st.markdown("**문서 내용:**")
                    st.code(doc, language=None)
                    
                    # 문서 통계
                    word_count = len(doc.split())
                    st.caption(f"📊 통계: {word_count}단어, {doc_length}자")
                
                # 문서 미리보기 (항상 표시)
                preview_length = 300
                doc_preview = doc[:preview_length] + "..." if len(doc) > preview_length else doc
                st.markdown("**미리보기:**")
                st.info(doc_preview)
                
                if i < len(relevant_docs):
                    st.markdown("---")
            
            st.markdown("---")
            
            # 3단계: OpenAI로 답변 생성
            with st.spinner("🤖 OpenAI로 답변을 생성하는 중..."):
                # RAG 프롬프트 생성
                rag_prompt = create_rag_prompt(prompt, relevant_docs)
                
                # LLM으로 답변 생성
                answer = generate_answer_with_llm(rag_prompt, model="gpt-4o-mini")
            
            # 4단계: 답변 표시
            st.markdown("### 💬 생성된 답변")
            st.markdown(answer)
            
            # 출처 정보와 함께 답변을 메시지에 추가
            if "messages" not in st.session_state:
                st.session_state["messages"] = []
            st.session_state["messages"].append({
                "role": "assistant", 
                "content": answer,
                "sources": relevant_docs
            })
            
        except Exception as e:
            error_msg = f"죄송합니다. 오류가 발생했습니다: {e}"
            st.error(error_msg)
            if "messages" not in st.session_state:
                st.session_state["messages"] = []
            st.session_state["messages"].append({
                "role": "assistant", 
                "content": error_msg
            })


def main():
    """메인 Streamlit 앱"""
    st.title("🤖 RAG 챗봇")
    st.markdown("PDF 문서를 기반으로 질문에 답변하는 RAG 챗봇입니다.")
    
    # 사이드바
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # 초기화 버튼
        if st.button("🔄 시스템 초기화", use_container_width=True):
            if initialize_rag_system():
                st.success("시스템이 성공적으로 초기화되었습니다!")
                st.session_state["messages"] = []  # 대화 기록 초기화
            else:
                st.error("초기화에 실패했습니다.")
        
        # 시스템 상태 표시
        st.divider()
        st.subheader("📊 시스템 상태")
        
        # 안전하게 세션 상태 확인
        index = st.session_state.get("index", None)
        texts = st.session_state.get("texts", None)
        pdf_files = st.session_state.get("pdf_files", [])
        chunk_info = st.session_state.get("chunk_info", [])
        
        if index is not None and texts is not None:
            st.success("✅ 벡터 인덱스 로드됨")
            st.info(f"📄 문서 청크 수: {len(texts)}")
            
            # PDF 파일 목록 표시
            if pdf_files:
                st.divider()
                st.subheader("📚 사용된 PDF 파일")
                for i, pdf_info in enumerate(pdf_files, 1):
                    st.markdown(f"{i}. **{pdf_info['name']}** ({pdf_info['size_kb']} KB)")
            
            # 청크 목록 표시 (접을 수 있게)
            if chunk_info:
                st.divider()
                with st.expander(f"📑 청크된 문서 목록 ({len(chunk_info)}개)", expanded=False):
                    for i, chunk in enumerate(chunk_info[:50], 1):  # 처음 50개만 표시
                        st.markdown(f"**청크 {chunk['chunk_id']+1}** (길이: {chunk['length']}자)")
                        st.text(chunk['preview'])
                        if i < min(50, len(chunk_info)):
                            st.divider()
                    if len(chunk_info) > 50:
                        st.caption(f"... 외 {len(chunk_info) - 50}개 청크 더 있음")
        else:
            st.warning("⚠️ 벡터 인덱스가 로드되지 않았습니다.")
            st.info("'시스템 초기화' 버튼을 클릭하세요.")
        
        # 샘플 질문 섹션
        sample_questions = st.session_state.get("sample_questions", [])
        if sample_questions:
            st.divider()
            st.subheader("💡 샘플 질문")
            st.caption("클릭하여 질문을 선택하세요")
            
            for i, question in enumerate(sample_questions):
                # 질문을 선택 가능한 텍스트로 표시
                st.text_area(
                    f"질문 {i+1}",
                    question,
                    height=60,
                    key=f"question_text_{i}",
                    disabled=False,
                    help="텍스트를 선택(Ctrl+A 또는 드래그) 후 복사(Ctrl+C)하세요"
                )
                
                if i < len(sample_questions) - 1:
                    st.divider()
    
    # 메인 영역
    # 시스템이 초기화되지 않았으면 초기화
    index = st.session_state.get("index", None)
    if index is None:
        st.info("👈 사이드바에서 '시스템 초기화' 버튼을 클릭하여 시작하세요.")
        if st.button("🚀 자동 초기화", use_container_width=True):
            initialize_rag_system()
            st.rerun()
    else:
        # 입력창에 복사된 질문이 있으면 표시
        input_placeholder = "질문을 입력하세요..."
        input_question = st.session_state.get("input_question", "")
        if input_question:
            input_placeholder = input_question
            # 복사된 질문이 있으면 안내 메시지 표시
            st.info(f"💡 **복사된 질문:** {input_question} - 아래 입력창에 표시되었습니다. Enter를 눌러 제출하거나 수정할 수 있습니다.")
        
        # 채팅 메시지 표시
        messages = st.session_state.get("messages", [])
        for message in messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
                
                # 출처 정보가 있으면 표시
                if message["role"] == "assistant" and "sources" in message:
                    # 답변 바로 아래에 RAG 청크 내용 표시
                    st.markdown("---")
                    st.markdown(f"### 📚 답변에 사용된 RAG 청크 ({len(message['sources'])}개)")
                    
                    # 전체 PDF 파일 목록 표시
                    pdf_files = st.session_state.get("pdf_files", [])
                    if pdf_files:
                        st.markdown("**📁 RAG에 사용된 PDF 파일:**")
                        pdf_list = ", ".join([pdf_info['name'] for pdf_info in pdf_files])
                        st.markdown(f"`{pdf_list}`")
                        st.markdown("")
                    
                    # 각 RAG 청크 상세 표시
                    for i, source in enumerate(message["sources"], 1):
                        st.markdown(f"#### 📄 RAG 청크 {i}")
                        
                        # 청크 정보
                        chunk_length = len(source)
                        st.markdown(f"**청크 길이:** {chunk_length}자")
                        
                        # 청크 내용 전체 표시 (접을 수 있게)
                        with st.expander(f"청크 {i} 전체 내용 보기", expanded=(i == 1)):  # 첫 번째 청크는 기본적으로 펼침
                            st.markdown("**청크 내용:**")
                            # 코드 블록 스타일로 표시하여 가독성 향상
                            st.code(source, language=None)
                            
                            # 청크 통계
                            word_count = len(source.split())
                            st.caption(f"📊 통계: {word_count}단어, {chunk_length}자")
                        
                        # 청크 미리보기 (항상 표시)
                        preview_length = 300
                        source_preview = source[:preview_length] + "..." if len(source) > preview_length else source
                        st.markdown("**미리보기:**")
                        st.info(source_preview)
                        
                        if i < len(message["sources"]):
                            st.markdown("---")
                    
                    # 추가 정보를 위한 expander
                    with st.expander("ℹ️ 출처 정보 상세", expanded=False):
                        st.caption(f"이 답변은 {len(message['sources'])}개의 문서 청크를 기반으로 생성되었습니다.")
                        if pdf_files:
                            st.markdown("**사용된 PDF 파일 목록:**")
                            for pdf_info in pdf_files:
                                st.markdown(f"- **{pdf_info['name']}** ({pdf_info['size_kb']} KB)")
        
        # 자동 질문 처리 (예시 질문 클릭 시)
        auto_question = st.session_state.get("auto_question", None)
        if auto_question:
            # 자동 질문을 즉시 처리
            del st.session_state["auto_question"]
            process_question(auto_question)
            st.rerun()
        
        # 사용자 입력 받기
        user_input = st.chat_input(input_placeholder)
        
        # 질문 변수 초기화
        prompt = None
        
        if user_input:
            # 복사된 질문 사용 시 초기화
            if input_question:
                st.session_state["input_question"] = ""
            prompt = user_input
        
        # 질문이 있으면 처리
        if prompt:
            process_question(prompt)
        
        # 대화 기록 초기화 버튼
        if messages:
            if st.button("🗑️ 대화 기록 지우기", use_container_width=True):
                st.session_state["messages"] = []
                st.rerun()


if __name__ == "__main__":
    main()
