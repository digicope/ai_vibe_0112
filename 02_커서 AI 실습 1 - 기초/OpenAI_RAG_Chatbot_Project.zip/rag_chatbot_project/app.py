import os
import pickle
from pathlib import Path
from typing import List, Tuple
import faiss
import numpy as np
from pypdf import PdfReader
from openai import OpenAI
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

class RAGChatbot:
    def __init__(self, vectorstore_path: str = "vectorstore"):
        """
        RAG 챗봇 초기화
        
        Args:
            vectorstore_path: 벡터 저장소 경로
        """
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.vectorstore_path = Path(vectorstore_path)
        self.vectorstore_path.mkdir(exist_ok=True)
        
        self.index = None
        self.texts = []
        self.embeddings = None
        
    def load_pdf(self, pdf_path: str) -> List[str]:
        """
        PDF 파일을 읽어서 텍스트 추출
        
        Args:
            pdf_path: PDF 파일 경로
            
        Returns:
            추출된 텍스트 리스트
        """
        reader = PdfReader(pdf_path)
        texts = []
        
        for page in reader.pages:
            text = page.extract_text()
            if text.strip():
                texts.append(text)
        
        return texts
    
    def split_text(self, texts: List[str], chunk_size: int = 1000, overlap: int = 200) -> List[str]:
        """
        텍스트를 청크로 분할
        
        Args:
            texts: 분할할 텍스트 리스트
            chunk_size: 청크 크기 (문자 수)
            overlap: 청크 간 겹치는 문자 수
            
        Returns:
            분할된 텍스트 청크 리스트
        """
        chunks = []
        
        for text in texts:
            # 텍스트가 chunk_size보다 작으면 그대로 추가
            if len(text) <= chunk_size:
                chunks.append(text)
            else:
                # 텍스트를 chunk_size로 분할 (overlap 고려)
                start = 0
                while start < len(text):
                    end = start + chunk_size
                    chunk = text[start:end]
                    chunks.append(chunk)
                    start = end - overlap
        
        return chunks
    
    def get_embeddings(self, texts: List[str]) -> np.ndarray:
        """
        OpenAI Embeddings API를 사용하여 텍스트를 벡터화
        
        Args:
            texts: 벡터화할 텍스트 리스트
            
        Returns:
            임베딩 벡터 배열
        """
        embeddings = []
        
        # 배치 처리 (OpenAI API는 여러 텍스트를 한 번에 처리 가능)
        response = self.client.embeddings.create(
            model="text-embedding-3-small",
            input=texts
        )
        
        for embedding in response.data:
            embeddings.append(embedding.embedding)
        
        return np.array(embeddings, dtype=np.float32)
    
    def build_vectorstore(self, pdf_path: str):
        """
        PDF 파일을 읽어서 벡터 저장소 구축
        
        Args:
            pdf_path: PDF 파일 경로
        """
        print(f"PDF 파일 로딩 중: {pdf_path}")
        texts = self.load_pdf(pdf_path)
        
        print("텍스트 청크 분할 중...")
        chunks = self.split_text(texts)
        self.texts = chunks
        
        print(f"총 {len(chunks)}개의 청크 생성")
        print("임베딩 생성 중...")
        embeddings = self.get_embeddings(chunks)
        self.embeddings = embeddings
        
        # Faiss 인덱스 생성
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dimension)
        self.index.add(embeddings)
        
        print(f"벡터 저장소 구축 완료 (차원: {dimension}, 벡터 수: {len(embeddings)})")
        
        # 벡터 저장소 저장
        self.save_vectorstore()
    
    def save_vectorstore(self):
        """벡터 저장소를 디스크에 저장"""
        # Faiss 인덱스 저장
        faiss.write_index(self.index, str(self.vectorstore_path / "index.faiss"))
        
        # 텍스트와 임베딩 저장
        with open(self.vectorstore_path / "texts.pkl", "wb") as f:
            pickle.dump(self.texts, f)
        
        with open(self.vectorstore_path / "embeddings.pkl", "wb") as f:
            pickle.dump(self.embeddings, f)
        
        print(f"벡터 저장소가 {self.vectorstore_path}에 저장되었습니다.")
    
    def load_vectorstore(self):
        """디스크에서 벡터 저장소 로드"""
        index_path = self.vectorstore_path / "index.faiss"
        texts_path = self.vectorstore_path / "texts.pkl"
        embeddings_path = self.vectorstore_path / "embeddings.pkl"
        
        if not all([index_path.exists(), texts_path.exists(), embeddings_path.exists()]):
            raise FileNotFoundError("벡터 저장소를 찾을 수 없습니다. 먼저 build_vectorstore()를 실행하세요.")
        
        self.index = faiss.read_index(str(index_path))
        
        with open(texts_path, "rb") as f:
            self.texts = pickle.load(f)
        
        with open(embeddings_path, "rb") as f:
            self.embeddings = pickle.load(f)
        
        print(f"벡터 저장소 로드 완료 (벡터 수: {len(self.texts)})")
    
    def search(self, query: str, k: int = 3) -> List[Tuple[str, float]]:
        """
        쿼리와 유사한 텍스트 청크 검색
        
        Args:
            query: 검색 쿼리
            k: 반환할 상위 k개 결과
            
        Returns:
            (텍스트, 거리) 튜플 리스트
        """
        if self.index is None:
            raise ValueError("벡터 저장소가 로드되지 않았습니다.")
        
        # 쿼리 임베딩 생성
        query_embedding = self.get_embeddings([query])[0]
        query_embedding = query_embedding.reshape(1, -1).astype(np.float32)
        
        # 유사도 검색
        distances, indices = self.index.search(query_embedding, k)
        
        results = []
        for i, (distance, idx) in enumerate(zip(distances[0], indices[0])):
            if idx < len(self.texts):
                results.append((self.texts[idx], float(distance)))
        
        return results
    
    def chat(self, query: str, k: int = 3) -> str:
        """
        RAG를 사용하여 쿼리에 대한 답변 생성
        
        Args:
            query: 사용자 쿼리
            k: 검색할 컨텍스트 청크 수
            
        Returns:
            생성된 답변
        """
        # 관련 컨텍스트 검색
        results = self.search(query, k)
        
        # 컨텍스트 구성
        context = "\n\n".join([text for text, _ in results])
        
        # 프롬프트 구성
        system_prompt = """당신은 주어진 문서를 기반으로 질문에 답변하는 도우미입니다. 
문서의 내용을 바탕으로 정확하고 유용한 답변을 제공하세요. 
만약 문서에서 답을 찾을 수 없다면, 그렇게 말씀해주세요."""
        
        user_prompt = f"""다음 문서 내용을 참고하여 질문에 답변해주세요.

문서 내용:
{context}

질문: {query}

답변:"""
        
        # OpenAI Chat API 호출
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.7
        )
        
        return response.choices[0].message.content


def load_all_pdfs_from_data(data_folder: str = "data", chunk_size: int = 1000, chunk_overlap: int = 200) -> List[str]:
    """
    data 폴더에 있는 모든 PDF 파일을 읽어서 텍스트를 추출하고 분할합니다.
    
    Args:
        data_folder: PDF 파일이 있는 폴더 경로 (기본값: "data")
        chunk_size: 청크 크기 (기본값: 1000)
        chunk_overlap: 청크 간 겹치는 문자 수 (기본값: 200)
        
    Returns:
        분할된 텍스트 청크 리스트
    """
    data_path = Path(data_folder)
    
    if not data_path.exists():
        raise FileNotFoundError(f"폴더를 찾을 수 없습니다: {data_folder}")
    
    # data 폴더에서 모든 PDF 파일 찾기
    pdf_files = list(data_path.glob("*.pdf"))
    
    if not pdf_files:
        raise FileNotFoundError(f"{data_folder} 폴더에 PDF 파일이 없습니다.")
    
    print(f"{len(pdf_files)}개의 PDF 파일을 찾았습니다.")
    
    # 모든 PDF 파일에서 텍스트 추출
    all_texts = []
    chatbot = RAGChatbot()
    
    for pdf_file in pdf_files:
        print(f"PDF 파일 로딩 중: {pdf_file.name}")
        try:
            texts = chatbot.load_pdf(str(pdf_file))
            all_texts.extend(texts)
            print(f"  - {len(texts)}페이지 추출 완료")
        except Exception as e:
            print(f"  - 오류 발생: {pdf_file.name} - {e}")
            continue
    
    if not all_texts:
        raise ValueError("추출된 텍스트가 없습니다.")
    
    print(f"\n총 {len(all_texts)}페이지의 텍스트를 추출했습니다.")
    print("텍스트 청크 분할 중...")
    
    # 텍스트를 하나의 문자열로 합치기
    combined_text = "\n\n".join(all_texts)
    
    # 청크로 분할
    chunks = chatbot.split_text([combined_text], chunk_size=chunk_size, overlap=chunk_overlap)
    
    print(f"총 {len(chunks)}개의 청크로 분할되었습니다.")
    
    return chunks


def create_or_load_faiss_index(chunks: List[str], vectorstore_path: str = "vectorstore", embedding_model: str = "text-embedding-3-small"):
    """
    분할된 문서를 OpenAI Embedding 모델로 벡터화하고 Faiss 인덱스를 생성하거나 로드합니다.
    
    Args:
        chunks: 분할된 텍스트 청크 리스트
        vectorstore_path: 벡터 저장소 경로 (기본값: "vectorstore")
        embedding_model: OpenAI Embedding 모델명 (기본값: "text-embedding-3-small")
        
    Returns:
        (index, texts, embeddings) 튜플
        - index: Faiss 인덱스 객체
        - texts: 텍스트 청크 리스트
        - embeddings: 임베딩 벡터 배열
    """
    vectorstore_dir = Path(vectorstore_path)
    vectorstore_dir.mkdir(exist_ok=True)
    
    index_path = vectorstore_dir / "index.faiss"
    texts_path = vectorstore_dir / "texts.pkl"
    embeddings_path = vectorstore_dir / "embeddings.pkl"
    
    # 이미 인덱스가 존재하면 로드
    if index_path.exists() and texts_path.exists() and embeddings_path.exists():
        print("기존 벡터 인덱스를 찾았습니다. 로드 중...")
        
        index = faiss.read_index(str(index_path))
        
        with open(texts_path, "rb") as f:
            texts = pickle.load(f)
        
        with open(embeddings_path, "rb") as f:
            embeddings = pickle.load(f)
        
        print(f"벡터 인덱스 로드 완료 (벡터 수: {len(texts)})")
        return index, texts, embeddings
    
    # 인덱스가 없으면 새로 생성
    print("새로운 벡터 인덱스를 생성합니다...")
    
    if not chunks:
        raise ValueError("분할된 문서 청크가 없습니다.")
    
    # OpenAI 클라이언트 초기화
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    if not client.api_key:
        raise ValueError("OPENAI_API_KEY 환경 변수가 설정되지 않았습니다.")
    
    print(f"총 {len(chunks)}개의 청크를 벡터화 중...")
    
    # 배치 처리로 임베딩 생성
    embeddings_list = []
    batch_size = 100  # OpenAI API는 한 번에 많은 텍스트를 처리할 수 있지만, 안정성을 위해 배치 처리
    
    for i in range(0, len(chunks), batch_size):
        batch = chunks[i:i + batch_size]
        print(f"  배치 {i//batch_size + 1}/{(len(chunks) + batch_size - 1)//batch_size} 처리 중...")
        
        try:
            response = client.embeddings.create(
                model=embedding_model,
                input=batch
            )
            
            for embedding in response.data:
                embeddings_list.append(embedding.embedding)
        except Exception as e:
            print(f"  배치 처리 중 오류 발생: {e}")
            raise
    
    # NumPy 배열로 변환
    embeddings = np.array(embeddings_list, dtype=np.float32)
    
    print(f"임베딩 생성 완료 (차원: {embeddings.shape[1]})")
    
    # Faiss 인덱스 생성
    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    
    print(f"Faiss 인덱스 생성 완료 (벡터 수: {len(embeddings)})")
    
    # 인덱스와 데이터 저장
    faiss.write_index(index, str(index_path))
    
    with open(texts_path, "wb") as f:
        pickle.dump(chunks, f)
    
    with open(embeddings_path, "wb") as f:
        pickle.dump(embeddings, f)
    
    print(f"벡터 인덱스가 {vectorstore_path} 폴더에 저장되었습니다.")
    
    return index, chunks, embeddings


def search_relevant_documents(query: str, index, texts: List[str], k: int = 3, embedding_model: str = "text-embedding-3-small") -> List[str]:
    """
    Faiss 벡터 인덱스를 기반으로 사용자의 질문과 가장 관련 있는 문서를 검색합니다.
    
    Args:
        query: 사용자의 질문
        index: Faiss 인덱스 객체
        texts: 텍스트 청크 리스트
        k: 검색 결과 문서 개수 (기본값: 3)
        embedding_model: OpenAI Embedding 모델명 (기본값: "text-embedding-3-small")
        
    Returns:
        검색된 문서 리스트 (유사도 순으로 정렬)
    """
    if index is None:
        raise ValueError("Faiss 인덱스가 제공되지 않았습니다.")
    
    if not texts:
        raise ValueError("텍스트 청크 리스트가 비어있습니다.")
    
    # OpenAI 클라이언트 초기화
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    if not client.api_key:
        raise ValueError("OPENAI_API_KEY 환경 변수가 설정되지 않았습니다.")
    
    # 질문을 벡터로 변환
    try:
        response = client.embeddings.create(
            model=embedding_model,
            input=[query]
        )
        query_embedding = np.array([response.data[0].embedding], dtype=np.float32)
    except Exception as e:
        raise ValueError(f"질문 벡터화 중 오류 발생: {e}")
    
    # Faiss 검색 함수 호출
    distances, indices = index.search(query_embedding, k)
    
    # 검색된 문서를 리스트로 반환
    results = []
    for idx in indices[0]:
        if 0 <= idx < len(texts):
            results.append(texts[idx])
    
    return results


def create_rag_prompt(query: str, documents: List[str]) -> str:
    """
    검색된 문서 내용을 기반으로 LLM에 전달할 RAG 프롬프트를 구성합니다.
    
    Args:
        query: 사용자의 질문
        documents: 검색된 문서 리스트
        
    Returns:
        구성된 RAG 프롬프트 문자열
    """
    if not documents:
        raise ValueError("검색된 문서가 없습니다.")
    
    # 문서 내용을 하나의 context 문자열로 합치기
    context = "\n\n".join(documents)
    
    # RAG 프롬프트 구성
    prompt = f"""다음 문서를 참고하여 질문에 답변하라.
문서에 없는 내용은 추측하지 말고 '알 수 없음'이라고 답하라.

=== 문서 내용 ===
{context}

=== 질문 ===
{query}

=== 답변 ===
"""
    
    return prompt


def generate_answer_with_llm(rag_prompt: str, model: str = "gpt-4o-mini") -> str:
    """
    RAG 프롬프트를 OpenAI LLM에 전달하여 최종 답변을 생성합니다.
    
    Args:
        rag_prompt: RAG 프롬프트 문자열
        model: 사용할 OpenAI 모델명 (기본값: "gpt-4o-mini")
        
    Returns:
        LLM이 생성한 텍스트 답변
    """
    # OpenAI 클라이언트 초기화
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    if not client.api_key:
        raise ValueError("OPENAI_API_KEY 환경 변수가 설정되지 않았습니다.")
    
    try:
        # OpenAI Chat API 호출
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "user", "content": rag_prompt}
            ],
            temperature=0.7
        )
        
        # 텍스트 답변만 반환
        answer = response.choices[0].message.content
        return answer
        
    except Exception as e:
        raise ValueError(f"LLM 호출 중 오류 발생: {e}")


def main():
    """메인 실행 함수 - 콘솔 기반 RAG 챗봇"""
    print("="*60)
    print("RAG 챗봇 초기화 중...")
    print("="*60)
    
    try:
        # 1. PDF 문서 로드 및 분할
        print("\n[1단계] PDF 문서 로드 및 분할 중...")
        chunks = load_all_pdfs_from_data("data", chunk_size=1000, chunk_overlap=200)
        print(f"✓ {len(chunks)}개의 문서 청크 생성 완료\n")
        
        # 2. Faiss 벡터 인덱스 생성 또는 로드
        print("[2단계] Faiss 벡터 인덱스 생성 또는 로드 중...")
        index, texts, embeddings = create_or_load_faiss_index(chunks, "vectorstore")
        print(f"✓ 벡터 인덱스 준비 완료 (총 {len(texts)}개 벡터)\n")
        
        # 챗봇 시작 메시지
        print("="*60)
        print("RAG 챗봇이 준비되었습니다!")
        print("질문을 입력하세요. ('quit', 'exit', '종료'를 입력하면 종료됩니다)")
        print("="*60 + "\n")
        
        # 3. 사용자로부터 질문 입력 받기 (반복)
        while True:
            query = input("질문: ").strip()
            
            # 종료 조건 확인
            if query.lower() in ['quit', 'exit', '종료']:
                print("\n챗봇을 종료합니다. 감사합니다!")
                break
            
            if not query:
                print("질문을 입력해주세요.\n")
                continue
            
            try:
                # 4. 질문과 관련된 문서 검색
                print("\n[검색 중...]")
                relevant_docs = search_relevant_documents(query, index, texts, k=3)
                print(f"✓ 관련 문서 {len(relevant_docs)}개 검색 완료")
                
                # 5. RAG 프롬프트 생성
                rag_prompt = create_rag_prompt(query, relevant_docs)
                
                # 6. OpenAI LLM 호출
                print("[답변 생성 중...]")
                answer = generate_answer_with_llm(rag_prompt, model="gpt-4o-mini")
                
                # 7. 최종 답변 출력
                print("\n" + "-"*60)
                print("답변:")
                print("-"*60)
                print(answer)
                print("-"*60 + "\n")
                
            except Exception as e:
                print(f"\n오류 발생: {e}\n")
                continue
                
    except FileNotFoundError as e:
        print(f"\n오류: {e}")
        print("data 폴더에 PDF 파일을 추가한 후 다시 실행하세요.")
    except ValueError as e:
        print(f"\n오류: {e}")
    except Exception as e:
        print(f"\n예상치 못한 오류 발생: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
