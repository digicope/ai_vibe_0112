# RAG 챗봇 프로젝트

OpenAI API를 직접 사용하여 구현한 RAG (Retrieval-Augmented Generation) 챗봇입니다.

이 프로젝트는 PDF 문서를 읽어서 벡터화하고, 사용자의 질문과 관련된 문서를 검색하여 정확한 답변을 생성하는 챗봇입니다.

## 프로젝트 구조

```
rag_chatbot_project/
 ├─ app.py                # 콘솔 기반 메인 실행 파일
 ├─ streamlit_app.py      # Streamlit 웹 앱 파일 ⭐
 ├─ data/                  # PDF 문서 저장 폴더
 │   └─ *.pdf
 ├─ vectorstore/          # Faiss 인덱스 저장 폴더
 ├─ requirements.txt
 ├─ .env                  # 환경 변수 파일
 └─ README.md
```

## 설치 방법

1. 필요한 패키지 설치:
```bash
pip install -r requirements.txt
```

2. `.env` 파일에 OpenAI API 키 설정:
```
OPENAI_API_KEY=your_actual_api_key_here
```

3. `data/` 폴더에 PDF 파일 추가:
   - `data/sample.pdf` 또는 원하는 PDF 파일을 `data/` 폴더에 추가하세요.

## 빠른 시작 가이드 (초보자용)

### 1단계: 환경 설정

1. **필요한 패키지 설치**
   ```bash
   pip install -r requirements.txt
   ```

2. **OpenAI API 키 설정**
   - `rag_chatbot_project` 폴더에 `.env` 파일을 생성합니다.
   - 다음 내용을 입력합니다:
     ```
     OPENAI_API_KEY=your_actual_api_key_here
     ```
   - `your_actual_api_key_here` 부분을 실제 OpenAI API 키로 교체하세요.

3. **PDF 파일 준비**
   - `data/` 폴더에 질문하고 싶은 PDF 파일을 넣어주세요.
   - 여러 개의 PDF 파일을 넣어도 모두 처리됩니다.

### 2단계: 프로그램 실행

#### 방법 1: 콘솔 기반 챗봇 (기존)

터미널에서 다음 명령어를 실행합니다:

```bash
cd rag_chatbot_project
python app.py
```

#### 방법 2: 웹 기반 챗봇 (Streamlit) ⭐ 추천

더 편리한 웹 인터페이스를 사용하려면:

```bash
cd rag_chatbot_project
streamlit run streamlit_app.py
```

브라우저가 자동으로 열리며 웹 인터페이스가 표시됩니다.

**Streamlit 앱의 주요 기능:**
- 📱 직관적인 웹 인터페이스
- 💡 PDF 분석 기반 샘플 질문 자동 생성
- 💬 채팅 형식의 대화 인터페이스
- 📊 시스템 상태 실시간 확인
- 🔄 원클릭 시스템 초기화

### 3단계: 실행 흐름 이해하기

프로그램을 실행하면 다음과 같은 단계를 거칩니다:

1. **PDF 문서 로드 및 분할**
   - `data/` 폴더의 모든 PDF 파일을 읽습니다.
   - 각 문서를 1000자 단위로 분할합니다 (200자 겹침).

2. **벡터 인덱스 생성 또는 로드**
   - 처음 실행 시: OpenAI Embedding API로 문서를 벡터화하고 Faiss 인덱스를 생성합니다.
   - 이후 실행 시: 기존에 생성된 인덱스를 로드합니다 (빠른 시작).

3. **질문 입력 및 답변 받기**
   - 질문을 입력하면 관련 문서를 검색합니다.
   - 검색된 문서를 기반으로 LLM이 답변을 생성합니다.

### 4단계: 챗봇 사용하기

프로그램이 시작되면 다음과 같이 질문을 입력할 수 있습니다:

```
질문: 이 문서의 핵심 내용은 무엇인가?
```

답변을 받은 후 계속 질문할 수 있습니다. 종료하려면 `quit`, `exit`, 또는 `종료`를 입력하세요.

## RAG 챗봇 동작 원리

이 RAG 챗봇은 다음과 같은 과정을 거쳐 답변을 생성합니다:

1. **문서 처리**: PDF 파일에서 텍스트를 추출하고 적절한 크기로 분할합니다.
2. **벡터화**: 각 문서 청크를 OpenAI Embedding 모델로 벡터화합니다.
3. **인덱싱**: 벡터를 Faiss 인덱스에 저장하여 빠른 검색이 가능하도록 합니다.
4. **검색**: 사용자 질문을 벡터화하고, 유사한 문서 청크를 검색합니다 (상위 3개).
5. **프롬프트 구성**: 검색된 문서와 질문을 조합하여 RAG 프롬프트를 만듭니다.
6. **답변 생성**: OpenAI LLM (gpt-4o-mini)에 프롬프트를 전달하여 최종 답변을 생성합니다.

## 테스트 질문 예시

RAG 챗봇의 동작을 확인하기 위해 다음 질문들을 시도해보세요:

### 1. 문서 요약 질문
```
질문: 이 문서의 핵심 내용은 무엇인가?
```
이 질문은 문서의 주요 내용을 요약하여 답변합니다.

### 2. 개념 설명 질문
```
질문: PDF에 언급된 주요 개념을 설명해줘
```
이 질문은 문서에서 다루는 주요 개념들을 찾아서 설명합니다.

### 3. 문서 범위 확인 질문
```
질문: 이 문서에서 다루지 않은 내용은?
```
이 질문은 문서의 한계를 파악하는 데 도움이 됩니다. 문서에 없는 내용에 대해서는 "알 수 없음"으로 답변합니다.

### 추가 테스트 질문 아이디어

- "이 문서의 목적은 무엇인가?"
- "문서에서 가장 중요한 부분은 어디인가?"
- "이 문서의 결론은 무엇인가?"
- "문서에서 언급된 구체적인 예시를 알려줘"

## 주요 기능

- **PDF 문서 처리**: `pypdf`를 사용하여 PDF 파일에서 텍스트 추출
- **텍스트 청크 분할**: 긴 텍스트를 적절한 크기의 청크로 분할
- **벡터화**: OpenAI Embeddings API를 사용하여 텍스트를 벡터로 변환
- **벡터 검색**: Faiss를 사용하여 유사한 문서 청크 검색
- **답변 생성**: 검색된 컨텍스트를 기반으로 OpenAI Chat API로 답변 생성

## 클래스 및 메서드

### RAGChatbot 클래스

- `load_pdf(pdf_path)`: PDF 파일에서 텍스트 추출
- `split_text(texts, chunk_size, overlap)`: 텍스트를 청크로 분할
- `get_embeddings(texts)`: OpenAI API로 텍스트 벡터화
- `build_vectorstore(pdf_path)`: PDF 파일로부터 벡터 저장소 구축
- `save_vectorstore()`: 벡터 저장소를 디스크에 저장
- `load_vectorstore()`: 디스크에서 벡터 저장소 로드
- `search(query, k)`: 쿼리와 유사한 텍스트 청크 검색
- `chat(query, k)`: RAG를 사용하여 답변 생성

## 문제 해결

### 자주 발생하는 오류

1. **"OPENAI_API_KEY 환경 변수가 설정되지 않았습니다"**
   - `.env` 파일이 `rag_chatbot_project` 폴더에 있는지 확인하세요.
   - `.env` 파일에 `OPENAI_API_KEY=your_key` 형식으로 올바르게 입력했는지 확인하세요.

2. **"폴더를 찾을 수 없습니다: data"**
   - `data/` 폴더가 `rag_chatbot_project` 폴더 안에 있는지 확인하세요.

3. **"data 폴더에 PDF 파일이 없습니다"**
   - `data/` 폴더에 최소 하나 이상의 PDF 파일이 있어야 합니다.

4. **임베딩 생성 중 오류**
   - OpenAI API 키가 유효한지 확인하세요.
   - API 사용량 한도를 확인하세요.

## 주의사항

- **OpenAI API 키 필요**: 이 프로젝트는 OpenAI API를 사용하므로 유효한 API 키가 필요합니다.
- **PDF 파일 위치**: PDF 파일은 반드시 `data/` 폴더에 저장해야 합니다.
- **벡터 저장소**: 벡터 인덱스는 `vectorstore/` 폴더에 자동으로 저장되며, 다음 실행 시 재사용됩니다.
- **API 비용**: OpenAI API 사용 시 비용이 발생할 수 있습니다. 사용량을 확인하세요.
- **처리 시간**: 처음 실행 시 PDF 파일이 많거나 크면 벡터화에 시간이 걸릴 수 있습니다.

## 프로젝트 구조 상세

```
rag_chatbot_project/
 ├─ app.py                # 콘솔 기반 메인 실행 파일 (모든 함수 포함)
 ├─ streamlit_app.py      # Streamlit 웹 앱 파일 ⭐
 ├─ data/                  # PDF 문서 저장 폴더
 │   └─ *.pdf             # 여기에 PDF 파일들을 넣으세요
 ├─ vectorstore/          # Faiss 인덱스 저장 폴더 (자동 생성)
 │   ├─ index.faiss       # Faiss 벡터 인덱스
 │   ├─ texts.pkl         # 문서 텍스트 청크
 │   └─ embeddings.pkl    # 임베딩 벡터
 ├─ requirements.txt      # 필요한 Python 패키지 목록
 ├─ .env                  # 환경 변수 파일 (직접 생성 필요)
 └─ README.md             # 이 문서
```
