import streamlit as st
import pandas as pd
import os
from pathlib import Path

# ============================================================================
# Streamlit 상태 관리 (Session State)의 필요성
# ============================================================================
# Streamlit은 기본적으로 스크립트가 실행될 때마다 모든 변수가 초기화됩니다.
# 이는 사용자가 위젯과 상호작용할 때마다 전체 스크립트가 다시 실행되기 때문입니다.
# 
# 문제점:
# 1. 사용자가 데이터를 추가하거나 수정해도 새로고침 시 데이터가 사라짐
# 2. 필터링 범위나 입력값이 유지되지 않음
# 3. 동적 데이터 변경이 반영되지 않음
#
# 해결책: st.session_state 사용
# - 세션 상태는 브라우저 세션 동안 유지되는 딕셔너리 형태의 저장소
# - 새로고침해도 데이터가 유지됨
# - 사용자별로 독립적인 상태 관리 가능
# - 동적 데이터 업데이트를 즉시 반영 가능
# ============================================================================

# 페이지 설정
st.set_page_config(
    page_title="Streamlit 데이터 관리 시스템",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 사이드바
with st.sidebar:
    st.title("📊 데이터 관리 시스템")
    st.markdown("---")
    st.markdown("### 🎯 주요 기능")
    st.markdown("""
    - ✅ 데이터 로딩
    - ✅ 데이터 추가
    - ✅ 데이터 필터링
    - ✅ 데이터 시각화
    """)
    st.markdown("---")
    st.markdown("### ℹ️ 정보")
    st.info("이 애플리케이션은 Streamlit의 다양한 기능을 단계별로 학습하기 위한 실습 프로젝트입니다.")
    
    # 데이터 초기화 버튼
    if st.button("🔄 데이터 초기화"):
        if 'df' in st.session_state:
            current_dir = Path(__file__).parent
            data_file = current_dir / "data" / "sample_data.csv"
            if data_file.exists():
                st.session_state.df = pd.read_csv(data_file)
                st.success("데이터가 초기화되었습니다!")
                st.rerun()

# 메인 콘텐츠 영역
# 헤더 섹션
st.markdown("""
<div style='text-align: center; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 10px; margin-bottom: 30px;'>
    <h1 style='color: white; margin: 0;'>📊 Streamlit 데이터 관리 시스템</h1>
    <p style='color: rgba(255,255,255,0.9); margin: 10px 0 0 0;'>데이터 관리 및 시각화 기능을 실습해보세요</p>
</div>
""", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# 이름 입력 섹션
with st.container():
    st.markdown("### 👤 사용자 인사")
    # 세션 상태에 이름 저장 (선택적 - 입력값 유지용)
    if 'user_name' not in st.session_state:
        st.session_state.user_name = ""
    
    col1, col2 = st.columns([3, 1])
    with col1:
        name = st.text_input("이름을 입력하세요:", placeholder="예: 홍길동", value=st.session_state.user_name, label_visibility="collapsed")
    with col2:
        button_clicked = st.button("확인", use_container_width=True, type="primary")
    
    # 버튼 클릭 시 처리
    if button_clicked:
        if name:
            # 세션 상태에 이름 저장 (새로고침 시에도 유지)
            st.session_state.user_name = name
            st.success(f"👋 안녕하세요, **{name}**님! 환영합니다!")
        else:
            st.warning("⚠️ 이름을 입력해주세요.")

st.markdown("<br>", unsafe_allow_html=True)

# 관심 주제 선택 섹션
with st.container():
    st.markdown("### 🎯 관심 주제 선택")
    st.markdown("관심 있는 주제를 선택하면 맞춤형 안내를 제공합니다.")
    
    # 관심 주제 옵션 정의
    interest_options = [
        "주제를 선택하세요",
        "데이터 분석",
        "웹 개발",
        "머신러닝",
        "생성형 AI"
    ]
    
    # 세션 상태에 관심 주제 저장 (새로고침 시에도 유지)
    if 'selected_interest' not in st.session_state:
        st.session_state.selected_interest = interest_options[0]
    
    # st.selectbox를 사용한 선택형 UI 위젯
    selected_interest = st.selectbox(
        "관심 주제를 선택하세요:",
        options=interest_options,
        index=interest_options.index(st.session_state.selected_interest) if st.session_state.selected_interest in interest_options else 0,
        help="드롭다운 메뉴에서 관심 있는 주제를 선택할 수 있습니다."
    )
    
    # 선택한 값을 세션 상태에 저장
    st.session_state.selected_interest = selected_interest
    
    # ============================================================
    # 조건문(if)을 활용한 로직 구현
    # ============================================================
    # 선택한 값에 따라 다른 안내 문구를 출력
    # 각 조건에 맞는 맞춤형 메시지를 제공
    # ============================================================
    
    # 선택한 주제에 따른 조건부 처리
    if selected_interest == "주제를 선택하세요":
        # 기본 상태: 아무것도 선택하지 않았을 때
        st.info("ℹ️ 위의 드롭다운 메뉴에서 관심 주제를 선택해주세요.")
    
    elif selected_interest == "데이터 분석":
        # 데이터 분석 선택 시
        st.success("📊 **데이터 분석**을 선택하셨습니다!")
        st.markdown("""
        <div style='background-color: #e8f5e9; padding: 15px; border-radius: 8px; border-left: 4px solid #4caf50;'>
            <h4 style='color: #2e7d32; margin-top: 0;'>💡 데이터 분석 추천 학습 경로</h4>
            <ul style='color: #1b5e20;'>
                <li><strong>pandas</strong>: 데이터 조작 및 분석</li>
                <li><strong>numpy</strong>: 수치 연산 및 배열 처리</li>
                <li><strong>matplotlib/seaborn</strong>: 데이터 시각화</li>
                <li><strong>Streamlit</strong>: 대시보드 및 데이터 앱 개발</li>
            </ul>
            <p style='color: #2e7d32; margin-bottom: 0;'>이 앱에서 데이터 로딩, 필터링, 시각화 기능을 실습해보세요! 🚀</p>
        </div>
        """, unsafe_allow_html=True)
    
    elif selected_interest == "웹 개발":
        # 웹 개발 선택 시
        st.success("🌐 **웹 개발**을 선택하셨습니다!")
        st.markdown("""
        <div style='background-color: #e3f2fd; padding: 15px; border-radius: 8px; border-left: 4px solid #2196f3;'>
            <h4 style='color: #1565c0; margin-top: 0;'>💡 웹 개발 추천 학습 경로</h4>
            <ul style='color: #0d47a1;'>
                <li><strong>HTML/CSS/JavaScript</strong>: 프론트엔드 기초</li>
                <li><strong>React/Vue</strong>: 현대적인 프론트엔드 프레임워크</li>
                <li><strong>FastAPI/Flask</strong>: 백엔드 API 개발</li>
                <li><strong>Streamlit</strong>: 빠른 프로토타이핑 및 내부 도구 개발</li>
            </ul>
            <p style='color: #1565c0; margin-bottom: 0;'>Streamlit은 Python만으로 웹 앱을 빠르게 만들 수 있는 도구입니다! ⚡</p>
        </div>
        """, unsafe_allow_html=True)
    
    elif selected_interest == "머신러닝":
        # 머신러닝 선택 시
        st.success("🤖 **머신러닝**을 선택하셨습니다!")
        st.markdown("""
        <div style='background-color: #fce4ec; padding: 15px; border-radius: 8px; border-left: 4px solid #e91e63;'>
            <h4 style='color: #c2185b; margin-top: 0;'>💡 머신러닝 추천 학습 경로</h4>
            <ul style='color: #880e4f;'>
                <li><strong>scikit-learn</strong>: 전통적인 머신러닝 알고리즘</li>
                <li><strong>TensorFlow/PyTorch</strong>: 딥러닝 프레임워크</li>
                <li><strong>pandas/numpy</strong>: 데이터 전처리</li>
                <li><strong>Streamlit</strong>: ML 모델 데모 및 시각화</li>
            </ul>
            <p style='color: #c2185b; margin-bottom: 0;'>Streamlit으로 ML 모델의 예측 결과를 인터랙티브하게 시각화해보세요! 🎯</p>
        </div>
        """, unsafe_allow_html=True)
    
    elif selected_interest == "생성형 AI":
        # 생성형 AI 선택 시
        st.success("✨ **생성형 AI**를 선택하셨습니다!")
        st.markdown("""
        <div style='background-color: #fff3e0; padding: 15px; border-radius: 8px; border-left: 4px solid #ff9800;'>
            <h4 style='color: #e65100; margin-top: 0;'>💡 생성형 AI 추천 학습 경로</h4>
            <ul style='color: #bf360c;'>
                <li><strong>OpenAI API</strong>: GPT 모델 활용</li>
                <li><strong>LangChain</strong>: LLM 애플리케이션 개발</li>
                <li><strong>Hugging Face</strong>: 오픈소스 AI 모델</li>
                <li><strong>Streamlit</strong>: AI 챗봇 및 생성형 앱 인터페이스</li>
            </ul>
            <p style='color: #e65100; margin-bottom: 0;'>Streamlit으로 AI 기반 챗봇이나 생성형 도구를 만들어보세요! 🚀</p>
        </div>
        """, unsafe_allow_html=True)
    
    # 추가 정보: 선택한 주제에 대한 통계 (데모용)
    if selected_interest != "주제를 선택하세요":
        st.markdown("---")
        st.caption(f"💡 **팁**: '{selected_interest}' 주제에 대한 더 자세한 정보는 공식 문서를 참고하세요.")

st.markdown("<br>", unsafe_allow_html=True)

# 외부 데이터 불러오기
st.markdown("### 📁 데이터 관리")
# 현재 스크립트 파일의 디렉토리를 기준으로 경로 설정
current_dir = Path(__file__).parent
data_file = current_dir / "data" / "sample_data.csv"

try:
    # 파일 존재 여부 확인
    if data_file.exists():
        # ================================================================
        # 상태 관리: DataFrame을 세션 상태에 저장
        # ================================================================
        # 'df' 키가 세션 상태에 없으면 (첫 실행 또는 초기화 필요 시)
        # CSV 파일에서 데이터를 로드하여 세션 상태에 저장
        # 이후 스크립트가 다시 실행되어도 세션 상태의 데이터가 유지됨
        # ================================================================
        if 'df' not in st.session_state:
            st.session_state.df = pd.read_csv(data_file)
            st.info("ℹ️ 데이터를 처음 로드했습니다. (세션 상태에 저장됨)")
        
        # 세션 상태에서 DataFrame 가져오기 (새로고침해도 유지됨)
        df = st.session_state.df
        
        # 데이터 통계 카드
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("📊 총 데이터 건수", f"{len(df)}건")
        with col2:
            st.metric("👥 고유 이름 수", f"{df['이름'].nunique()}명")
        with col3:
            if '나이' in df.columns:
                st.metric("📈 평균 나이", f"{df['나이'].mean():.1f}세")
        with col4:
            if '도시' in df.columns:
                city_count = df[df['도시'] != '']['도시'].nunique()
                st.metric("🏙️ 도시 수", f"{city_count}개")
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # 데이터 추가 기능
        with st.expander("➕ 새 데이터 추가", expanded=False):
            with st.form("add_data_form"):
                st.markdown("#### 📝 데이터 입력")
                col1, col2 = st.columns(2)
                with col1:
                    new_name = st.text_input("이름 *", placeholder="예: 홍길동", help="필수 입력 항목")
                with col2:
                    new_value = st.number_input("나이 *", min_value=0, step=1, help="필수 입력 항목")
                
                col3, col4 = st.columns(2)
                with col3:
                    new_city = st.text_input("도시", placeholder="예: 서울", help="선택 입력 항목")
                with col4:
                    new_job = st.text_input("직업", placeholder="예: 개발자", help="선택 입력 항목")
                
                add_button = st.form_submit_button("✅ 데이터 추가", use_container_width=True, type="primary")
                
                if add_button:
                    if new_name and new_value:
                        # 새 행 데이터 생성 (기존 컬럼 구조에 맞춤)
                        new_row = {
                            "이름": new_name,
                            "나이": int(new_value),
                            "도시": new_city if new_city else "",
                            "직업": new_job if new_job else ""
                        }
                        # ============================================================
                        # 상태 관리: 세션 상태의 DataFrame에 직접 추가
                        # ============================================================
                        # st.session_state.df에 직접 추가하여 상태를 업데이트
                        # 이렇게 하면 새로고침해도 추가된 데이터가 유지됨
                        # 일반 변수(df)에만 추가하면 스크립트 재실행 시 사라짐
                        # ============================================================
                        new_df = pd.DataFrame([new_row])
                        st.session_state.df = pd.concat([st.session_state.df, new_df], ignore_index=True)
                        df = st.session_state.df  # 로컬 변수도 업데이트
                        
                        # ============================================================
                        # CSV 파일에 데이터 저장
                        # ============================================================
                        # 세션 상태에 추가된 데이터를 CSV 파일에 저장
                        # 이렇게 하면 앱을 종료해도 데이터가 영구적으로 보존됨
                        # ============================================================
                        try:
                            # CSV 파일에 저장 (인덱스 없이 저장)
                            df.to_csv(data_file, index=False, encoding='utf-8-sig')
                            st.success(f"✅ '{new_name}' 데이터가 성공적으로 추가되었습니다! (CSV 파일에 저장됨)")
                        except Exception as e:
                            st.error(f"❌ CSV 파일 저장 중 오류가 발생했습니다: {str(e)}")
                            st.warning("⚠️ 세션 상태에는 저장되었지만 파일 저장에 실패했습니다.")
                        
                        st.rerun()
                    else:
                        st.warning("⚠️ 이름과 나이는 필수 입력 항목입니다.")
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # 데이터 필터링 기능
        st.markdown("### 🔍 데이터 필터링 및 시각화")
        
        # 숫자 컬럼 찾기 (나이 컬럼)
        numeric_column = "나이"
        if numeric_column in df.columns:
            # 필터링 컨테이너
            with st.container():
                # 나이 컬럼의 최소값과 최대값 구하기
                min_age = int(df[numeric_column].min())
                max_age = int(df[numeric_column].max())
                
                # ============================================================
                # 상태 관리: 필터링 범위를 세션 상태에 저장
                # ============================================================
                # 필터링 범위를 세션 상태에 저장하여 새로고침 시에도 유지
                # 사용자가 설정한 필터 범위가 계속 유지됨
                # ============================================================
                if 'age_range' not in st.session_state:
                    st.session_state.age_range = (min_age, max_age)
                
                # 세션 상태에서 필터 범위 가져오기 (없으면 기본값 사용)
                default_range = st.session_state.age_range if 'age_range' in st.session_state else (min_age, max_age)
                
                # 슬라이더로 범위 선택
                st.markdown("#### 🎚️ 나이 범위 선택")
                age_range = st.slider(
                    f"**{numeric_column}** 범위를 선택하세요:",
                    min_value=min_age,
                    max_value=max_age,
                    value=default_range,
                    step=1,
                    help=f"선택 가능한 범위: {min_age}세 ~ {max_age}세"
                )
                
                # 선택한 범위를 세션 상태에 저장
                st.session_state.age_range = age_range
                
                # 필터링 적용
                filtered_df = df[
                    (df[numeric_column] >= age_range[0]) & 
                    (df[numeric_column] <= age_range[1])
                ]
                
                # 필터링 결과 요약
                col1, col2 = st.columns(2)
                with col1:
                    st.info(f"📊 필터링된 데이터: **{len(filtered_df)}건** / 전체 {len(df)}건")
                with col2:
                    if len(filtered_df) > 0:
                        percentage = (len(filtered_df) / len(df)) * 100
                        st.metric("필터링 비율", f"{percentage:.1f}%")
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            # 데이터 시각화 및 표시
            if len(filtered_df) > 0:
                # 탭으로 데이터 테이블과 시각화 분리
                tab1, tab2 = st.tabs(["📋 데이터 테이블", "📊 데이터 시각화"])
                
                with tab1:
                    st.markdown(f"#### 필터링된 데이터 ({len(filtered_df)}건)")
                    st.dataframe(
                        filtered_df,
                        use_container_width=True,
                        hide_index=True
                    )
                
                with tab2:
                    st.markdown("#### 📈 차트 유형 선택")
                    # 시각화 옵션 선택
                    chart_type = st.radio(
                        "차트 유형을 선택하세요:",
                        ["📊 나이 분포 (막대 그래프)", "📈 나이 분포 (선 그래프)", "🏙️ 도시별 분포"],
                        horizontal=True,
                        label_visibility="collapsed"
                    )
                    
                    st.markdown("<br>", unsafe_allow_html=True)
                    
                    if "막대 그래프" in chart_type:
                        # 나이별 개수를 계산하여 막대 그래프로 표시
                        age_counts = filtered_df[numeric_column].value_counts().sort_index()
                        st.bar_chart(age_counts, use_container_width=True)
                        st.caption("📊 나이별 인원 수 분포")
                    
                    elif "선 그래프" in chart_type:
                        # 나이별 개수를 계산하여 선 그래프로 표시
                        age_counts = filtered_df[numeric_column].value_counts().sort_index()
                        st.line_chart(age_counts, use_container_width=True)
                        st.caption("📈 나이별 인원 수 추이")
                    
                    elif "도시별" in chart_type:
                        # 도시별 개수를 계산하여 막대 그래프로 표시
                        if "도시" in filtered_df.columns:
                            city_df = filtered_df[filtered_df["도시"] != ""]
                            if len(city_df) > 0:
                                city_counts = city_df["도시"].value_counts()
                                st.bar_chart(city_counts, use_container_width=True)
                                st.caption("🏙️ 도시별 인원 수 분포")
                            else:
                                st.info("ℹ️ 도시 정보가 없습니다.")
                        else:
                            st.warning("⚠️ 도시 컬럼이 존재하지 않습니다.")
                    
                    # 추가 통계 정보 표시
                    st.markdown("<br>", unsafe_allow_html=True)
                    st.markdown("#### 📊 상세 통계 정보")
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("📊 평균 나이", f"{filtered_df[numeric_column].mean():.1f}세")
                    with col2:
                        st.metric("⬇️ 최소 나이", f"{filtered_df[numeric_column].min()}세")
                    with col3:
                        st.metric("⬆️ 최대 나이", f"{filtered_df[numeric_column].max()}세")
                    with col4:
                        st.metric("📐 중앙값", f"{filtered_df[numeric_column].median():.1f}세")
            else:
                st.warning("⚠️ 필터링된 데이터가 없어 시각화할 수 없습니다.")
        else:
            st.warning(f"⚠️ 숫자 컬럼 '{numeric_column}'을 찾을 수 없습니다.")
            st.dataframe(df, use_container_width=True)
    else:
        st.error(f"❌ 파일을 찾을 수 없습니다: {data_file}")
        st.info("💡 data/sample_data.csv 파일이 존재하는지 확인해주세요.")
except Exception as e:
    st.error(f"❌ 데이터 로딩 중 오류가 발생했습니다: {str(e)}")
    st.exception(e)
