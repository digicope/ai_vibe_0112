# Streamlit 웹 채팅봇

OpenAI API를 사용한 대화형 AI 채팅봇 웹 애플리케이션입니다.

## 기술 스택

- Python 3.11+
- Streamlit
- OpenAI (최신 SDK)
- python-dotenv

## 프로젝트 구조

```
.
├── app.py                 # Streamlit 엔트리 포인트
├── requirements.txt       # Python 패키지 의존성
├── .env.example          # 환경변수 템플릿
├── .env                  # 실제 환경변수 (로컬에서 생성 필요)
├── README.md             # 프로젝트 문서
└── src/
    ├── llm.py            # OpenAI 호출/스트리밍 처리 모듈
    ├── prompts.py        # 시스템 프롬프트/기본 설정
    ├── ui.py             # 채팅 UI 렌더링 함수
    └── utils.py          # 공통 유틸리티 (로깅, 예외 메시지 포맷 등)
```

## 설치 및 실행

### 1. 저장소 클론 및 디렉토리 이동

```bash
cd Streamlit_Web_Chatbot
```

### 2. 가상환경 생성 및 활성화 (권장)

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. 패키지 설치

```bash
pip install -r requirements.txt
```

### 4. 환경변수 설정

`.env.example` 파일을 참고하여 `.env` 파일을 생성하고 OpenAI API 키를 설정합니다:

```bash
# .env.example을 복사하여 .env 생성
cp .env.example .env
```

`.env` 파일 내용:
```
OPENAI_API_KEY=your_openai_api_key_here
```

**중요**: `.env` 파일은 Git에 커밋하지 마세요. 이미 `.gitignore`에 포함되어 있습니다.

### 5. 애플리케이션 실행

```bash
streamlit run app.py
```

브라우저가 자동으로 열리며 채팅봇 인터페이스가 표시됩니다.

## 환경변수

### 필수 환경변수

- `OPENAI_API_KEY`: OpenAI API 키 (필수)
  - [OpenAI Platform](https://platform.openai.com/api-keys)에서 발급받을 수 있습니다.

### 선택적 환경변수

- `OPENAI_MODEL`: 기본 모델 이름 (기본값: `gpt-4o-mini`)

## 기능

### 사이드바 설정

- **모델 선택**: 사용할 OpenAI 모델 선택 (gpt-4o, gpt-4o-mini, gpt-4-turbo, gpt-3.5-turbo)
- **Temperature 슬라이더**: 0.0 ~ 1.0 범위로 조절 가능 (기본값: 0.7)
- **대화 초기화**: 현재 대화 히스토리를 모두 삭제
- **시스템 프롬프트 보기/수정**: AI의 행동과 응답 스타일을 제어하는 프롬프트 수정

### 메인 영역

- **대화 히스토리 표시**: 사용자와 어시스턴트의 메시지를 role별로 구분하여 표시
- **메시지 입력**: 하단의 입력창에서 메시지 입력 및 전송
- **스트리밍 응답**: 어시스턴트 응답이 실시간으로 점진적으로 표시됨
- **오류 처리**: API 오류 발생 시 사용자 친화적인 오류 메시지 표시

## 오류 처리

애플리케이션은 다음과 같은 오류 상황을 처리합니다:

- **API 키 누락/유효하지 않음**: 명확한 안내 메시지 표시
- **Rate Limit**: 사용량 한도 도달 시 안내
- **네트워크 오류**: 연결 문제 안내
- **모델 오류**: 모델 선택 문제 안내
- **기타 오류**: 일반적인 오류 메시지 표시

## 배포 팁

### Streamlit Cloud 배포

1. GitHub 저장소에 코드 푸시
2. [Streamlit Cloud](https://streamlit.io/cloud)에 접속하여 앱 배포
3. 환경변수 설정:
   - Streamlit Cloud 대시보드에서 "Settings" → "Secrets" 선택
   - `OPENAI_API_KEY` 추가

### 다른 플랫폼 배포

- **Heroku**: `Procfile`에 `web: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0` 추가
- **Docker**: Dockerfile 생성 및 컨테이너화
- **AWS/GCP/Azure**: 각 플랫폼의 배포 가이드 참조

## 개발 팁

- 로그는 콘솔에 출력되며, 오류 발생 시 `src/utils.py`의 `format_error_message` 함수가 사용자 친화적인 메시지로 변환합니다.
- 세션 상태는 `st.session_state`에 저장되며, 페이지 새로고침 시에도 유지됩니다.
- 스트리밍은 OpenAI의 `stream=True` 옵션을 사용하여 구현되었습니다.

## 라이선스

이 프로젝트는 MIT 라이선스를 따릅니다.
