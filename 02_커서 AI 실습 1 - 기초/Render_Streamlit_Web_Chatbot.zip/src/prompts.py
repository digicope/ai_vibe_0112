"""시스템 프롬프트 및 기본 설정 모듈"""
import os
from typing import Dict, Any

# 기본 시스템 프롬프트
DEFAULT_SYSTEM_PROMPT = """당신은 친절하고 도움이 되는 AI 어시스턴트입니다. 
사용자의 질문에 정확하고 유용한 답변을 제공하세요."""

# 기본 모델 설정 (환경변수에서 가져오거나 기본값 사용)
DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

# 기본 temperature 설정
DEFAULT_TEMPERATURE = 0.7


def get_default_config() -> Dict[str, Any]:
    """
    기본 설정 딕셔너리 반환
    
    Returns:
        기본 설정이 포함된 딕셔너리
    """
    return {
        "model": DEFAULT_MODEL,
        "temperature": DEFAULT_TEMPERATURE,
        "system_prompt": DEFAULT_SYSTEM_PROMPT
    }
