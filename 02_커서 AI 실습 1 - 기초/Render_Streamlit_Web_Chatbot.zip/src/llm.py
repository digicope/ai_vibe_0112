"""OpenAI API 호출 및 스트리밍 처리 모듈"""
import os
from typing import List, Dict, Optional, Iterator
from openai import OpenAI
# from dotenv import load_dotenv
import streamlit as st

from src.utils import format_error_message, validate_api_key, logger

# 환경변수 로드
# load_dotenv()


def get_openai_client() -> Optional[OpenAI]:
    """
    OpenAI 클라이언트 생성
    
    Returns:
        OpenAI 클라이언트 객체 또는 None (API 키가 없을 경우)
    """
    api_key = os.getenv("OPENAI_API_KEY")
    
    if not validate_api_key(api_key):
        return None
    
    return OpenAI(api_key=api_key)


def create_messages(system_prompt: str, conversation_history: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """
    OpenAI API에 전달할 messages 리스트 생성
    
    Args:
        system_prompt: 시스템 프롬프트
        conversation_history: 대화 히스토리 (role, content 포함)
        
    Returns:
        OpenAI API 형식의 messages 리스트
    """
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(conversation_history)
    return messages


def stream_chat_completion(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float
) -> Iterator[str]:
    """
    OpenAI API를 사용한 스트리밍 채팅 완성
    
    Args:
        messages: 대화 메시지 리스트
        model: 사용할 모델 이름
        temperature: temperature 값
        
    Yields:
        스트리밍된 텍스트 청크
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    
    if client is None:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다.")
    
    try:
        stream = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            stream=True
        )
        
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                yield chunk.choices[0].delta.content
                
    except Exception as e:
        logger.error(f"OpenAI API 호출 오류: {e}")
        raise


def get_chat_completion(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float
) -> str:
    """
    OpenAI API를 사용한 채팅 완성 (비스트리밍)
    
    Args:
        messages: 대화 메시지 리스트
        model: 사용할 모델 이름
        temperature: temperature 값
        
    Returns:
        완성된 응답 텍스트
        
    Raises:
        Exception: API 호출 실패 시
    """
    client = get_openai_client()
    
    if client is None:
        raise ValueError("OpenAI API 키가 설정되지 않았습니다.")
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logger.error(f"OpenAI API 호출 오류: {e}")
        raise
