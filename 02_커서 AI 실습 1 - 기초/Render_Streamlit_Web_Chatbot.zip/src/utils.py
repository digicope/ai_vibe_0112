"""공통 유틸리티 함수 모듈"""
import logging
from typing import Optional

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def format_error_message(error: Exception) -> str:
    """
    OpenAI API 오류를 사용자 친화적인 메시지로 변환
    
    Args:
        error: 발생한 예외 객체
        
    Returns:
        사용자 친화적인 오류 메시지
    """
    error_str = str(error).lower()
    
    # API 키 관련 오류
    if 'api key' in error_str or 'authentication' in error_str or 'invalid' in error_str:
        return "❌ OpenAI API 키가 유효하지 않습니다. .env 파일의 OPENAI_API_KEY를 확인해주세요."
    
    # Rate limit 오류
    if 'rate limit' in error_str or 'quota' in error_str:
        return "⏱️ API 사용량 한도에 도달했습니다. 잠시 후 다시 시도해주세요."
    
    # 네트워크 오류
    if 'connection' in error_str or 'network' in error_str or 'timeout' in error_str:
        return "🌐 네트워크 연결 오류가 발생했습니다. 인터넷 연결을 확인해주세요."
    
    # 모델 관련 오류
    if 'model' in error_str and ('not found' in error_str or 'invalid' in error_str):
        return "🤖 선택한 모델을 사용할 수 없습니다. 다른 모델을 선택해주세요."
    
    # 기타 오류
    return f"❌ 오류가 발생했습니다: {str(error)}"


def validate_api_key(api_key: Optional[str]) -> bool:
    """
    API 키 유효성 검사
    
    Args:
        api_key: 검사할 API 키
        
    Returns:
        유효하면 True, 그렇지 않으면 False
    """
    if not api_key:
        return False
    if not api_key.strip():
        return False
    # 예제 키인 경우
    if api_key.startswith('your_'):
        return False
    # 실제 API 키는 'sk-'로 시작해야 함
    if not api_key.startswith('sk-'):
        return False
    return True
