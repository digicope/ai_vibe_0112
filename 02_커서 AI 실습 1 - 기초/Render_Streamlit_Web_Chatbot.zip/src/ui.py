"""채팅 UI 렌더링 함수 모듈"""
import streamlit as st
from typing import List, Dict, Optional

from src.llm import stream_chat_completion, create_messages
from src.utils import format_error_message, logger


def render_message(message: Dict[str, str]):
    """
    단일 메시지를 role에 따라 렌더링
    
    Args:
        message: role과 content를 포함한 메시지 딕셔너리
    """
    role = message.get("role", "user")
    content = message.get("content", "")
    
    if role == "user":
        with st.chat_message("user"):
            st.write(content)
    elif role == "assistant":
        with st.chat_message("assistant"):
            st.write(content)


def render_chat_history(messages: List[Dict[str, str]]):
    """
    대화 히스토리 전체를 렌더링
    
    Args:
        messages: 대화 메시지 리스트
    """
    for message in messages:
        render_message(message)


def render_streaming_response(
    messages: List[Dict[str, str]],
    model: str,
    temperature: float
) -> str:
    """
    스트리밍 응답을 렌더링하고 완성된 텍스트 반환
    
    Args:
        messages: 대화 메시지 리스트
        model: 사용할 모델 이름
        temperature: temperature 값
        
    Returns:
        완성된 응답 텍스트
    """
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""
        
        try:
            for chunk in stream_chat_completion(messages, model, temperature):
                full_response += chunk
                message_placeholder.write(full_response + "▌")
            
            # 스트리밍 완료 후 최종 텍스트 표시
            message_placeholder.write(full_response)
            
        except Exception as e:
            error_msg = format_error_message(e)
            message_placeholder.error(error_msg)
            logger.error(f"스트리밍 오류: {e}")
            raise
    
    return full_response


def render_sidebar(
    default_model: str,
    default_temperature: float,
    default_system_prompt: str
) -> tuple[str, float, str]:
    """
    사이드바 UI 렌더링 및 설정값 반환
    
    Args:
        default_model: 기본 모델 이름
        default_temperature: 기본 temperature 값
        default_system_prompt: 기본 시스템 프롬프트
        
    Returns:
        (model, temperature, system_prompt) 튜플
    """
    with st.sidebar:
        st.header("⚙️ 설정")
        
        # 모델 선택
        model = st.selectbox(
            "모델 선택",
            options=["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"],
            index=["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"].index(default_model) 
            if default_model in ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"] 
            else 1
        )
        
        # Temperature 슬라이더
        temperature = st.slider(
            "Temperature",
            min_value=0.0,
            max_value=1.0,
            value=default_temperature,
            step=0.1,
            help="값이 높을수록 더 창의적인 응답을 생성합니다."
        )
        
        st.divider()
        
        # 대화 초기화 버튼
        if st.button("🗑️ 대화 초기화", use_container_width=True):
            st.session_state.messages = []
            st.rerun()
        
        st.divider()
        
        # 시스템 프롬프트 보기/수정
        st.subheader("시스템 프롬프트")
        system_prompt = st.text_area(
            "시스템 프롬프트를 수정할 수 있습니다.",
            value=default_system_prompt,
            height=200,
            help="AI의 행동과 응답 스타일을 제어하는 프롬프트입니다."
        )
    
    return model, temperature, system_prompt
