"""Streamlit 웹 채팅봇 엔트리 포인트"""
import streamlit as st
import os
# from dotenv import load_dotenv

from src.prompts import get_default_config, DEFAULT_SYSTEM_PROMPT, DEFAULT_MODEL, DEFAULT_TEMPERATURE
from src.ui import render_sidebar, render_chat_history, render_streaming_response
from src.llm import create_messages
from src.utils import validate_api_key, format_error_message, logger

# 환경변수 로드
# load_dotenv()

# 페이지 설정
st.set_page_config(
    page_title="AI 채팅봇",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# 세션 상태 초기화
if "messages" not in st.session_state:
    st.session_state.messages = []

if "system_prompt" not in st.session_state:
    default_config = get_default_config()
    st.session_state.system_prompt = default_config["system_prompt"]

if "model" not in st.session_state:
    default_config = get_default_config()
    st.session_state.model = default_config["model"]

if "temperature" not in st.session_state:
    default_config = get_default_config()
    st.session_state.temperature = default_config["temperature"]

# API 키 검증
api_key = os.getenv("OPENAI_API_KEY")
if not validate_api_key(api_key):
    st.error("⚠️ OpenAI API 키가 설정되지 않았습니다. .env 파일에 OPENAI_API_KEY를 설정해주세요.")
    st.stop()

# 사이드바 렌더링 및 설정값 업데이트
model, temperature, system_prompt = render_sidebar(
    st.session_state.model,
    st.session_state.temperature,
    st.session_state.system_prompt
)

# 사이드바에서 변경된 설정값을 세션 상태에 반영
st.session_state.model = model
st.session_state.temperature = temperature
st.session_state.system_prompt = system_prompt

# 메인 영역
st.title("🤖 AI 채팅봇")
st.caption("OpenAI API를 사용한 대화형 AI 어시스턴트")

# 기존 대화 히스토리 렌더링
if st.session_state.messages:
    render_chat_history(st.session_state.messages)

# 사용자 입력 처리
if prompt := st.chat_input("메시지를 입력하세요..."):
    # 사용자 메시지를 즉시 화면에 반영
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.write(prompt)
    
    # 어시스턴트 응답 생성 및 스트리밍
    try:
        messages = create_messages(
            st.session_state.system_prompt,
            st.session_state.messages
        )
        
        # 스트리밍 응답 렌더링
        full_response = render_streaming_response(
            messages,
            st.session_state.model,
            st.session_state.temperature
        )
        
        # 응답을 세션 상태에 추가
        st.session_state.messages.append({
            "role": "assistant",
            "content": full_response
        })
        
    except Exception as e:
        error_msg = format_error_message(e)
        st.error(error_msg)
        logger.error(f"응답 생성 오류: {e}")
