<?php
require_once 'db_config.php';

// 데이터베이스 연결
$conn = getDBConnection();

// 사용자 테이블 생성 SQL
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    reg_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

if ($conn->query($sql) === TRUE) {
    echo "테이블 생성 완료";
} else {
    echo "테이블 생성 오류: " . $conn->error;
}

$conn->close();
?>
