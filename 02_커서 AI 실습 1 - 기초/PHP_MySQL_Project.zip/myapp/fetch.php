<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_config.php';

// 데이터베이스 연결
$conn = getDBConnection();

// users 테이블의 전체 데이터 조회
$sql = "SELECT id, name, email, age, DATE_FORMAT(reg_date, '%Y-%m-%d') as reg_date 
        FROM users 
        ORDER BY id DESC";

$result = $conn->query($sql);

if ($result) {
    $users = [];
    
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    
    echo json_encode($users, JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['error' => '데이터 조회 오류: ' . $conn->error], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
