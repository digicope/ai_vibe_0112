<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_config.php';

// POST 데이터 받기
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;

// 입력 검증
if ($id <= 0) {
    echo json_encode(['message' => '유효하지 않은 ID'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 데이터베이스 연결
$conn = getDBConnection();

// 사용자 삭제
$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    echo json_encode(['message' => '삭제 완료'], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['message' => '삭제 실패'], JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
?>
