# Dothome 무료 호스팅 배포 가이드

이 가이드는 PHP + MySQL 사용자 관리 웹앱을 dothome.co.kr 무료 호스팅에 업로드하는 단계별 절차를 설명합니다.

## 📋 사전 준비사항

1. **Dothome 계정 및 접속 정보**
   - 호스팅 계정 ID
   - FTP 접속 정보 (호스트, 사용자명, 비밀번호)
   - phpMyAdmin 접속 정보

2. **필요한 파일**
   - 모든 프로젝트 파일 (`myapp` 폴더 내의 모든 파일)

---

## 1단계: 데이터베이스 및 테이블 생성

### 1.1 phpMyAdmin 접속

1. Dothome 호스팅 관리 페이지에 로그인
2. **데이터베이스** 또는 **phpMyAdmin** 메뉴 클릭
3. phpMyAdmin 접속

### 1.2 데이터베이스 선택/확인

1. 왼쪽 사이드바에서 데이터베이스 목록 확인
2. `digicope` 데이터베이스가 있는지 확인
   - 없으면 Dothome 관리 페이지에서 데이터베이스 생성 필요

### 1.3 테이블 생성 방법 1: SQL 실행

1. phpMyAdmin에서 `digicope` 데이터베이스 선택
2. 상단 메뉴에서 **SQL** 탭 클릭
3. 다음 SQL 쿼리를 입력:

```sql
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    reg_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

4. **실행** 버튼 클릭
5. "테이블이 생성되었습니다" 메시지 확인

### 1.4 테이블 생성 방법 2: create_table.php 실행

1. FTP로 `create_table.php` 파일을 먼저 업로드
2. 브라우저에서 `http://yourdomain.dothome.co.kr/myapp/create_table.php` 접속
3. "테이블 생성 완료" 메시지 확인

---

## 2단계: 샘플 데이터 삽입 (seed_data.php)

### 2.1 파일 업로드

1. FTP로 `seed_data.php` 파일 업로드 (3단계 참조)

### 2.2 샘플 데이터 실행

1. 브라우저에서 다음 URL 접속:
   ```
   http://yourdomain.dothome.co.kr/myapp/seed_data.php
   ```

2. 화면에 다음 메시지가 표시되면 성공:
   ```
   추가됨: 김민수 (minsu123@example.com, 25세)
   추가됨: 박지연 (jiyeon456@example.com, 30세)
   ...
   === 샘플 데이터 삽입 완료 ===
   추가된 사용자: 10명
   ```

### 2.3 데이터 확인

1. phpMyAdmin에서 `users` 테이블 선택
2. **보기** 탭 클릭하여 10명의 사용자 데이터 확인

---

## 3단계: FTP를 통한 파일 업로드

### 3.1 FTP 클라이언트 준비

**추천 FTP 클라이언트:**
- **FileZilla** (무료, 크로스 플랫폼)
- **WinSCP** (Windows)
- **Cyberduck** (Mac)

### 3.2 FTP 접속 정보

Dothome 호스팅 관리 페이지에서 확인:
- **호스트**: `ftp.dothome.co.kr` 또는 제공된 FTP 주소
- **포트**: `21` (일반적으로)
- **사용자명**: 호스팅 계정 ID
- **비밀번호**: FTP 비밀번호

### 3.3 FTP 연결

1. FTP 클라이언트 실행
2. 새 연결 생성:
   - 호스트: `ftp.dothome.co.kr`
   - 사용자명: `your_account_id`
   - 비밀번호: `your_ftp_password`
   - 포트: `21`
3. **연결** 버튼 클릭

### 3.4 파일 업로드

1. **로컬 폴더** (왼쪽): `C:\AI_Cursor_Lab\PHP_MySQL_Project\myapp` 선택
2. **원격 폴더** (오른쪽): `public_html` 또는 `www` 폴더로 이동
3. `myapp` 폴더 생성 (또는 원하는 폴더명)
4. 다음 파일들을 업로드:

```
📁 myapp/
 ├── index.html
 ├── style.css
 ├── script.js
 ├── db_config.php
 ├── create_table.php
 ├── insert.php
 ├── fetch.php
 ├── update.php
 ├── delete.php
 ├── seed_data.php
 └── export_csv.php
```

**업로드 순서:**
1. 먼저 `db_config.php` 업로드 (데이터베이스 설정 확인)
2. `create_table.php` 업로드 및 실행 (테이블 생성)
3. `seed_data.php` 업로드 및 실행 (샘플 데이터)
4. 나머지 모든 파일 업로드

### 3.5 파일 권한 확인

일반적으로 PHP 파일은 `644` 권한이면 충분합니다.
- 필요시 FTP 클라이언트에서 파일 우클릭 → **파일 권한** → `644` 설정

---

## 4단계: 설정 확인 및 테스트

### 4.1 db_config.php 확인

업로드된 `db_config.php` 파일이 올바른 설정을 가지고 있는지 확인:

```php
$host = "localhost";
$user = "digicope";
$pass = "pass01**";
$dbname = "digicope";
```

### 4.2 웹사이트 접속 테스트

1. 브라우저에서 메인 페이지 접속:
   ```
   http://yourdomain.dothome.co.kr/myapp/index.html
   ```

2. 다음 기능 테스트:
   - ✅ 사용자 목록이 표시되는지 확인
   - ✅ 새 사용자 추가 기능 테스트
   - ✅ 사용자 수정 기능 테스트
   - ✅ 사용자 삭제 기능 테스트

### 4.3 오류 발생 시 확인사항

**문제: 데이터베이스 연결 오류**
- `db_config.php`의 접속 정보 확인
- phpMyAdmin에서 데이터베이스와 사용자 존재 확인

**문제: 테이블이 없다는 오류**
- `create_table.php` 실행 확인
- phpMyAdmin에서 `users` 테이블 존재 확인

**문제: 파일을 찾을 수 없음**
- FTP 업로드 경로 확인 (`public_html/myapp/` 또는 `www/myapp/`)
- 파일명 대소문자 확인 (Linux 서버는 대소문자 구분)

**문제: 한글이 깨짐**
- 파일 인코딩이 UTF-8인지 확인
- 데이터베이스 문자셋이 `utf8mb4`인지 확인

---

## 5단계: 보안 고려사항

### 5.1 seed_data.php 제거 (선택사항)

배포 후에는 샘플 데이터 생성 파일을 삭제하거나 보호하는 것을 권장합니다:

```php
// seed_data.php 파일 상단에 추가
if ($_SERVER['REMOTE_ADDR'] !== 'your_ip_address') {
    die('Access Denied');
}
```

또는 파일명을 변경하거나 `.htaccess`로 접근 제한

### 5.2 db_config.php 보안

민감한 정보가 포함된 파일이므로:
- 웹에서 직접 접근 불가능한 위치로 이동 고려
- 또는 `.htaccess`로 접근 제한

---

## 📝 체크리스트

배포 전 확인사항:

- [ ] Dothome 호스팅 계정 활성화
- [ ] 데이터베이스 `digicope` 생성 확인
- [ ] FTP 접속 정보 확인
- [ ] `db_config.php` 설정 확인
- [ ] `create_table.php` 실행하여 테이블 생성
- [ ] `seed_data.php` 실행하여 샘플 데이터 삽입
- [ ] 모든 파일 FTP 업로드 완료
- [ ] 메인 페이지 접속 테스트
- [ ] CRUD 기능 모두 테스트
- [ ] 오류 없이 정상 작동 확인

---

## 🔗 유용한 링크

- **Dothome 공식 사이트**: https://www.dothome.co.kr
- **FileZilla 다운로드**: https://filezilla-project.org
- **phpMyAdmin 문서**: https://www.phpmyadmin.net/docs/

---

## 💡 추가 팁

1. **백업**: 배포 전 로컬 파일 백업
2. **버전 관리**: Git을 사용하여 코드 버전 관리
3. **로컬 테스트**: XAMPP나 WAMP로 로컬에서 먼저 테스트
4. **에러 로그**: 문제 발생 시 Dothome 호스팅 관리 페이지의 에러 로그 확인

---

**문제가 발생하면:**
1. Dothome 고객센터에 문의
2. 에러 메시지를 정확히 기록
3. phpMyAdmin에서 데이터베이스 상태 확인
