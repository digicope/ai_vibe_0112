<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_config.php';

// POST 데이터 받기
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$age = isset($_POST['age']) ? intval($_POST['age']) : 0;

// 입력 검증
if (empty($name) || empty($email) || $age <= 0) {
    echo json_encode(['status' => 'error'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 이메일 형식 검증
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['status' => 'error'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 데이터베이스 연결
$conn = getDBConnection();

// SQL 준비 및 실행
$stmt = $conn->prepare("INSERT INTO users (name, email, age) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $name, $email, $age);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success'], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['status' => 'error'], JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
?>
