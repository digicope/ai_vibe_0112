<?php
require_once 'db_config.php';

// 데이터베이스 연결
$conn = getDBConnection();

// users 테이블의 모든 데이터 조회
$sql = "SELECT id, name, email, age, DATE_FORMAT(reg_date, '%Y-%m-%d') as reg_date 
        FROM users 
        ORDER BY id DESC";

$result = $conn->query($sql);

// 날짜 형식으로 파일명 생성 (예: users_2024-01-19.csv)
$date = date('Y-m-d');
$filename = "users_{$date}.csv";

// CSV 헤더 설정
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// 출력 버퍼 시작
$output = fopen('php://output', 'w');

// BOM 추가 (한글 깨짐 방지)
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// CSV 헤더 작성
fputcsv($output, ['ID', '이름', '이메일', '나이', '등록일']);

// 데이터 작성
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['id'],
            $row['name'],
            $row['email'],
            $row['age'],
            $row['reg_date']
        ]);
    }
}

fclose($output);
$conn->close();
exit;
?>
