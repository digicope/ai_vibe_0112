<?php
// 데이터베이스 연결 설정 (dothome.co.kr 무료 호스팅 환경)
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "sample_db";

// 데이터베이스 연결 함수
function getDBConnection() {
    global $host, $user, $pass, $dbname;
    
    // 에러 보고 활성화 (개발 환경)
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
    // MySQLi 연결 시도
    $conn = @new mysqli($host, $user, $pass, $dbname);
    
    // 연결 오류 확인
    if ($conn->connect_error) {
        $error_msg = "데이터베이스 연결 실패: " . $conn->connect_error . " (에러 코드: " . $conn->connect_errno . ")";
        
        // 에러 로그 기록
        error_log($error_msg);
        
        // 사용자에게 에러 메시지 출력
        die(json_encode([
            'success' => false,
            'message' => $error_msg
        ], JSON_UNESCAPED_UNICODE));
    }
    
    // UTF-8 인코딩 설정
    if (!$conn->set_charset("utf8mb4")) {
        $error_msg = "문자 인코딩 설정 실패: " . $conn->error;
        error_log($error_msg);
        die(json_encode([
            'success' => false,
            'message' => $error_msg
        ], JSON_UNESCAPED_UNICODE));
    }
    
    return $conn;
}

// 연결 테스트 함수 (선택사항)
function testDBConnection() {
    try {
        $conn = getDBConnection();
        if ($conn) {
            echo "데이터베이스 연결 성공!<br>";
            echo "서버 정보: " . $conn->server_info . "<br>";
            echo "호스트 정보: " . $conn->host_info . "<br>";
            $conn->close();
            return true;
        }
    } catch (Exception $e) {
        echo "연결 테스트 실패: " . $e->getMessage();
        return false;
    }
}
?>
