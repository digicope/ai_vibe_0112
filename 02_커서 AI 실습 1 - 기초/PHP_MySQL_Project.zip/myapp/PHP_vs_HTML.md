# PHP와 HTML의 차이점 가이드

이 문서는 PHP와 HTML의 주요 차이점과 각각의 특징을 설명합니다.

---

## 📋 목차

1. [기본 개념](#기본-개념)
2. [주요 차이점](#주요-차이점)
3. [언어 특성](#언어-특성)
4. [실행 방식](#실행-방식)
5. [사용 예제](#사용-예제)
6. [언제 무엇을 사용할까?](#언제-무엇을-사용할까)

---

## 기본 개념

### HTML (HyperText Markup Language)

- **정의**: 웹 페이지의 구조와 내용을 정의하는 마크업 언어
- **역할**: 정적(Static) 웹 페이지 생성
- **확장자**: `.html`, `.htm`
- **실행**: 웹 브라우저에서 직접 실행

### PHP (PHP: Hypertext Preprocessor)

- **정의**: 서버 측에서 실행되는 프로그래밍 언어
- **역할**: 동적(Dynamic) 웹 페이지 생성
- **확장자**: `.php`
- **실행**: 웹 서버에서 처리 후 HTML로 변환되어 브라우저에 전송

---

## 주요 차이점

| 구분 | HTML | PHP |
|------|------|-----|
| **언어 유형** | 마크업 언어 | 프로그래밍 언어 |
| **실행 위치** | 클라이언트 (브라우저) | 서버 |
| **처리 방식** | 정적 처리 | 동적 처리 |
| **데이터베이스** | 직접 연결 불가 | 연결 가능 |
| **변수 사용** | 불가능 | 가능 |
| **조건문/반복문** | 제한적 (JavaScript 필요) | 완전 지원 |
| **파일 처리** | 불가능 | 가능 |
| **세션/쿠키** | JavaScript 필요 | 직접 처리 |
| **보안** | 클라이언트 측 (소스 노출) | 서버 측 (소스 숨김) |

---

## 언어 특성

### HTML의 특징

#### ✅ 장점
- **간단함**: 배우기 쉬운 문법
- **직접 실행**: 브라우저에서 바로 확인 가능
- **빠른 로딩**: 서버 처리 없이 즉시 표시
- **표준화**: 모든 브라우저에서 지원

#### ❌ 단점
- **정적 콘텐츠**: 내용 변경 시 파일 수정 필요
- **상호작용 제한**: 사용자 입력 처리 어려움
- **데이터베이스 연결 불가**: 동적 데이터 처리 불가능
- **보안 취약**: 소스 코드가 노출됨

### PHP의 특징

#### ✅ 장점
- **동적 콘텐츠**: 데이터베이스와 연동하여 실시간 데이터 표시
- **서버 측 처리**: 보안이 강화됨
- **풍부한 기능**: 파일 처리, 이메일 전송, 세션 관리 등
- **데이터베이스 연동**: MySQL, PostgreSQL 등과 쉽게 연동
- **코드 재사용**: 함수, 클래스로 모듈화 가능

#### ❌ 단점
- **서버 필요**: 웹 서버 환경 필요
- **처리 시간**: 서버에서 처리하므로 약간의 지연 가능
- **학습 곡선**: 프로그래밍 지식 필요

---

## 실행 방식

### HTML 실행 흐름

```
1. 사용자가 브라우저에서 HTML 파일 요청
   ↓
2. 웹 서버가 HTML 파일을 그대로 전송
   ↓
3. 브라우저가 HTML을 해석하여 화면에 표시
```

**예시:**
```html
<!-- index.html -->
<!DOCTYPE html>
<html>
<head>
    <title>안녕하세요</title>
</head>
<body>
    <h1>안녕하세요!</h1>
    <p>오늘은 2024년 1월 19일입니다.</p>
</body>
</html>
```

**결과**: 항상 같은 내용이 표시됨 (날짜가 하드코딩됨)

### PHP 실행 흐름

```
1. 사용자가 브라우저에서 PHP 파일 요청
   ↓
2. 웹 서버가 PHP 엔진에 파일 전달
   ↓
3. PHP 엔진이 코드를 실행하고 HTML로 변환
   ↓
4. 변환된 HTML을 브라우저에 전송
   ↓
5. 브라우저가 HTML을 해석하여 화면에 표시
```

**예시:**
```php
<!-- index.php -->
<!DOCTYPE html>
<html>
<head>
    <title>안녕하세요</title>
</head>
<body>
    <h1>안녕하세요!</h1>
    <p>오늘은 <?php echo date('Y년 m월 d일'); ?>입니다.</p>
    <p>현재 시간: <?php echo date('H:i:s'); ?></p>
</body>
</html>
```

**결과**: 현재 날짜와 시간이 실시간으로 표시됨

---

## 사용 예제

### 예제 1: 간단한 텍스트 출력

#### HTML
```html
<!DOCTYPE html>
<html>
<body>
    <h1>사용자 이름: 홍길동</h1>
    <p>이메일: hong@example.com</p>
</body>
</html>
```
- 항상 같은 이름과 이메일이 표시됨

#### PHP
```php
<!DOCTYPE html>
<html>
<body>
    <?php
    $name = "홍길동";
    $email = "hong@example.com";
    ?>
    <h1>사용자 이름: <?php echo $name; ?></h1>
    <p>이메일: <?php echo $email; ?></p>
</body>
</html>
```
- 변수를 사용하여 동적으로 변경 가능

### 예제 2: 조건문 사용

#### HTML (JavaScript 필요)
```html
<!DOCTYPE html>
<html>
<body>
    <p id="message"></p>
    <script>
        var hour = new Date().getHours();
        if (hour < 12) {
            document.getElementById('message').innerHTML = '좋은 아침입니다!';
        } else {
            document.getElementById('message').innerHTML = '좋은 오후입니다!';
        }
    </script>
</body>
</html>
```

#### PHP
```php
<!DOCTYPE html>
<html>
<body>
    <p>
    <?php
    $hour = date('H');
    if ($hour < 12) {
        echo '좋은 아침입니다!';
    } else {
        echo '좋은 오후입니다!';
    }
    ?>
    </p>
</body>
</html>
```

### 예제 3: 반복문 사용

#### HTML (JavaScript 필요)
```html
<!DOCTYPE html>
<html>
<body>
    <ul id="list"></ul>
    <script>
        var items = ['사과', '바나나', '오렌지'];
        var html = '';
        for (var i = 0; i < items.length; i++) {
            html += '<li>' + items[i] + '</li>';
        }
        document.getElementById('list').innerHTML = html;
    </script>
</body>
</html>
```

#### PHP
```php
<!DOCTYPE html>
<html>
<body>
    <ul>
    <?php
    $items = ['사과', '바나나', '오렌지'];
    foreach ($items as $item) {
        echo '<li>' . $item . '</li>';
    }
    ?>
    </ul>
</body>
</html>
```

### 예제 4: 데이터베이스 연동

#### HTML
```html
<!-- 불가능: HTML만으로는 데이터베이스 연결 불가 -->
<!DOCTYPE html>
<html>
<body>
    <p>데이터베이스에서 데이터를 가져올 수 없습니다.</p>
</body>
</html>
```

#### PHP
```php
<!DOCTYPE html>
<html>
<body>
    <table>
        <tr>
            <th>이름</th>
            <th>이메일</th>
        </tr>
    <?php
    require_once 'db_config.php';
    $conn = getDBConnection();
    
    $result = $conn->query("SELECT name, email FROM users");
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['name'] . '</td>';
        echo '<td>' . $row['email'] . '</td>';
        echo '</tr>';
    }
    $conn->close();
    ?>
    </table>
</body>
</html>
```

---

## 언제 무엇을 사용할까?

### HTML을 사용하는 경우

✅ **정적 웹사이트**
- 회사 소개 페이지
- 포트폴리오 사이트
- 랜딩 페이지
- 정적인 문서 사이트

✅ **단순한 구조**
- 복잡한 로직이 필요 없는 경우
- 빠른 프로토타이핑

✅ **클라이언트 측 처리**
- JavaScript와 함께 사용하여 클라이언트 측에서 처리

### PHP를 사용하는 경우

✅ **동적 웹사이트**
- 사용자 관리 시스템
- 쇼핑몰
- 블로그
- 소셜 미디어 플랫폼

✅ **데이터베이스 연동**
- 사용자 정보 저장/조회
- 게시판
- 댓글 시스템

✅ **서버 측 처리**
- 폼 데이터 처리
- 파일 업로드
- 이메일 전송
- 세션 관리

✅ **보안이 중요한 경우**
- 로그인 시스템
- 관리자 페이지
- 개인정보 처리

---

## HTML과 PHP의 조합

실제 웹 개발에서는 HTML과 PHP를 함께 사용합니다:

```php
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title><?php echo $pageTitle; ?></title>
    <!-- HTML로 구조 정의 -->
</head>
<body>
    <!-- HTML로 레이아웃 구성 -->
    <header>
        <h1>사용자 관리 시스템</h1>
    </header>
    
    <main>
        <!-- PHP로 동적 데이터 처리 -->
        <?php
        require_once 'db_config.php';
        $conn = getDBConnection();
        $result = $conn->query("SELECT * FROM users");
        
        // HTML로 데이터 표시
        echo '<table>';
        echo '<tr><th>이름</th><th>이메일</th></tr>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['name']) . '</td>';
            echo '<td>' . htmlspecialchars($row['email']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
        $conn->close();
        ?>
    </main>
    
    <footer>
        <!-- HTML로 푸터 구성 -->
        <p>&copy; 2024 All rights reserved</p>
    </footer>
</body>
</html>
```

**핵심 포인트:**
- **HTML**: 페이지의 구조와 레이아웃 정의
- **PHP**: 동적 데이터 처리 및 로직 구현
- **조합**: HTML 구조 안에 PHP 코드를 삽입하여 동적 콘텐츠 생성

---

## 요약

| 항목 | HTML | PHP |
|------|------|-----|
| **목적** | 웹 페이지 구조 정의 | 서버 측 로직 처리 |
| **실행** | 브라우저 | 서버 |
| **데이터** | 정적 (하드코딩) | 동적 (데이터베이스) |
| **사용** | 모든 웹 페이지 | 동적 기능이 필요한 경우 |
| **학습 난이도** | 쉬움 | 중간 |
| **보안** | 클라이언트 측 | 서버 측 |

**결론**: 
- **HTML**은 웹 페이지의 뼈대와 구조를 만듭니다.
- **PHP**는 그 구조 안에 동적인 기능과 데이터를 추가합니다.
- 현대 웹 개발에서는 두 가지를 함께 사용하여 완전한 웹 애플리케이션을 만듭니다.

---

## 추가 학습 자료

- **HTML 학습**: [MDN Web Docs - HTML](https://developer.mozilla.org/ko/docs/Web/HTML)
- **PHP 학습**: [PHP 공식 문서](https://www.php.net/manual/kr/)
- **실습**: 이 프로젝트의 `index.html`과 PHP 파일들을 비교해보세요!

---

**작성일**: 2024년 1월 19일  
**프로젝트**: PHP + MySQL 사용자 관리 시스템
