// 페이지 로드 시 사용자 목록 불러오기
document.addEventListener('DOMContentLoaded', function() {
    fetchUsers();
    
    // 폼 제출 이벤트
    document.getElementById('user-form').addEventListener('submit', handleFormSubmit);
    
    // 취소 버튼 이벤트
    document.getElementById('cancel-btn').addEventListener('click', resetForm);
});

// 사용자 목록 가져오기
async function fetchUsers() {
    try {
        const response = await fetch('fetch.php');
        const users = await response.json();
        
        const usersList = document.getElementById('users-list');
        
        // 배열인지 확인 (에러 객체가 아닌 경우)
        if (Array.isArray(users)) {
            if (users.length === 0) {
                usersList.innerHTML = '<p class="empty-message">사용자 목록을 불러올 수 없습니다.</p>';
            } else {
                displayUsers(users);
            }
        } else {
            usersList.innerHTML = `<p class="error-message">사용자 목록을 불러올 수 없습니다.</p>`;
        }
    } catch (error) {
        document.getElementById('users-list').innerHTML = 
            `<p class="error-message">오류 발생: ${error.message}</p>`;
    }
}

// 사용자 목록 표시
function displayUsers(users) {
    const usersList = document.getElementById('users-list');
    
    let html = `
        <table class="users-table">
            <thead>
                <tr>
                    <th>이름</th>
                    <th>이메일</th>
                    <th>나이</th>
                    <th>등록일</th>
                    <th>작업</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    users.forEach((user) => {
        html += `
            <tr>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.age}</td>
                <td>${user.reg_date}</td>
                <td>
                    <button class="btn-edit" onclick="editUser(${user.id}, '${user.name}', '${user.email}', ${user.age})">수정</button>
                    <button class="btn-delete" onclick="deleteUser(${user.id})">삭제</button>
                </td>
            </tr>
        `;
    });
    
    html += `
            </tbody>
        </table>
    `;
    
    usersList.innerHTML = html;
}

// 폼 제출 처리
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const userId = document.getElementById('user-id').value;
    const isEdit = userId !== '';
    
    try {
        const url = isEdit ? 'update.php' : 'insert.php';
        const response = await fetch(url, {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (isEdit) {
            // update.php 응답 처리
            if (data.message === '업데이트 완료') {
                showMessage('사용자 정보가 수정되었습니다.', 'success');
                resetForm();
                fetchUsers();
            } else {
                showMessage('오류가 발생했습니다.', 'error');
            }
        } else {
            // insert.php 응답 처리
            if (data.status === 'success') {
                showMessage('사용자가 추가되었습니다.', 'success');
                resetForm();
                fetchUsers();
            } else {
                showMessage('오류가 발생했습니다.', 'error');
            }
        }
    } catch (error) {
        showMessage(`오류 발생: ${error.message}`, 'error');
    }
}

// 사용자 수정
function editUser(id, name, email, age) {
    document.getElementById('user-id').value = id;
    document.getElementById('name').value = name;
    document.getElementById('email').value = email;
    document.getElementById('age').value = age;
    
    document.getElementById('form-title').textContent = '사용자 정보 수정';
    document.getElementById('submit-btn').textContent = '수정';
    document.getElementById('cancel-btn').style.display = 'inline-block';
    
    // 폼으로 스크롤
    document.querySelector('.form-container').scrollIntoView({ behavior: 'smooth' });
}

// 사용자 삭제
async function deleteUser(id) {
    if (!confirm('정말로 이 사용자를 삭제하시겠습니까?')) {
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('id', id);
        
        const response = await fetch('delete.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.message === '삭제 완료') {
            showMessage('사용자가 삭제되었습니다.', 'success');
            fetchUsers();
        } else {
            showMessage('오류가 발생했습니다.', 'error');
        }
    } catch (error) {
        showMessage(`오류 발생: ${error.message}`, 'error');
    }
}

// 폼 초기화
function resetForm() {
    document.getElementById('user-form').reset();
    document.getElementById('user-id').value = '';
    document.getElementById('form-title').textContent = '새 사용자 추가';
    document.getElementById('submit-btn').textContent = '추가';
    document.getElementById('cancel-btn').style.display = 'none';
}

// 메시지 표시
function showMessage(message, type) {
    const container = document.querySelector('.container');
    const messageDiv = document.createElement('div');
    messageDiv.className = type === 'success' ? 'success-message' : 'error-message';
    messageDiv.textContent = message;
    
    container.insertBefore(messageDiv, container.firstChild);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}
