<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_config.php';

// POST 데이터 받기
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$age = isset($_POST['age']) ? intval($_POST['age']) : 0;

// 입력 검증
if ($id <= 0 || empty($name) || empty($email) || $age <= 0) {
    echo json_encode(['message' => '입력 오류'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 이메일 형식 검증
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['message' => '이메일 형식 오류'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 데이터베이스 연결
$conn = getDBConnection();

// 사용자 정보 업데이트
$stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, age = ? WHERE id = ?");
$stmt->bind_param("ssii", $name, $email, $age, $id);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    echo json_encode(['message' => '업데이트 완료'], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['message' => '업데이트 실패'], JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();
?>
