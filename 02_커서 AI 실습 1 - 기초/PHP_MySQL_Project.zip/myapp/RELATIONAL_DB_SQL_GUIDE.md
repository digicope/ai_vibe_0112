# 관계형 데이터베이스와 SQL 가이드

이 문서는 관계형 데이터베이스(RDBMS)와 SQL의 기본 개념을 설명합니다.

---

## 📋 목차

1. [관계형 데이터베이스란?](#관계형-데이터베이스란)
2. [관계형 DB의 핵심 개념](#관계형-db의-핵심-개념)
3. [SQL이란?](#sql이란)
4. [SQL 기본 명령어](#sql-기본-명령어)
5. [관계형 DB의 장점](#관계형-db의-장점)
6. [실제 예제](#실제-예제)

---

## 관계형 데이터베이스란?

### 정의

**관계형 데이터베이스(Relational Database)**는 데이터를 **테이블(Table)** 형태로 저장하고, 테이블 간의 **관계(Relationship)**를 통해 데이터를 관리하는 데이터베이스입니다.

### 주요 특징

- 📊 **테이블 구조**: 데이터를 행(Row)과 열(Column)로 구성된 테이블에 저장
- 🔗 **관계 설정**: 여러 테이블 간의 관계를 정의하여 데이터 중복 최소화
- 🔒 **무결성**: 데이터의 정확성과 일관성을 보장
- 📈 **확장성**: 대용량 데이터 처리에 효율적

### 대표적인 관계형 DB

- **MySQL**: 오픈소스, 웹 개발에 널리 사용
- **PostgreSQL**: 고급 기능을 제공하는 오픈소스 DB
- **Oracle**: 기업용 상용 DB
- **SQL Server**: Microsoft의 상용 DB
- **SQLite**: 경량 임베디드 DB

---

## 관계형 DB의 핵심 개념

### 1. 테이블 (Table)

데이터를 저장하는 기본 단위로, 행과 열로 구성됩니다.

```
┌────┬──────────┬───────────────┬─────┐
│ id │   name   │     email     │ age │
├────┼──────────┼───────────────┼─────┤
│  1 │ 김민수   │ minsu@ex.com  │  25 │
│  2 │ 박지연   │ jiyeon@ex.com │  30 │
│  3 │ 이철수   │ cheolsu@ex.com│  28 │
└────┴──────────┴───────────────┴─────┘
```

- **행(Row)**: 하나의 레코드(Record), 실제 데이터
- **열(Column)**: 필드(Field), 데이터의 속성
- **셀(Cell)**: 행과 열이 만나는 지점, 하나의 값

### 2. 기본키 (Primary Key, PK)

각 행을 고유하게 식별하는 컬럼입니다.

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- 기본키
    name VARCHAR(50),
    email VARCHAR(100)
);
```

**특징:**
- ✅ 중복 불가능
- ✅ NULL 값 불가능
- ✅ 각 행을 고유하게 식별

### 3. 외래키 (Foreign Key, FK)

다른 테이블의 기본키를 참조하는 컬럼입니다.

```sql
CREATE TABLE orders (
    id INT PRIMARY KEY,
    user_id INT,  -- 외래키
    product_name VARCHAR(100),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

**특징:**
- 🔗 다른 테이블과의 관계를 정의
- 📊 데이터 중복 방지
- 🔒 참조 무결성 보장

### 4. 관계 (Relationship)

#### 일대일 (1:1)
- 한 테이블의 한 레코드가 다른 테이블의 한 레코드와 연결
- 예: 사용자 ↔ 사용자 프로필

#### 일대다 (1:N)
- 한 테이블의 한 레코드가 다른 테이블의 여러 레코드와 연결
- 예: 사용자(1) ↔ 주문(N)

#### 다대다 (N:M)
- 한 테이블의 여러 레코드가 다른 테이블의 여러 레코드와 연결
- 중간 테이블 필요
- 예: 학생(N) ↔ 과목(M) → 수강 테이블

### 5. 정규화 (Normalization)

데이터 중복을 최소화하고 데이터 무결성을 보장하기 위한 설계 방법입니다.

**1NF (제1정규형)**: 각 셀은 하나의 값만 가짐
**2NF (제2정규형)**: 부분 종속성 제거
**3NF (제3정규형)**: 이행 종속성 제거

---

## SQL이란?

### 정의

**SQL (Structured Query Language)**는 관계형 데이터베이스를 조작하기 위한 표준 언어입니다.

### SQL의 역할

- 📝 **데이터 정의**: 테이블 생성, 수정, 삭제
- 📊 **데이터 조작**: 데이터 조회, 삽입, 수정, 삭제
- 🔒 **데이터 제어**: 권한 관리, 트랜잭션 제어

### SQL 명령어 분류

1. **DDL (Data Definition Language)**: 데이터 정의
   - `CREATE`, `ALTER`, `DROP`

2. **DML (Data Manipulation Language)**: 데이터 조작
   - `SELECT`, `INSERT`, `UPDATE`, `DELETE`

3. **DCL (Data Control Language)**: 데이터 제어
   - `GRANT`, `REVOKE`

4. **TCL (Transaction Control Language)**: 트랜잭션 제어
   - `COMMIT`, `ROLLBACK`

---

## SQL 기본 명령어

### 1. CREATE - 테이블 생성

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    age INT,
    reg_date DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 2. SELECT - 데이터 조회

```sql
-- 모든 데이터 조회
SELECT * FROM users;

-- 특정 컬럼만 조회
SELECT name, email FROM users;

-- 조건부 조회
SELECT * FROM users WHERE age > 25;

-- 정렬
SELECT * FROM users ORDER BY age DESC;

-- 제한
SELECT * FROM users LIMIT 10;
```

### 3. INSERT - 데이터 삽입

```sql
-- 단일 데이터 삽입
INSERT INTO users (name, email, age) 
VALUES ('홍길동', 'hong@example.com', 25);

-- 여러 데이터 삽입
INSERT INTO users (name, email, age) VALUES
('김민수', 'minsu@example.com', 30),
('박지연', 'jiyeon@example.com', 28);
```

### 4. UPDATE - 데이터 수정

```sql
-- 특정 레코드 수정
UPDATE users 
SET age = 26, email = 'newemail@example.com' 
WHERE id = 1;

-- 여러 레코드 일괄 수정
UPDATE users SET age = age + 1 WHERE age < 30;
```

### 5. DELETE - 데이터 삭제

```sql
-- 특정 레코드 삭제
DELETE FROM users WHERE id = 1;

-- 조건부 삭제
DELETE FROM users WHERE age < 18;
```

### 6. JOIN - 테이블 조인

```sql
-- INNER JOIN (내부 조인)
SELECT users.name, orders.product_name
FROM users
INNER JOIN orders ON users.id = orders.user_id;

-- LEFT JOIN (왼쪽 외부 조인)
SELECT users.name, orders.product_name
FROM users
LEFT JOIN orders ON users.id = orders.user_id;
```

### 7. 집계 함수

```sql
-- 개수
SELECT COUNT(*) FROM users;

-- 평균
SELECT AVG(age) FROM users;

-- 최대값
SELECT MAX(age) FROM users;

-- 최소값
SELECT MIN(age) FROM users;

-- 합계
SELECT SUM(age) FROM users;
```

### 8. GROUP BY - 그룹화

```sql
-- 나이별 사용자 수
SELECT age, COUNT(*) as count
FROM users
GROUP BY age;

-- 나이대별 평균
SELECT 
    CASE 
        WHEN age < 30 THEN '20대'
        WHEN age < 40 THEN '30대'
        ELSE '40대 이상'
    END as age_group,
    COUNT(*) as count
FROM users
GROUP BY age_group;
```

---

## 관계형 DB의 장점

### 1. 데이터 무결성

- ✅ **참조 무결성**: 외래키로 데이터 일관성 보장
- ✅ **엔티티 무결성**: 기본키로 중복 방지
- ✅ **도메인 무결성**: 데이터 타입과 제약 조건으로 유효성 보장

### 2. 데이터 중복 최소화

**정규화 전:**
```
┌────┬──────────┬───────────────┬──────────────┐
│ id │   name   │     email     │  order_info  │
├────┼──────────┼───────────────┼──────────────┤
│  1 │ 김민수   │ minsu@ex.com  │ 상품A, 상품B │
│  2 │ 박지연   │ jiyeon@ex.com │ 상품A        │
└────┴──────────┴───────────────┴──────────────┘
```

**정규화 후:**
```
users 테이블          orders 테이블
┌────┬──────────┐    ┌────┬─────────┬──────────┐
│ id │   name   │    │ id │ user_id │ product  │
├────┼──────────┤    ├────┼─────────┼──────────┤
│  1 │ 김민수   │    │  1 │    1    │  상품A   │
│  2 │ 박지연   │    │  2 │    1    │  상품B   │
└────┴──────────┘    │  3 │    2    │  상품A   │
                     └────┴─────────┴──────────┘
```

### 3. 유연한 쿼리

- 복잡한 조건의 데이터 조회 가능
- 여러 테이블을 조인하여 다양한 데이터 조합
- 집계 함수로 통계 분석

### 4. 확장성

- 대용량 데이터 처리에 효율적
- 인덱스를 통한 빠른 검색
- 트랜잭션으로 데이터 일관성 보장

---

## 실제 예제

### 예제 1: 사용자와 주문 관계

```sql
-- users 테이블
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    email VARCHAR(100)
);

-- orders 테이블 (users와 1:N 관계)
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    product_name VARCHAR(100),
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 데이터 삽입
INSERT INTO users (name, email) VALUES
('김민수', 'minsu@example.com'),
('박지연', 'jiyeon@example.com');

INSERT INTO orders (user_id, product_name) VALUES
(1, '노트북'),
(1, '마우스'),
(2, '키보드');

-- 조인 쿼리
SELECT 
    users.name,
    users.email,
    orders.product_name,
    orders.order_date
FROM users
INNER JOIN orders ON users.id = orders.user_id;
```

**결과:**
```
┌──────────┬──────────────────┬──────────┬─────────────────────┐
│   name   │      email       │ product  │     order_date      │
├──────────┼──────────────────┼──────────┼─────────────────────┤
│ 김민수   │ minsu@ex.com     │ 노트북   │ 2024-01-19 10:00:00 │
│ 김민수   │ minsu@ex.com     │ 마우스   │ 2024-01-19 10:05:00 │
│ 박지연   │ jiyeon@ex.com    │ 키보드   │ 2024-01-19 11:00:00 │
└──────────┴──────────────────┴──────────┴─────────────────────┘
```

### 예제 2: 학생과 과목 (다대다 관계)

```sql
-- students 테이블
CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50)
);

-- courses 테이블
CREATE TABLE courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    course_name VARCHAR(100)
);

-- 중간 테이블 (enrollments)
CREATE TABLE enrollments (
    student_id INT,
    course_id INT,
    enrollment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

-- 데이터 삽입
INSERT INTO students (name) VALUES
('김철수'), ('이영희'), ('박민수');

INSERT INTO courses (course_name) VALUES
('수학'), ('영어'), ('과학');

INSERT INTO enrollments (student_id, course_id) VALUES
(1, 1), (1, 2),  -- 김철수: 수학, 영어
(2, 2), (2, 3),  -- 이영희: 영어, 과학
(3, 1), (3, 3);  -- 박민수: 수학, 과학

-- 조인 쿼리
SELECT 
    students.name as student_name,
    courses.course_name
FROM students
INNER JOIN enrollments ON students.id = enrollments.student_id
INNER JOIN courses ON enrollments.course_id = courses.id
ORDER BY students.name;
```

---

## 요약

### 관계형 데이터베이스

- 📊 테이블 형태로 데이터 저장
- 🔗 테이블 간 관계를 통한 데이터 관리
- 🔒 데이터 무결성 보장
- 📈 확장 가능한 구조

### SQL

- 📝 데이터베이스를 조작하는 표준 언어
- 🔍 데이터 조회, 삽입, 수정, 삭제
- 🔗 여러 테이블을 조인하여 복잡한 쿼리 작성
- 📊 집계 함수로 통계 분석

### 핵심 개념

1. **테이블**: 데이터를 저장하는 기본 단위
2. **기본키**: 각 행을 고유하게 식별
3. **외래키**: 테이블 간의 관계 정의
4. **정규화**: 데이터 중복 최소화
5. **JOIN**: 여러 테이블을 연결하여 데이터 조회

---

## 학습 팁

1. **기본부터**: SELECT, INSERT, UPDATE, DELETE부터 시작
2. **실습**: 직접 쿼리를 작성하고 실행해보기
3. **JOIN 이해**: 테이블 간의 관계를 이해하는 것이 중요
4. **정규화**: 데이터 설계 시 정규화 원칙 이해
5. **인덱스**: 성능 최적화를 위한 인덱스 활용

---

**작성일**: 2024년 1월 19일  
**프로젝트**: PHP + MySQL 사용자 관리 시스템  
**참고**: 이 프로젝트의 `users` 테이블을 예제로 활용하세요!
