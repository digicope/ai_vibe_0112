<?php
require_once 'db_config.php';

// 데이터베이스 연결
$conn = getDBConnection();

// 한국식 성씨 배열
$surnames = ['김', '이', '박', '최', '정', '강', '조', '윤', '장', '임', '한', '오', '서', '신', '권', '황', '안', '송', '전', '홍'];

// 한국식 이름 배열
$firstNames = [
    '민수', '지연', '영희', '철수', '지영', '민준', '서연', '현우', '수진', '동현',
    '예진', '준호', '혜진', '성민', '미영', '상호', '지은', '태현', '은지', '정호',
    '수빈', '민지', '준영', '지현', '현정', '동욱', '소영', '민호', '지혜', '성호',
    '유진', '재현', '혜원', '승현', '지원', '민경', '태준', '은영', '정민', '지우'
];

// 랜덤 이름 생성 함수
function generateKoreanName($surnames, $firstNames) {
    $surname = $surnames[array_rand($surnames)];
    $firstName = $firstNames[array_rand($firstNames)];
    return $surname . $firstName;
}

// 랜덤 이메일 생성 함수
function generateEmail($name) {
    // 한글 이름을 로마자로 변환하는 간단한 매핑
    $nameMap = [
        '민수' => 'minsu', '지연' => 'jiyeon', '영희' => 'younghee', '철수' => 'cheolsu',
        '지영' => 'jiyoung', '민준' => 'minjun', '서연' => 'seoyeon', '현우' => 'hyunwoo',
        '수진' => 'sujin', '동현' => 'donghyun', '예진' => 'yejin', '준호' => 'junho',
        '혜진' => 'hyejin', '성민' => 'seongmin', '미영' => 'miyoung', '상호' => 'sangho',
        '지은' => 'jieun', '태현' => 'taehyun', '은지' => 'eunji', '정호' => 'jungho',
        '수빈' => 'subin', '민지' => 'minji', '준영' => 'junyoung', '지현' => 'jihyun',
        '현정' => 'hyunjung', '동욱' => 'dongwook', '소영' => 'soyoung', '민호' => 'minho',
        '지혜' => 'jihye', '성호' => 'seongho', '유진' => 'yujin', '재현' => 'jaehyun',
        '혜원' => 'hyewon', '승현' => 'seunghyun', '지원' => 'jiwon', '민경' => 'mingyeong',
        '태준' => 'taejun', '은영' => 'eunyoung', '정민' => 'jungmin', '지우' => 'jiwoo'
    ];
    
    // 이름에서 성씨 제외한 부분 추출
    $namePart = mb_substr($name, 1);
    
    // 매핑에 있으면 사용, 없으면 랜덤 영어 조합
    if (isset($nameMap[$namePart])) {
        $emailName = $nameMap[$namePart];
    } else {
        // 랜덤 영어 조합 생성
        $randomStr = '';
        $chars = 'abcdefghijklmnopqrstuvwxyz';
        for ($i = 0; $i < 6; $i++) {
            $randomStr .= $chars[rand(0, strlen($chars) - 1)];
        }
        $emailName = $randomStr;
    }
    
    // 중복 방지를 위해 랜덤 숫자 추가
    $randomNum = rand(100, 999);
    return $emailName . $randomNum . '@example.com';
}

// 10명의 랜덤 사용자 데이터 생성
$users = [];
for ($i = 0; $i < 10; $i++) {
    $name = generateKoreanName($surnames, $firstNames);
    $email = generateEmail($name);
    $age = rand(20, 50); // 20~50 사이 랜덤 정수
    
    $users[] = [$name, $email, $age];
}

// 데이터베이스에 삽입
$stmt = $conn->prepare("INSERT INTO users (name, email, age) VALUES (?, ?, ?)");
$inserted = 0;
$skipped = 0;

foreach ($users as $user) {
    $stmt->bind_param("ssi", $user[0], $user[1], $user[2]);
    
    if ($stmt->execute()) {
        $inserted++;
        echo "추가됨: {$user[0]} ({$user[1]}, {$user[2]}세)\n";
    } else {
        // 중복 이메일인 경우 스킵
        if ($conn->errno == 1062) {
            $skipped++;
            echo "스킵됨 (중복 이메일): {$user[0]} ({$user[1]})\n";
        } else {
            echo "오류: {$user[0]} 추가 실패 - " . $conn->error . "\n";
        }
    }
}

echo "\n=== 샘플 데이터 삽입 완료 ===\n";
echo "추가된 사용자: {$inserted}명\n";
if ($skipped > 0) {
    echo "스킵된 사용자 (중복): {$skipped}명\n";
}

$stmt->close();
$conn->close();
?>
