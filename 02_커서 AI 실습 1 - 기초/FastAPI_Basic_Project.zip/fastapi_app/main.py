"""
FastAPI 기본 웹 서버
초보자 실습용 FastAPI 애플리케이션
"""

# FastAPI와 필요한 모듈들을 import 합니다
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn
from pathlib import Path

# CRUD 기능 import
from fastapi_crud_app import (
    UserCreate, UserUpdate,
    create_user, get_users, get_user, update_user, delete_user
)

# 도서 관리 CRUD 기능 import
from fastapi_crud_app_2 import (
    BookCreate, BookUpdate,
    create_book, get_books, get_book, update_book, delete_book
)

# 현재 파일의 디렉토리 경로를 가져옵니다
# 이렇게 하면 어느 디렉토리에서 실행하더라도 올바른 경로를 찾을 수 있습니다
BASE_DIR = Path(__file__).resolve().parent

# FastAPI 앱 인스턴스를 생성합니다
# 이 인스턴스가 우리의 웹 애플리케이션의 핵심입니다
app = FastAPI(title="FastAPI Web Server 실습")

# Jinja2 템플릿 엔진을 설정합니다
# templates 폴더에 있는 HTML 파일들을 렌더링할 수 있게 해줍니다
# BASE_DIR을 사용하여 절대 경로로 설정합니다
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

# 정적 파일(static)을 서빙하도록 설정합니다
# CSS, JavaScript, 이미지 등의 파일을 /static 경로로 접근할 수 있게 해줍니다
# BASE_DIR을 사용하여 절대 경로로 설정합니다
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")


# 루트 경로("/")에 대한 GET 요청을 처리하는 라우트입니다
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    """
    루트 경로("/")로 접속했을 때 실행되는 함수입니다.
    templates/index.html 파일을 렌더링하여 반환합니다.
    
    Args:
        request: HTTP 요청 객체 (템플릿 렌더링에 필요)
    
    Returns:
        HTMLResponse: 렌더링된 HTML 페이지
    """
    # Jinja2 템플릿을 사용하여 index.html을 렌더링합니다
    return templates.TemplateResponse("index.html", {"request": request})


# "/api/hello" 경로에 대한 GET 요청을 처리하는 API 엔드포인트입니다
@app.get("/api/hello")
async def hello():
    """
    "/api/hello" 경로로 GET 요청을 보내면 실행되는 함수입니다.
    JSON 형식으로 메시지를 반환합니다.
    
    Returns:
        dict: JSON 형식의 응답 메시지
    """
    return {"message": "Hello FastAPI"}


# ========== CRUD API 엔드포인트 ==========

# (1) Create: 사용자 추가
@app.post("/api/users")
async def api_create_user(user: UserCreate):
    """
    새로운 사용자를 생성합니다.
    POST /api/users
    """
    try:
        return create_user(user)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (2) Read: 사용자 목록 조회
@app.get("/api/users")
async def api_get_users():
    """
    모든 사용자 목록을 조회합니다.
    GET /api/users
    """
    try:
        return get_users()
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (3) Read: 사용자 1명 조회
@app.get("/api/users/{user_id}")
async def api_get_user(user_id: int):
    """
    특정 사용자를 조회합니다.
    GET /api/users/{id}
    """
    try:
        return get_user(user_id)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (4) Update: 사용자 수정
@app.put("/api/users/{user_id}")
async def api_update_user(user_id: int, user: UserUpdate):
    """
    사용자 정보를 수정합니다.
    PUT /api/users/{id}
    """
    try:
        return update_user(user_id, user)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (5) Delete: 사용자 삭제
@app.delete("/api/users/{user_id}")
async def api_delete_user(user_id: int):
    """
    사용자를 삭제합니다.
    DELETE /api/users/{id}
    """
    try:
        return delete_user(user_id)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# ========== 웹페이지 라우트 ==========

# 사용자 관리 CRUD 테스트 페이지
@app.get("/users", response_class=HTMLResponse)
async def users_page(request: Request):
    """
    사용자 관리 CRUD 테스트 페이지를 렌더링합니다.
    GET /users
    """
    return templates.TemplateResponse("users.html", {"request": request})

# 도서 관리 CRUD 테스트 페이지
@app.get("/books", response_class=HTMLResponse)
async def books_page(request: Request):
    """
    도서 관리 CRUD 테스트 페이지를 렌더링합니다.
    GET /books
    """
    return templates.TemplateResponse("books.html", {"request": request})


# ========== 도서 관리 CRUD API 엔드포인트 ==========

# (1) Create: 도서 추가
@app.post("/api/books")
async def api_create_book(book: BookCreate):
    """
    새로운 도서를 생성합니다.
    POST /api/books
    """
    try:
        return create_book(book)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (2) Read: 도서 목록 조회
@app.get("/api/books")
async def api_get_books():
    """
    모든 도서 목록을 조회합니다.
    GET /api/books
    """
    try:
        return get_books()
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (3) Read: 도서 1권 조회
@app.get("/api/books/{book_id}")
async def api_get_book(book_id: int):
    """
    특정 도서를 조회합니다.
    GET /api/books/{id}
    """
    try:
        return get_book(book_id)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (4) Update: 도서 정보 수정
@app.put("/api/books/{book_id}")
async def api_update_book(book_id: int, book: BookUpdate):
    """
    도서 정보를 수정합니다.
    PUT /api/books/{id}
    """
    try:
        return update_book(book_id, book)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# (5) Delete: 도서 삭제
@app.delete("/api/books/{book_id}")
async def api_delete_book(book_id: int):
    """
    도서를 삭제합니다.
    DELETE /api/books/{id}
    """
    try:
        return delete_book(book_id)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )


# 이 파일이 직접 실행될 때만 서버를 시작합니다
# 다른 파일에서 import할 때는 서버가 시작되지 않습니다
if __name__ == "__main__":
    # uvicorn을 사용하여 FastAPI 서버를 실행합니다
    # host="0.0.0.0": 모든 네트워크 인터페이스에서 접속 가능하도록 설정
    # port=5000: 5000번 포트에서 서버를 실행
    # reload=True: 코드 변경 시 자동으로 서버를 재시작 (개발 환경용)
    # reload를 사용하려면 import 문자열을 사용해야 하므로, 여기서는 reload=False로 설정
    # reload 기능이 필요하면 터미널에서 "uvicorn main:app --host 0.0.0.0 --port 5000 --reload" 명령어 사용
    uvicorn.run("main:app", host="0.0.0.0", port=5000, reload=True)
