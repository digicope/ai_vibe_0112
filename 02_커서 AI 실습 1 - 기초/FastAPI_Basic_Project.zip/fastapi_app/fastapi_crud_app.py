"""
FastAPI REST API CRUD 연산
사용자 관리 시스템
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
import sqlite3
from datetime import datetime
from pathlib import Path

# 현재 파일의 디렉토리 경로를 가져옵니다
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "app.db"

# Pydantic 모델: 요청 데이터 검증
class UserCreate(BaseModel):
    """사용자 생성 요청 모델"""
    name: str = Field(..., min_length=1, description="사용자 이름 (필수)")
    email: EmailStr = Field(..., description="이메일 주소 (필수, 고유)")
    age: Optional[int] = Field(None, ge=0, description="나이 (선택, 0 이상)")

class UserUpdate(BaseModel):
    """사용자 수정 요청 모델"""
    name: str = Field(..., min_length=1, description="사용자 이름 (필수)")
    email: EmailStr = Field(..., description="이메일 주소 (필수)")
    age: Optional[int] = Field(None, ge=0, description="나이 (선택, 0 이상)")

# 데이터베이스 초기화 함수
def init_db():
    """
    데이터베이스와 테이블을 초기화합니다.
    테이블이 없으면 자동으로 생성합니다.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # users 테이블 생성
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            age INTEGER,
            reg_date TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        )
    """)
    
    conn.commit()
    conn.close()
    print(f"데이터베이스 초기화 완료: {DB_PATH}")

# 앱 시작 시 데이터베이스 초기화
init_db()

# 데이터베이스 연결 헬퍼 함수
def get_db_connection():
    """데이터베이스 연결을 반환합니다."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # 딕셔너리 형태로 결과 반환
    return conn

# 날짜 포맷팅 함수
def format_date(date_str: str) -> str:
    """날짜를 YYYY-MM-DD 형태로 포맷합니다."""
    try:
        # SQLite의 datetime 형식을 파싱
        dt = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%Y-%m-%d")
    except:
        return date_str

# CRUD API 엔드포인트들

# (1) Create: 사용자 추가
# POST /api/users
def create_user(user: UserCreate):
    """
    새로운 사용자를 생성합니다.
    
    Args:
        user: 사용자 생성 요청 데이터
        
    Returns:
        dict: 생성 성공 응답 (status, id)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 이메일 중복 확인
        cursor.execute("SELECT id FROM users WHERE email = ?", (user.email,))
        if cursor.fetchone():
            raise HTTPException(
                status_code=400,
                detail={"status": "error", "message": "이미 존재하는 이메일입니다."}
            )
        
        # 사용자 추가
        cursor.execute("""
            INSERT INTO users (name, email, age)
            VALUES (?, ?, ?)
        """, (user.name, user.email, user.age))
        
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        
        return {"status": "success", "id": user_id}
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 생성 실패: {str(e)}"}
        )

# (2) Read: 사용자 목록 조회
# GET /api/users
def get_users():
    """
    모든 사용자 목록을 조회합니다.
    
    Returns:
        list: 사용자 목록 (JSON 배열)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT id, name, email, age, reg_date FROM users ORDER BY id")
        rows = cursor.fetchall()
        conn.close()
        
        # 딕셔너리 형태로 변환하고 날짜 포맷팅
        users = []
        for row in rows:
            user = dict(row)
            user["reg_date"] = format_date(user["reg_date"])
            users.append(user)
        
        return users
    
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 목록 조회 실패: {str(e)}"}
        )

# (3) Read: 사용자 1명 조회
# GET /api/users/{id}
def get_user(user_id: int):
    """
    특정 사용자를 조회합니다.
    
    Args:
        user_id: 사용자 ID
        
    Returns:
        dict: 사용자 정보
        
    Raises:
        HTTPException: 사용자를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT id, name, email, age, reg_date FROM users WHERE id = ?", (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {user_id}에 해당하는 사용자를 찾을 수 없습니다."}
            )
        
        user = dict(row)
        user["reg_date"] = format_date(user["reg_date"])
        return user
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 조회 실패: {str(e)}"}
        )

# (4) Update: 사용자 수정
# PUT /api/users/{id}
def update_user(user_id: int, user: UserUpdate):
    """
    사용자 정보를 수정합니다.
    
    Args:
        user_id: 사용자 ID
        user: 사용자 수정 요청 데이터
        
    Returns:
        dict: 수정된 사용자 정보
        
    Raises:
        HTTPException: 사용자를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 사용자 존재 확인
        cursor.execute("SELECT id FROM users WHERE id = ?", (user_id,))
        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {user_id}에 해당하는 사용자를 찾을 수 없습니다."}
            )
        
        # 이메일 중복 확인 (자기 자신 제외)
        cursor.execute("SELECT id FROM users WHERE email = ? AND id != ?", (user.email, user_id))
        if cursor.fetchone():
            raise HTTPException(
                status_code=400,
                detail={"status": "error", "message": "이미 존재하는 이메일입니다."}
            )
        
        # 사용자 정보 수정
        cursor.execute("""
            UPDATE users
            SET name = ?, email = ?, age = ?
            WHERE id = ?
        """, (user.name, user.email, user.age, user_id))
        
        conn.commit()
        
        # 수정된 사용자 정보 조회
        cursor.execute("SELECT id, name, email, age, reg_date FROM users WHERE id = ?", (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        user_dict = dict(row)
        user_dict["reg_date"] = format_date(user_dict["reg_date"])
        return user_dict
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 수정 실패: {str(e)}"}
        )

# (5) Delete: 사용자 삭제
# DELETE /api/users/{id}
def delete_user(user_id: int):
    """
    사용자를 삭제합니다.
    
    Args:
        user_id: 사용자 ID
        
    Returns:
        dict: 삭제 성공 응답
        
    Raises:
        HTTPException: 사용자를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 사용자 존재 확인
        cursor.execute("SELECT id FROM users WHERE id = ?", (user_id,))
        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {user_id}에 해당하는 사용자를 찾을 수 없습니다."}
            )
        
        # 사용자 삭제
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
        
        return {"status": "deleted"}
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 삭제 실패: {str(e)}"}
        )
