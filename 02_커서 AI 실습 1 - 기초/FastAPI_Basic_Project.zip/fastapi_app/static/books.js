// REST API CRUD 테스트 JavaScript - 도서 관리 시스템

// API 기본 URL
const API_BASE = '/api/books';

// 알림 메시지 표시 함수
function showAlert(message, type = 'success') {
    const alertArea = document.getElementById('alert-area');
    alertArea.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    
    // 3초 후 자동 제거
    setTimeout(() => {
        alertArea.innerHTML = '';
    }, 3000);
}

// 상태 한글 변환
function getStatusText(status) {
    return status === 'available' ? '대여 가능' : '대여 중';
}

// 도서 목록 불러오기
async function loadBooks() {
    try {
        const response = await fetch(API_BASE);
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || '목록 조회 실패');
        }
        
        const books = await response.json();
        renderBooksTable(books);
    } catch (error) {
        showAlert(`목록 조회 실패: ${error.message}`, 'error');
    }
}

// 도서 테이블 렌더링
function renderBooksTable(books) {
    const tbody = document.getElementById('books-tbody');
    
    if (books.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">등록된 도서가 없습니다.</td></tr>';
        return;
    }
    
    tbody.innerHTML = books.map(book => `
        <tr data-book-id="${book.id}">
            <td>${book.id}</td>
            <td class="editable" data-field="title">${book.title}</td>
            <td class="editable" data-field="author">${book.author}</td>
            <td class="editable" data-field="isbn">${book.isbn}</td>
            <td class="editable" data-field="status">${getStatusText(book.status)}</td>
            <td class="editable" data-field="borrower">${book.borrower || ''}</td>
            <td>${book.reg_date}</td>
            <td>
                <button class="btn btn-small btn-edit" onclick="editBook(${book.id})">수정</button>
                <button class="btn btn-small btn-delete" onclick="deleteBook(${book.id})">삭제</button>
            </td>
        </tr>
    `).join('');
}

// 상태 선택에 따른 대여자 필드 표시/숨김
function toggleBorrowerField(statusSelect, borrowerGroup) {
    if (statusSelect.value === 'borrowed') {
        borrowerGroup.style.display = 'block';
        const borrowerInput = borrowerGroup.querySelector('input');
        if (borrowerInput) {
            borrowerInput.required = true;
        }
    } else {
        borrowerGroup.style.display = 'none';
        const borrowerInput = borrowerGroup.querySelector('input');
        if (borrowerInput) {
            borrowerInput.required = false;
            borrowerInput.value = '';
        }
    }
}

// 도서 추가 폼의 상태 변경 이벤트
document.getElementById('create-status').addEventListener('change', function() {
    const borrowerGroup = document.getElementById('create-borrower-group');
    toggleBorrowerField(this, borrowerGroup);
});

// 도서 추가
document.getElementById('create-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const title = document.getElementById('create-title').value.trim();
    const author = document.getElementById('create-author').value.trim();
    const isbn = document.getElementById('create-isbn').value.trim();
    const status = document.getElementById('create-status').value;
    const borrower = document.getElementById('create-borrower').value.trim();
    
    if (!title || !author || !isbn) {
        showAlert('제목, 저자, ISBN은 필수 입력 항목입니다.', 'error');
        return;
    }
    
    // status가 borrowed일 때 borrower 필수
    if (status === 'borrowed' && !borrower) {
        showAlert('상태가 "대여 중"일 때 대여자는 필수 입력 항목입니다.', 'error');
        return;
    }
    
    try {
        const response = await fetch(API_BASE, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                title: title,
                author: author,
                isbn: isbn,
                status: status,
                borrower: status === 'borrowed' ? borrower : null
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '도서 추가 실패');
        }
        
        showAlert(`도서가 추가되었습니다. (ID: ${data.id})`, 'success');
        
        // 폼 초기화
        document.getElementById('create-form').reset();
        document.getElementById('create-borrower-group').style.display = 'none';
        
        // 목록 다시 불러오기
        loadBooks();
    } catch (error) {
        showAlert(`추가 실패: ${error.message}`, 'error');
    }
});

// 단일 도서 조회
document.getElementById('read-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const bookId = document.getElementById('read-id').value;
    const resultBox = document.getElementById('read-result');
    
    try {
        const response = await fetch(`${API_BASE}/${bookId}`);
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '도서 조회 실패');
        }
        
        resultBox.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
        showAlert('도서 조회 성공', 'success');
    } catch (error) {
        resultBox.innerHTML = `<pre class="error">${error.message}</pre>`;
        showAlert(`조회 실패: ${error.message}`, 'error');
    }
});

// 도서 수정 모드 전환
let editingBookId = null;

function editBook(bookId) {
    const row = document.querySelector(`tr[data-book-id="${bookId}"]`);
    if (!row) return;
    
    // 이미 편집 중인 경우 취소
    if (editingBookId && editingBookId !== bookId) {
        cancelEdit(editingBookId);
    }
    
    editingBookId = bookId;
    
    // 편집 가능한 필드를 입력 필드로 변경
    const editableCells = row.querySelectorAll('.editable');
    editableCells.forEach(cell => {
        const field = cell.getAttribute('data-field');
        const currentValue = cell.textContent.trim();
        
        if (field === 'status') {
            // 상태는 select로 변경
            const statusValue = currentValue === '대여 가능' ? 'available' : 'borrowed';
            cell.innerHTML = `
                <select class="edit-input edit-status" data-field="${field}">
                    <option value="available" ${statusValue === 'available' ? 'selected' : ''}>대여 가능</option>
                    <option value="borrowed" ${statusValue === 'borrowed' ? 'selected' : ''}>대여 중</option>
                </select>
            `;
            
            // 상태 변경 이벤트 리스너 추가
            const select = cell.querySelector('select');
            select.addEventListener('change', function() {
                const borrowerCell = row.querySelector('[data-field="borrower"]');
                if (this.value === 'borrowed') {
                    if (borrowerCell.querySelector('input')) {
                        borrowerCell.querySelector('input').required = true;
                    }
                } else {
                    if (borrowerCell.querySelector('input')) {
                        borrowerCell.querySelector('input').required = false;
                        borrowerCell.querySelector('input').value = '';
                    }
                }
            });
        } else if (field === 'borrower') {
            cell.innerHTML = `<input type="text" class="edit-input" data-field="${field}" value="${currentValue}">`;
        } else {
            cell.innerHTML = `<input type="text" class="edit-input" data-field="${field}" value="${currentValue}" required>`;
        }
    });
    
    // 작업 버튼 변경
    const actionCell = row.querySelector('td:last-child');
    actionCell.innerHTML = `
        <button class="btn btn-small btn-save" onclick="saveBook(${bookId})">저장</button>
        <button class="btn btn-small btn-cancel" onclick="cancelEdit(${bookId})">취소</button>
    `;
}

// 수정 취소
function cancelEdit(bookId) {
    const row = document.querySelector(`tr[data-book-id="${bookId}"]`);
    if (!row) return;
    
    // 원래 값으로 복원 (서버에서 다시 불러오기)
    loadBooks();
    editingBookId = null;
}

// 도서 저장
async function saveBook(bookId) {
    const row = document.querySelector(`tr[data-book-id="${bookId}"]`);
    if (!row) return;
    
    const inputs = row.querySelectorAll('.edit-input');
    const bookData = {};
    
    inputs.forEach(input => {
        const field = input.getAttribute('data-field');
        const value = input.value.trim();
        
        if (field === 'status') {
            bookData[field] = value;
        } else if (field === 'borrower') {
            bookData[field] = value || null;
        } else {
            bookData[field] = value;
        }
    });
    
    // 필수 필드 검증
    if (!bookData.title || !bookData.author || !bookData.isbn) {
        showAlert('제목, 저자, ISBN은 필수 입력 항목입니다.', 'error');
        return;
    }
    
    // status가 borrowed일 때 borrower 필수
    if (bookData.status === 'borrowed' && !bookData.borrower) {
        showAlert('상태가 "대여 중"일 때 대여자는 필수 입력 항목입니다.', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${bookId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(bookData)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '도서 수정 실패');
        }
        
        showAlert('도서 정보가 수정되었습니다.', 'success');
        editingBookId = null;
        
        // 목록 다시 불러오기
        loadBooks();
    } catch (error) {
        showAlert(`수정 실패: ${error.message}`, 'error');
    }
}

// 도서 삭제
async function deleteBook(bookId) {
    if (!confirm(`정말로 도서 ID ${bookId}를 삭제하시겠습니까?`)) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${bookId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '도서 삭제 실패');
        }
        
        showAlert('도서가 삭제되었습니다.', 'success');
        
        // 목록 다시 불러오기
        loadBooks();
    } catch (error) {
        showAlert(`삭제 실패: ${error.message}`, 'error');
    }
}

// 페이지 로드 시 도서 목록 불러오기
document.addEventListener('DOMContentLoaded', () => {
    loadBooks();
    // 초기 상태에 따라 대여자 필드 표시/숨김
    const statusSelect = document.getElementById('create-status');
    const borrowerGroup = document.getElementById('create-borrower-group');
    toggleBorrowerField(statusSelect, borrowerGroup);
});
