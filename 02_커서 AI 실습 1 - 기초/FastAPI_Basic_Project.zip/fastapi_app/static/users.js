// REST API CRUD 테스트 JavaScript

// API 기본 URL
const API_BASE = '/api/users';

// 알림 메시지 표시 함수
function showAlert(message, type = 'success') {
    const alertArea = document.getElementById('alert-area');
    alertArea.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    
    // 3초 후 자동 제거
    setTimeout(() => {
        alertArea.innerHTML = '';
    }, 3000);
}

// 사용자 목록 불러오기
async function loadUsers() {
    try {
        const response = await fetch(API_BASE);
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || '목록 조회 실패');
        }
        
        const users = await response.json();
        renderUsersTable(users);
    } catch (error) {
        showAlert(`목록 조회 실패: ${error.message}`, 'error');
    }
}

// 사용자 테이블 렌더링
function renderUsersTable(users) {
    const tbody = document.getElementById('users-tbody');
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">등록된 사용자가 없습니다.</td></tr>';
        return;
    }
    
    tbody.innerHTML = users.map(user => `
        <tr data-user-id="${user.id}">
            <td>${user.id}</td>
            <td class="editable" data-field="name">${user.name}</td>
            <td class="editable" data-field="email">${user.email}</td>
            <td class="editable" data-field="age">${user.age || ''}</td>
            <td>${user.reg_date}</td>
            <td>
                <button class="btn btn-small btn-edit" onclick="editUser(${user.id})">수정</button>
                <button class="btn btn-small btn-delete" onclick="deleteUser(${user.id})">삭제</button>
            </td>
        </tr>
    `).join('');
}

// 사용자 추가
document.getElementById('create-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('create-name').value.trim();
    const email = document.getElementById('create-email').value.trim();
    const age = document.getElementById('create-age').value;
    
    if (!name || !email) {
        showAlert('이름과 이메일은 필수 입력 항목입니다.', 'error');
        return;
    }
    
    try {
        const response = await fetch(API_BASE, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                name: name,
                email: email,
                age: age ? parseInt(age) : null
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 추가 실패');
        }
        
        showAlert(`사용자가 추가되었습니다. (ID: ${data.id})`, 'success');
        
        // 폼 초기화
        document.getElementById('create-form').reset();
        
        // 목록 다시 불러오기
        loadUsers();
    } catch (error) {
        showAlert(`추가 실패: ${error.message}`, 'error');
    }
});

// 단일 사용자 조회
document.getElementById('read-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const userId = document.getElementById('read-id').value;
    const resultBox = document.getElementById('read-result');
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`);
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 조회 실패');
        }
        
        resultBox.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
        showAlert('사용자 조회 성공', 'success');
    } catch (error) {
        resultBox.innerHTML = `<pre class="error">${error.message}</pre>`;
        showAlert(`조회 실패: ${error.message}`, 'error');
    }
});

// 사용자 수정 모드 전환
let editingUserId = null;

function editUser(userId) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    if (!row) return;
    
    // 이미 편집 중인 경우 취소
    if (editingUserId && editingUserId !== userId) {
        cancelEdit(editingUserId);
    }
    
    editingUserId = userId;
    
    // 편집 가능한 필드를 입력 필드로 변경
    const editableCells = row.querySelectorAll('.editable');
    editableCells.forEach(cell => {
        const field = cell.getAttribute('data-field');
        const currentValue = cell.textContent.trim();
        
        if (field === 'age') {
            cell.innerHTML = `<input type="number" class="edit-input" data-field="${field}" value="${currentValue || ''}" min="0">`;
        } else {
            cell.innerHTML = `<input type="${field === 'email' ? 'email' : 'text'}" class="edit-input" data-field="${field}" value="${currentValue}" required>`;
        }
    });
    
    // 작업 버튼 변경
    const actionCell = row.querySelector('td:last-child');
    actionCell.innerHTML = `
        <button class="btn btn-small btn-save" onclick="saveUser(${userId})">저장</button>
        <button class="btn btn-small btn-cancel" onclick="cancelEdit(${userId})">취소</button>
    `;
}

// 수정 취소
function cancelEdit(userId) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    if (!row) return;
    
    // 원래 값으로 복원 (서버에서 다시 불러오기)
    loadUsers();
    editingUserId = null;
}

// 사용자 저장
async function saveUser(userId) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    if (!row) return;
    
    const inputs = row.querySelectorAll('.edit-input');
    const userData = {};
    
    inputs.forEach(input => {
        const field = input.getAttribute('data-field');
        const value = input.value.trim();
        
        if (field === 'age') {
            userData[field] = value ? parseInt(value) : null;
        } else {
            userData[field] = value;
        }
    });
    
    // 필수 필드 검증
    if (!userData.name || !userData.email) {
        showAlert('이름과 이메일은 필수 입력 항목입니다.', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 수정 실패');
        }
        
        showAlert('사용자 정보가 수정되었습니다.', 'success');
        editingUserId = null;
        
        // 목록 다시 불러오기
        loadUsers();
    } catch (error) {
        showAlert(`수정 실패: ${error.message}`, 'error');
    }
}

// 사용자 삭제
async function deleteUser(userId) {
    if (!confirm(`정말로 사용자 ID ${userId}를 삭제하시겠습니까?`)) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 삭제 실패');
        }
        
        showAlert('사용자가 삭제되었습니다.', 'success');
        
        // 목록 다시 불러오기
        loadUsers();
    } catch (error) {
        showAlert(`삭제 실패: ${error.message}`, 'error');
    }
}

// 페이지 로드 시 사용자 목록 불러오기
document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
});
