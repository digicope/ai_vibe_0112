# FastAPI 기본 웹 서버 실습 프로젝트

이 프로젝트는 FastAPI를 사용한 기본 웹 서버 실습용 프로젝트입니다.

## 프로젝트 구조

```
fastapi_app/
├── main.py              # FastAPI 애플리케이션 메인 파일
├── requirements.txt     # Python 패키지 의존성 목록
├── templates/           # HTML 템플릿 폴더
│   └── index.html       # 메인 HTML 템플릿
├── static/              # 정적 파일 폴더 (CSS, JS, 이미지 등)
│   └── style.css        # CSS 스타일 파일
└── README.md            # 프로젝트 설명 문서
```

## 설치 방법

### 1. Python 가상 환경 생성 (권장)

```bash
# 가상 환경 생성
python -m venv venv

# 가상 환경 활성화
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate
```

### 2. requirements.txt 설치

프로젝트 디렉토리(`fastapi_app`)에서 다음 명령어를 실행합니다:

```bash
pip install -r requirements.txt
```

이 명령어는 다음 패키지들을 설치합니다:
- `fastapi`: FastAPI 웹 프레임워크
- `uvicorn`: ASGI 서버 (FastAPI 실행용)
- `jinja2`: 템플릿 엔진

## 서버 실행 방법

### 기본 실행 명령어

프로젝트 디렉토리(`fastapi_app`)에서 다음 명령어를 실행합니다:

```bash
python main.py
```

또는 uvicorn을 직접 사용하여 실행할 수 있습니다:

```bash
uvicorn main:app --host 0.0.0.0 --port 5000
```

### 개발 모드 실행 (자동 재시작)

코드 변경 시 자동으로 서버를 재시작하려면:

```bash
uvicorn main:app --host 0.0.0.0 --port 5000 --reload
```

## 브라우저 접속 주소

서버가 정상적으로 실행되면 다음 주소로 접속할 수 있습니다:

- **로컬 접속**: `http://localhost:5000`
- **로컬 네트워크 접속**: `http://127.0.0.1:5000`
- **외부 접속**: `http://[서버IP주소]:5000` (같은 네트워크 내의 다른 기기에서 접속)

## 서버 동작 확인 방법

### 1. "/" 경로 접속 확인

브라우저에서 `http://localhost:5000` 또는 `http://127.0.0.1:5000`으로 접속합니다.

**확인할 화면:**
- 화면 중앙에 "FastAPI 서버가 정상적으로 실행 중이다." 문구가 표시됩니다.
- 배경색은 연한 회색입니다.
- 제목이 크게 표시됩니다.

### 2. "/api/hello" API 테스트 방법

#### 방법 1: 브라우저에서 직접 접속

브라우저 주소창에 다음 주소를 입력합니다:
```
http://localhost:5000/api/hello
```

**예상 응답:**
```json
{
  "message": "Hello FastAPI"
}
```

#### 방법 2: curl 명령어 사용 (터미널/명령 프롬프트)

```bash
curl http://localhost:5000/api/hello
```

**예상 응답:**
```json
{"message":"Hello FastAPI"}
```

#### 방법 3: Python requests 라이브러리 사용

```python
import requests

response = requests.get("http://localhost:5000/api/hello")
print(response.json())
# 출력: {'message': 'Hello FastAPI'}
```

#### 방법 4: FastAPI 자동 생성 문서 사용

FastAPI는 자동으로 API 문서를 생성합니다:
- Swagger UI: `http://localhost:5000/docs`
- ReDoc: `http://localhost:5000/redoc`

이 페이지에서 API를 테스트할 수 있습니다.

## 자주 발생하는 오류와 해결 방법

### 오류 1: ModuleNotFoundError: No module named 'fastapi'

**원인:**
- requirements.txt의 패키지가 설치되지 않았습니다.

**해결 방법:**
```bash
pip install -r requirements.txt
```

### 오류 2: Address already in use (포트 5000이 이미 사용 중)

**원인:**
- 5000번 포트가 다른 프로그램에서 사용 중입니다.

**해결 방법:**
1. 다른 포트로 변경하여 실행:
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8000
   ```
   또는 `main.py` 파일에서 포트 번호를 변경합니다.

2. 5000번 포트를 사용하는 프로세스 종료:
   - Windows: 작업 관리자에서 해당 프로세스 종료
   - Linux/Mac: `lsof -i :5000` 명령어로 프로세스 확인 후 종료

## host=0.0.0.0의 의미

`host="0.0.0.0"`으로 설정하면:

- **모든 네트워크 인터페이스에서 접속을 허용**합니다.
- 로컬호스트(`localhost`, `127.0.0.1`)뿐만 아니라 같은 네트워크에 있는 다른 기기에서도 접속할 수 있습니다.
- 기본값인 `127.0.0.1`은 로컬호스트에서만 접속 가능합니다.

**예시:**
- `host="0.0.0.0"`: 로컬 + 네트워크 내 다른 기기 접속 가능
- `host="127.0.0.1"`: 로컬에서만 접속 가능

## 외부 접속을 위한 방화벽 포트 설정

같은 네트워크가 아닌 외부에서 접속하려면 방화벽에서 포트를 열어야 합니다.

### Windows 방화벽 설정

1. **제어판** → **시스템 및 보안** → **Windows Defender 방화벽**
2. **고급 설정** 클릭
3. **인바운드 규칙** → **새 규칙**
4. **포트** 선택 → **다음**
5. **TCP** 선택, **특정 로컬 포트**에 `5000` 입력 → **다음**
6. **연결 허용** 선택 → **다음**
7. 모든 프로필에 적용 → **다음**
8. 이름 입력 (예: "FastAPI Port 5000") → **완료**

### Linux 방화벽 설정 (ufw 사용 시)

```bash
sudo ufw allow 5000
```

### 주의사항

- 외부 접속을 허용하면 보안 위험이 있을 수 있습니다.
- 개발 환경에서는 로컬 접속만 허용하는 것을 권장합니다.
- 프로덕션 환경에서는 반드시 인증 및 보안 설정을 추가해야 합니다.

## 개발 환경에서 reload 사용 시 주의사항

`uvicorn --reload` 옵션을 사용하면 코드 변경 시 자동으로 서버가 재시작됩니다.

### 장점
- 코드 수정 후 수동으로 서버를 재시작할 필요가 없습니다.
- 개발 효율성이 향상됩니다.

### 주의사항

1. **파일 저장 시 자동 재시작**
   - Python 파일을 저장하면 즉시 서버가 재시작됩니다.
   - 저장하지 않은 변경사항은 반영되지 않습니다.

2. **재시작 중 요청 처리 지연**
   - 재시작 중에는 요청이 처리되지 않습니다.
   - 재시작이 완료될 때까지 잠시 기다려야 합니다.

3. **프로덕션 환경에서는 사용 금지**
   - `--reload` 옵션은 개발 환경에서만 사용해야 합니다.
   - 프로덕션 환경에서는 성능 저하 및 보안 문제가 발생할 수 있습니다.

4. **대용량 파일 변경 시**
   - 많은 파일을 한 번에 변경하면 재시작 시간이 길어질 수 있습니다.

### 프로덕션 실행 명령어

프로덕션 환경에서는 `--reload` 옵션 없이 실행합니다:

```bash
uvicorn main:app --host 0.0.0.0 --port 5000 --workers 4
```

## 추가 정보

- FastAPI 공식 문서: https://fastapi.tiangolo.com/
- Uvicorn 공식 문서: https://www.uvicorn.org/
- Jinja2 공식 문서: https://jinja.palletsprojects.com/
