# FastAPI REST API CRUD 구현 완료 요약

## 📋 추가/수정된 전체 파일 목록

### 새로 생성된 파일
1. `fastapi_crud_app.py` - CRUD 비즈니스 로직 (SQLite DB 처리)
2. `templates/users.html` - CRUD 테스트 웹페이지
3. `static/users.js` - CRUD JavaScript (fetch API)
4. `static/users.css` - CRUD 페이지 스타일
5. `CRUD_사용방법.md` - 사용 방법 가이드

### 수정된 파일
1. `main.py` - CRUD API 라우트 및 /users 페이지 라우트 추가
2. `requirements.txt` - email-validator 패키지 추가

---

## 📄 각 파일의 전체 코드

### 1. fastapi_crud_app.py

```python
"""
FastAPI REST API CRUD 연산
사용자 관리 시스템
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, EmailStr, Field
from typing import Optional
import sqlite3
from datetime import datetime
from pathlib import Path

# 현재 파일의 디렉토리 경로를 가져옵니다
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "app.db"

# Pydantic 모델: 요청 데이터 검증
class UserCreate(BaseModel):
    """사용자 생성 요청 모델"""
    name: str = Field(..., min_length=1, description="사용자 이름 (필수)")
    email: EmailStr = Field(..., description="이메일 주소 (필수, 고유)")
    age: Optional[int] = Field(None, ge=0, description="나이 (선택, 0 이상)")

class UserUpdate(BaseModel):
    """사용자 수정 요청 모델"""
    name: str = Field(..., min_length=1, description="사용자 이름 (필수)")
    email: EmailStr = Field(..., description="이메일 주소 (필수)")
    age: Optional[int] = Field(None, ge=0, description="나이 (선택, 0 이상)")

# 데이터베이스 초기화 함수
def init_db():
    """
    데이터베이스와 테이블을 초기화합니다.
    테이블이 없으면 자동으로 생성합니다.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # users 테이블 생성
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            age INTEGER,
            reg_date TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        )
    """)
    
    conn.commit()
    conn.close()
    print(f"데이터베이스 초기화 완료: {DB_PATH}")

# 앱 시작 시 데이터베이스 초기화
init_db()

# 데이터베이스 연결 헬퍼 함수
def get_db_connection():
    """데이터베이스 연결을 반환합니다."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # 딕셔너리 형태로 결과 반환
    return conn

# 날짜 포맷팅 함수
def format_date(date_str: str) -> str:
    """날짜를 YYYY-MM-DD 형태로 포맷합니다."""
    try:
        # SQLite의 datetime 형식을 파싱
        dt = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%Y-%m-%d")
    except:
        return date_str

# CRUD API 엔드포인트들

# (1) Create: 사용자 추가
# POST /api/users
def create_user(user: UserCreate):
    """
    새로운 사용자를 생성합니다.
    
    Args:
        user: 사용자 생성 요청 데이터
        
    Returns:
        dict: 생성 성공 응답 (status, id)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 이메일 중복 확인
        cursor.execute("SELECT id FROM users WHERE email = ?", (user.email,))
        if cursor.fetchone():
            raise HTTPException(
                status_code=400,
                detail={"status": "error", "message": "이미 존재하는 이메일입니다."}
            )
        
        # 사용자 추가
        cursor.execute("""
            INSERT INTO users (name, email, age)
            VALUES (?, ?, ?)
        """, (user.name, user.email, user.age))
        
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        
        return {"status": "success", "id": user_id}
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 생성 실패: {str(e)}"}
        )

# (2) Read: 사용자 목록 조회
# GET /api/users
def get_users():
    """
    모든 사용자 목록을 조회합니다.
    
    Returns:
        list: 사용자 목록 (JSON 배열)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT id, name, email, age, reg_date FROM users ORDER BY id")
        rows = cursor.fetchall()
        conn.close()
        
        # 딕셔너리 형태로 변환하고 날짜 포맷팅
        users = []
        for row in rows:
            user = dict(row)
            user["reg_date"] = format_date(user["reg_date"])
            users.append(user)
        
        return users
    
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 목록 조회 실패: {str(e)}"}
        )

# (3) Read: 사용자 1명 조회
# GET /api/users/{id}
def get_user(user_id: int):
    """
    특정 사용자를 조회합니다.
    
    Args:
        user_id: 사용자 ID
        
    Returns:
        dict: 사용자 정보
        
    Raises:
        HTTPException: 사용자를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT id, name, email, age, reg_date FROM users WHERE id = ?", (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {user_id}에 해당하는 사용자를 찾을 수 없습니다."}
            )
        
        user = dict(row)
        user["reg_date"] = format_date(user["reg_date"])
        return user
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 조회 실패: {str(e)}"}
        )

# (4) Update: 사용자 수정
# PUT /api/users/{id}
def update_user(user_id: int, user: UserUpdate):
    """
    사용자 정보를 수정합니다.
    
    Args:
        user_id: 사용자 ID
        user: 사용자 수정 요청 데이터
        
    Returns:
        dict: 수정된 사용자 정보
        
    Raises:
        HTTPException: 사용자를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 사용자 존재 확인
        cursor.execute("SELECT id FROM users WHERE id = ?", (user_id,))
        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {user_id}에 해당하는 사용자를 찾을 수 없습니다."}
            )
        
        # 이메일 중복 확인 (자기 자신 제외)
        cursor.execute("SELECT id FROM users WHERE email = ? AND id != ?", (user.email, user_id))
        if cursor.fetchone():
            raise HTTPException(
                status_code=400,
                detail={"status": "error", "message": "이미 존재하는 이메일입니다."}
            )
        
        # 사용자 정보 수정
        cursor.execute("""
            UPDATE users
            SET name = ?, email = ?, age = ?
            WHERE id = ?
        """, (user.name, user.email, user.age, user_id))
        
        conn.commit()
        
        # 수정된 사용자 정보 조회
        cursor.execute("SELECT id, name, email, age, reg_date FROM users WHERE id = ?", (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        user_dict = dict(row)
        user_dict["reg_date"] = format_date(user_dict["reg_date"])
        return user_dict
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 수정 실패: {str(e)}"}
        )

# (5) Delete: 사용자 삭제
# DELETE /api/users/{id}
def delete_user(user_id: int):
    """
    사용자를 삭제합니다.
    
    Args:
        user_id: 사용자 ID
        
    Returns:
        dict: 삭제 성공 응답
        
    Raises:
        HTTPException: 사용자를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 사용자 존재 확인
        cursor.execute("SELECT id FROM users WHERE id = ?", (user_id,))
        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {user_id}에 해당하는 사용자를 찾을 수 없습니다."}
            )
        
        # 사용자 삭제
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
        
        return {"status": "deleted"}
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"사용자 삭제 실패: {str(e)}"}
        )
```

---

### 2. main.py (수정된 부분만 표시)

```python
# CRUD 기능 import
from fastapi_crud_app import (
    UserCreate, UserUpdate,
    create_user, get_users, get_user, update_user, delete_user
)

# ========== CRUD API 엔드포인트 ==========

# (1) Create: 사용자 추가
@app.post("/api/users")
async def api_create_user(user: UserCreate):
    """새로운 사용자를 생성합니다. POST /api/users"""
    try:
        return create_user(user)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )

# (2) Read: 사용자 목록 조회
@app.get("/api/users")
async def api_get_users():
    """모든 사용자 목록을 조회합니다. GET /api/users"""
    try:
        return get_users()
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )

# (3) Read: 사용자 1명 조회
@app.get("/api/users/{user_id}")
async def api_get_user(user_id: int):
    """특정 사용자를 조회합니다. GET /api/users/{id}"""
    try:
        return get_user(user_id)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )

# (4) Update: 사용자 수정
@app.put("/api/users/{user_id}")
async def api_update_user(user_id: int, user: UserUpdate):
    """사용자 정보를 수정합니다. PUT /api/users/{id}"""
    try:
        return update_user(user_id, user)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )

# (5) Delete: 사용자 삭제
@app.delete("/api/users/{user_id}")
async def api_delete_user(user_id: int):
    """사용자를 삭제합니다. DELETE /api/users/{id}"""
    try:
        return delete_user(user_id)
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": str(e)}
        )

# ========== 웹페이지 라우트 ==========

# CRUD 테스트 페이지
@app.get("/users", response_class=HTMLResponse)
async def users_page(request: Request):
    """CRUD 테스트 페이지를 렌더링합니다. GET /users"""
    return templates.TemplateResponse("users.html", {"request": request})
```

---

### 3. templates/users.html

```html
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REST API CRUD 테스트</title>
    <link rel="stylesheet" href="/static/users.css">
</head>
<body>
    <div class="container">
        <h1>REST API CRUD 테스트 페이지</h1>
        
        <!-- 알림 영역 -->
        <div id="alert-area"></div>
        
        <!-- 사용자 목록 테이블 -->
        <div class="section">
            <h2>사용자 목록</h2>
            <table id="users-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>이름</th>
                        <th>이메일</th>
                        <th>나이</th>
                        <th>등록일</th>
                        <th>작업</th>
                    </tr>
                </thead>
                <tbody id="users-tbody">
                    <!-- JavaScript로 동적 생성 -->
                </tbody>
            </table>
        </div>
        
        <!-- 사용자 추가 폼 -->
        <div class="section">
            <h2>사용자 추가</h2>
            <form id="create-form">
                <div class="form-group">
                    <label for="create-name">이름 *</label>
                    <input type="text" id="create-name" required>
                </div>
                <div class="form-group">
                    <label for="create-email">이메일 *</label>
                    <input type="email" id="create-email" required>
                </div>
                <div class="form-group">
                    <label for="create-age">나이</label>
                    <input type="number" id="create-age" min="0">
                </div>
                <button type="submit" class="btn btn-primary">추가</button>
            </form>
        </div>
        
        <!-- 단일 사용자 조회 폼 -->
        <div class="section">
            <h2>단일 사용자 조회</h2>
            <form id="read-form">
                <div class="form-group">
                    <label for="read-id">사용자 ID</label>
                    <input type="number" id="read-id" min="1" required>
                </div>
                <button type="submit" class="btn btn-secondary">단일 조회</button>
            </form>
            <div id="read-result" class="result-box"></div>
        </div>
    </div>
    
    <script src="/static/users.js"></script>
</body>
</html>
```

---

### 4. static/users.js

```javascript
// REST API CRUD 테스트 JavaScript

// API 기본 URL
const API_BASE = '/api/users';

// 알림 메시지 표시 함수
function showAlert(message, type = 'success') {
    const alertArea = document.getElementById('alert-area');
    alertArea.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    
    // 3초 후 자동 제거
    setTimeout(() => {
        alertArea.innerHTML = '';
    }, 3000);
}

// 사용자 목록 불러오기
async function loadUsers() {
    try {
        const response = await fetch(API_BASE);
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || '목록 조회 실패');
        }
        
        const users = await response.json();
        renderUsersTable(users);
    } catch (error) {
        showAlert(`목록 조회 실패: ${error.message}`, 'error');
    }
}

// 사용자 테이블 렌더링
function renderUsersTable(users) {
    const tbody = document.getElementById('users-tbody');
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">등록된 사용자가 없습니다.</td></tr>';
        return;
    }
    
    tbody.innerHTML = users.map(user => `
        <tr data-user-id="${user.id}">
            <td>${user.id}</td>
            <td class="editable" data-field="name">${user.name}</td>
            <td class="editable" data-field="email">${user.email}</td>
            <td class="editable" data-field="age">${user.age || ''}</td>
            <td>${user.reg_date}</td>
            <td>
                <button class="btn btn-small btn-edit" onclick="editUser(${user.id})">수정</button>
                <button class="btn btn-small btn-delete" onclick="deleteUser(${user.id})">삭제</button>
            </td>
        </tr>
    `).join('');
}

// 사용자 추가
document.getElementById('create-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const name = document.getElementById('create-name').value.trim();
    const email = document.getElementById('create-email').value.trim();
    const age = document.getElementById('create-age').value;
    
    if (!name || !email) {
        showAlert('이름과 이메일은 필수 입력 항목입니다.', 'error');
        return;
    }
    
    try {
        const response = await fetch(API_BASE, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                name: name,
                email: email,
                age: age ? parseInt(age) : null
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 추가 실패');
        }
        
        showAlert(`사용자가 추가되었습니다. (ID: ${data.id})`, 'success');
        
        // 폼 초기화
        document.getElementById('create-form').reset();
        
        // 목록 다시 불러오기
        loadUsers();
    } catch (error) {
        showAlert(`추가 실패: ${error.message}`, 'error');
    }
});

// 단일 사용자 조회
document.getElementById('read-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const userId = document.getElementById('read-id').value;
    const resultBox = document.getElementById('read-result');
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`);
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 조회 실패');
        }
        
        resultBox.innerHTML = `<pre>${JSON.stringify(data, null, 2)}</pre>`;
        showAlert('사용자 조회 성공', 'success');
    } catch (error) {
        resultBox.innerHTML = `<pre class="error">${error.message}</pre>`;
        showAlert(`조회 실패: ${error.message}`, 'error');
    }
});

// 사용자 수정 모드 전환
let editingUserId = null;

function editUser(userId) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    if (!row) return;
    
    // 이미 편집 중인 경우 취소
    if (editingUserId && editingUserId !== userId) {
        cancelEdit(editingUserId);
    }
    
    editingUserId = userId;
    
    // 편집 가능한 필드를 입력 필드로 변경
    const editableCells = row.querySelectorAll('.editable');
    editableCells.forEach(cell => {
        const field = cell.getAttribute('data-field');
        const currentValue = cell.textContent.trim();
        
        if (field === 'age') {
            cell.innerHTML = `<input type="number" class="edit-input" data-field="${field}" value="${currentValue || ''}" min="0">`;
        } else {
            cell.innerHTML = `<input type="${field === 'email' ? 'email' : 'text'}" class="edit-input" data-field="${field}" value="${currentValue}" required>`;
        }
    });
    
    // 작업 버튼 변경
    const actionCell = row.querySelector('td:last-child');
    actionCell.innerHTML = `
        <button class="btn btn-small btn-save" onclick="saveUser(${userId})">저장</button>
        <button class="btn btn-small btn-cancel" onclick="cancelEdit(${userId})">취소</button>
    `;
}

// 수정 취소
function cancelEdit(userId) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    if (!row) return;
    
    // 원래 값으로 복원 (서버에서 다시 불러오기)
    loadUsers();
    editingUserId = null;
}

// 사용자 저장
async function saveUser(userId) {
    const row = document.querySelector(`tr[data-user-id="${userId}"]`);
    if (!row) return;
    
    const inputs = row.querySelectorAll('.edit-input');
    const userData = {};
    
    inputs.forEach(input => {
        const field = input.getAttribute('data-field');
        const value = input.value.trim();
        
        if (field === 'age') {
            userData[field] = value ? parseInt(value) : null;
        } else {
            userData[field] = value;
        }
    });
    
    // 필수 필드 검증
    if (!userData.name || !userData.email) {
        showAlert('이름과 이메일은 필수 입력 항목입니다.', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 수정 실패');
        }
        
        showAlert('사용자 정보가 수정되었습니다.', 'success');
        editingUserId = null;
        
        // 목록 다시 불러오기
        loadUsers();
    } catch (error) {
        showAlert(`수정 실패: ${error.message}`, 'error');
    }
}

// 사용자 삭제
async function deleteUser(userId) {
    if (!confirm(`정말로 사용자 ID ${userId}를 삭제하시겠습니까?`)) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || '사용자 삭제 실패');
        }
        
        showAlert('사용자가 삭제되었습니다.', 'success');
        
        // 목록 다시 불러오기
        loadUsers();
    } catch (error) {
        showAlert(`삭제 실패: ${error.message}`, 'error');
    }
}

// 페이지 로드 시 사용자 목록 불러오기
document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
});
```

---

### 5. static/users.css

```css
/* REST API CRUD 테스트 페이지 스타일 */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    padding: 20px;
    line-height: 1.6;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    background-color: white;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

h1 {
    color: #333;
    margin-bottom: 30px;
    text-align: center;
    font-size: 2em;
}

h2 {
    color: #555;
    margin-bottom: 20px;
    font-size: 1.5em;
    border-bottom: 2px solid #4CAF50;
    padding-bottom: 10px;
}

.section {
    margin-bottom: 40px;
}

/* 알림 영역 */
#alert-area {
    margin-bottom: 20px;
}

.alert {
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 10px;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

/* 테이블 스타일 */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background-color: white;
}

thead {
    background-color: #4CAF50;
    color: white;
}

th, td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
}

th {
    font-weight: bold;
}

/* Zebra-stripe 효과 */
tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

tbody tr:hover {
    background-color: #f1f1f1;
}

.text-center {
    text-align: center;
}

/* 편집 모드 입력 필드 */
.edit-input {
    width: 100%;
    padding: 5px;
    border: 1px solid #4CAF50;
    border-radius: 3px;
    font-size: 14px;
}

/* 폼 스타일 */
.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
    margin-bottom: 5px;
    color: #555;
    font-weight: 500;
}

input[type="text"],
input[type="email"],
input[type="number"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
}

input[type="text"]:focus,
input[type="email"]:focus,
input[type="number"]:focus {
    outline: none;
    border-color: #4CAF50;
    box-shadow: 0 0 5px rgba(76, 175, 80, 0.3);
}

/* 버튼 스타일 */
.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background-color 0.3s, transform 0.1s;
}

.btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.btn:active {
    transform: translateY(0);
}

.btn-primary {
    background-color: #4CAF50;
    color: white;
}

.btn-primary:hover {
    background-color: #45a049;
}

.btn-secondary {
    background-color: #2196F3;
    color: white;
}

.btn-secondary:hover {
    background-color: #0b7dda;
}

.btn-small {
    padding: 5px 10px;
    font-size: 12px;
    margin-right: 5px;
}

.btn-edit {
    background-color: #FF9800;
    color: white;
}

.btn-edit:hover {
    background-color: #e68900;
}

.btn-save {
    background-color: #4CAF50;
    color: white;
}

.btn-save:hover {
    background-color: #45a049;
}

.btn-cancel {
    background-color: #757575;
    color: white;
}

.btn-cancel:hover {
    background-color: #616161;
}

.btn-delete {
    background-color: #f44336;
    color: white;
}

.btn-delete:hover {
    background-color: #da190b;
}

/* 결과 박스 */
.result-box {
    margin-top: 15px;
    padding: 15px;
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.result-box pre {
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
    font-family: 'Courier New', monospace;
    font-size: 13px;
}

.result-box pre.error {
    color: #f44336;
}

/* 반응형 디자인 */
@media (max-width: 768px) {
    .container {
        padding: 15px;
    }
    
    table {
        font-size: 12px;
    }
    
    th, td {
        padding: 8px;
    }
    
    .btn-small {
        padding: 4px 8px;
        font-size: 11px;
    }
}
```

---

### 6. requirements.txt

```
# FastAPI 웹 프레임워크
fastapi>=0.104.0

# ASGI 서버 (FastAPI를 실행하기 위해 필요)
uvicorn[standard]>=0.24.0

# 템플릿 엔진 (Jinja2)
jinja2>=3.1.2

# 이메일 검증 (Pydantic EmailStr 사용 시 필요)
email-validator>=2.0.0
```

---

## ✅ 웹페이지에서 CRUD 동작 확인 절차

### 1단계: 서버 실행

```bash
cd fastapi_app
pip install -r requirements.txt
python main.py
```

서버가 정상 실행되면:
- 콘솔에 "데이터베이스 초기화 완료" 메시지 표시
- `app.db` 파일이 자동 생성됨

### 2단계: 브라우저 접속

브라우저에서 다음 주소로 접속:
```
http://localhost:5000/users
```

### 3단계: CRUD 기능 테스트

#### ✅ Create (추가) 테스트

1. **"사용자 추가"** 섹션으로 스크롤
2. 다음 정보 입력:
   - 이름: `홍길동`
   - 이메일: `hong@example.com`
   - 나이: `30`
3. **"추가"** 버튼 클릭
4. **확인 사항:**
   - ✅ 상단에 초록색 성공 메시지 표시: "사용자가 추가되었습니다. (ID: 1)"
   - ✅ 상단 테이블에 새 사용자 행이 추가됨
   - ✅ ID, 이름, 이메일, 나이, 등록일이 정확히 표시됨

**오류 테스트:**
- 동일한 이메일로 다시 추가 시도 → 빨간색 오류 메시지: "이미 존재하는 이메일입니다."
- 이름 없이 추가 시도 → "이름과 이메일은 필수 입력 항목입니다."

#### ✅ Read (조회) 테스트

**전체 조회:**
1. 페이지 상단의 **"사용자 목록"** 테이블 확인
2. **확인 사항:**
   - ✅ 추가한 사용자가 테이블에 표시됨
   - ✅ 모든 컬럼(ID, 이름, 이메일, 나이, 등록일, 작업)이 정상 표시됨
   - ✅ 등록일이 `YYYY-MM-DD` 형식으로 표시됨

**단일 조회:**
1. **"단일 사용자 조회"** 섹션으로 스크롤
2. 사용자 ID 입력: `1`
3. **"단일 조회"** 버튼 클릭
4. **확인 사항:**
   - ✅ 하단에 JSON 형태로 사용자 정보 표시
   - ✅ 모든 필드가 정확히 표시됨

**오류 테스트:**
- 존재하지 않는 ID (예: `999`) 입력 → 빨간색 오류 메시지: "ID 999에 해당하는 사용자를 찾을 수 없습니다."

#### ✅ Update (수정) 테스트

1. 테이블에서 수정할 사용자의 **"수정"** 버튼 클릭
2. **확인 사항:**
   - ✅ 해당 행의 이름, 이메일, 나이 필드가 입력 필드로 변경됨
   - ✅ "수정", "삭제" 버튼이 "저장", "취소" 버튼으로 변경됨
3. 이름을 `홍길동2`로 변경
4. **"저장"** 버튼 클릭
5. **확인 사항:**
   - ✅ 초록색 성공 메시지: "사용자 정보가 수정되었습니다."
   - ✅ 테이블에 수정된 이름이 반영됨
   - ✅ 버튼이 다시 "수정", "삭제"로 변경됨

**취소 테스트:**
- 수정 모드에서 **"취소"** 버튼 클릭 → 변경사항이 취소되고 원래 값으로 복원됨

**오류 테스트:**
- 다른 사용자의 이메일로 수정 시도 → "이미 존재하는 이메일입니다."

#### ✅ Delete (삭제) 테스트

1. 테이블에서 삭제할 사용자의 **"삭제"** 버튼 클릭
2. 확인 대화상자에서 **"확인"** 클릭
3. **확인 사항:**
   - ✅ 초록색 성공 메시지: "사용자가 삭제되었습니다."
   - ✅ 테이블에서 해당 사용자 행이 제거됨

**취소 테스트:**
- 삭제 확인 대화상자에서 **"취소"** 클릭 → 삭제되지 않음

**오류 테스트:**
- 이미 삭제된 ID로 다시 삭제 시도 → 404 오류 메시지

### 4단계: 종합 테스트 시나리오

1. **여러 사용자 추가**
   - 사용자 3명 이상 추가
   - 각각 다른 이름, 이메일, 나이 입력

2. **목록 확인**
   - 모든 사용자가 테이블에 정렬되어 표시되는지 확인
   - Zebra-stripe 스타일이 적용되어 있는지 확인

3. **수정 및 삭제 반복**
   - 여러 사용자를 수정하고 삭제
   - 각 작업 후 목록이 정상적으로 갱신되는지 확인

4. **에러 처리 확인**
   - 필수 필드 누락 시 오류 메시지 표시
   - 중복 이메일 입력 시 오류 메시지 표시
   - 존재하지 않는 ID 조회/수정/삭제 시 오류 메시지 표시

---

## 🎯 완료 체크리스트

- [x] SQLite 데이터베이스 설정 (app.db, users 테이블)
- [x] CRUD API 엔드포인트 5개 구현 (POST, GET 목록, GET 단일, PUT, DELETE)
- [x] Pydantic 모델로 입력 검증 (name, email 필수, age 선택)
- [x] 에러 처리 (JSON 응답, 404 처리)
- [x] 웹페이지 UI (users.html)
- [x] JavaScript로 CRUD 기능 구현 (users.js)
- [x] CSS 스타일링 (users.css)
- [x] /users 라우트 추가
- [x] 사용 방법 문서 작성

---

## 📝 참고사항

- 데이터베이스 파일(`app.db`)은 서버 실행 시 자동 생성됩니다.
- 모든 API 응답은 JSON 형식입니다.
- 에러 응답은 항상 `{"status": "error", "message": "..."}` 형식을 따릅니다.
- 날짜는 `YYYY-MM-DD` 형식으로 표시됩니다.
- 이메일은 고유값이어야 하며, 중복 시 오류가 발생합니다.
