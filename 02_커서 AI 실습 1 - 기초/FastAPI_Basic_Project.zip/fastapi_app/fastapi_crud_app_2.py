"""
FastAPI REST API CRUD 연산
도서 대여/관리 시스템
"""

from fastapi import HTTPException
from pydantic import BaseModel, Field, model_validator
from typing import Optional, Literal
import sqlite3
from datetime import datetime
from pathlib import Path

# 현재 파일의 디렉토리 경로를 가져옵니다
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "library.db"

# Pydantic 모델: 요청 데이터 검증
class BookCreate(BaseModel):
    """도서 생성 요청 모델"""
    title: str = Field(..., min_length=1, description="도서 제목 (필수)")
    author: str = Field(..., min_length=1, description="저자 (필수)")
    isbn: str = Field(..., min_length=1, description="ISBN (필수, 고유)")
    status: Literal["available", "borrowed"] = Field("available", description="대여 상태 (available/borrowed)")
    borrower: Optional[str] = Field(None, description="대여자 이름 (status가 borrowed일 때 필수)")

    @model_validator(mode='after')
    def validate_borrower(self):
        """status가 borrowed일 때 borrower 필수 검증"""
        if self.status == 'borrowed' and not self.borrower:
            raise ValueError('status가 borrowed일 때 borrower는 필수입니다.')
        # status가 available이면 borrower는 None으로 설정
        if self.status == 'available':
            self.borrower = None
        return self

class BookUpdate(BaseModel):
    """도서 수정 요청 모델"""
    title: str = Field(..., min_length=1, description="도서 제목 (필수)")
    author: str = Field(..., min_length=1, description="저자 (필수)")
    isbn: str = Field(..., min_length=1, description="ISBN (필수)")
    status: Literal["available", "borrowed"] = Field(..., description="대여 상태 (available/borrowed)")
    borrower: Optional[str] = Field(None, description="대여자 이름 (status가 borrowed일 때 필수)")

    @model_validator(mode='after')
    def validate_borrower(self):
        """status가 borrowed일 때 borrower 필수 검증"""
        if self.status == 'borrowed' and not self.borrower:
            raise ValueError('status가 borrowed일 때 borrower는 필수입니다.')
        # status가 available이면 borrower는 None으로 설정
        if self.status == 'available':
            self.borrower = None
        return self

# 데이터베이스 초기화 함수
def init_db():
    """
    데이터베이스와 테이블을 초기화합니다.
    테이블이 없으면 자동으로 생성합니다.
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # books 테이블 생성
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            isbn TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL DEFAULT 'available',
            borrower TEXT,
            reg_date TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
        )
    """)
    
    conn.commit()
    conn.close()
    print(f"데이터베이스 초기화 완료: {DB_PATH}")

# 앱 시작 시 데이터베이스 초기화
init_db()

# 데이터베이스 연결 헬퍼 함수
def get_db_connection():
    """데이터베이스 연결을 반환합니다."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # 딕셔너리 형태로 결과 반환
    return conn

# 날짜 포맷팅 함수
def format_date(date_str: str) -> str:
    """날짜를 YYYY-MM-DD 형태로 포맷합니다."""
    try:
        # SQLite의 datetime 형식을 파싱
        dt = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%Y-%m-%d")
    except:
        return date_str

# CRUD API 엔드포인트들

# (1) Create: 도서 추가
# POST /api/books
def create_book(book: BookCreate):
    """
    새로운 도서를 생성합니다.
    
    Args:
        book: 도서 생성 요청 데이터
        
    Returns:
        dict: 생성 성공 응답 (status, id)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # ISBN 중복 확인
        cursor.execute("SELECT id FROM books WHERE isbn = ?", (book.isbn,))
        if cursor.fetchone():
            raise HTTPException(
                status_code=400,
                detail={"status": "error", "message": "이미 존재하는 ISBN입니다."}
            )
        
        # status가 available이면 borrower는 None으로 설정
        borrower_value = None if book.status == "available" else book.borrower
        
        # 도서 추가
        cursor.execute("""
            INSERT INTO books (title, author, isbn, status, borrower)
            VALUES (?, ?, ?, ?, ?)
        """, (book.title, book.author, book.isbn, book.status, borrower_value))
        
        conn.commit()
        book_id = cursor.lastrowid
        conn.close()
        
        return {"status": "success", "id": book_id}
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"도서 생성 실패: {str(e)}"}
        )

# (2) Read: 도서 목록 조회
# GET /api/books
def get_books():
    """
    모든 도서 목록을 조회합니다.
    
    Returns:
        list: 도서 목록 (JSON 배열)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT id, title, author, isbn, status, borrower, reg_date FROM books ORDER BY id")
        rows = cursor.fetchall()
        conn.close()
        
        # 딕셔너리 형태로 변환하고 날짜 포맷팅
        books = []
        for row in rows:
            book = dict(row)
            book["reg_date"] = format_date(book["reg_date"])
            books.append(book)
        
        return books
    
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"도서 목록 조회 실패: {str(e)}"}
        )

# (3) Read: 도서 1권 조회
# GET /api/books/{id}
def get_book(book_id: int):
    """
    특정 도서를 조회합니다.
    
    Args:
        book_id: 도서 ID
        
    Returns:
        dict: 도서 정보
        
    Raises:
        HTTPException: 도서를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT id, title, author, isbn, status, borrower, reg_date FROM books WHERE id = ?", (book_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {book_id}에 해당하는 도서를 찾을 수 없습니다."}
            )
        
        book = dict(row)
        book["reg_date"] = format_date(book["reg_date"])
        return book
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"도서 조회 실패: {str(e)}"}
        )

# (4) Update: 도서 정보 수정
# PUT /api/books/{id}
def update_book(book_id: int, book: BookUpdate):
    """
    도서 정보를 수정합니다.
    
    Args:
        book_id: 도서 ID
        book: 도서 수정 요청 데이터
        
    Returns:
        dict: 수정된 도서 정보
        
    Raises:
        HTTPException: 도서를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 도서 존재 확인
        cursor.execute("SELECT id FROM books WHERE id = ?", (book_id,))
        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {book_id}에 해당하는 도서를 찾을 수 없습니다."}
            )
        
        # ISBN 중복 확인 (자기 자신 제외)
        cursor.execute("SELECT id FROM books WHERE isbn = ? AND id != ?", (book.isbn, book_id))
        if cursor.fetchone():
            raise HTTPException(
                status_code=400,
                detail={"status": "error", "message": "이미 존재하는 ISBN입니다."}
            )
        
        # status가 available이면 borrower는 None으로 설정
        borrower_value = None if book.status == "available" else book.borrower
        
        # 도서 정보 수정
        cursor.execute("""
            UPDATE books
            SET title = ?, author = ?, isbn = ?, status = ?, borrower = ?
            WHERE id = ?
        """, (book.title, book.author, book.isbn, book.status, borrower_value, book_id))
        
        conn.commit()
        
        # 수정된 도서 정보 조회
        cursor.execute("SELECT id, title, author, isbn, status, borrower, reg_date FROM books WHERE id = ?", (book_id,))
        row = cursor.fetchone()
        conn.close()
        
        book_dict = dict(row)
        book_dict["reg_date"] = format_date(book_dict["reg_date"])
        return book_dict
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"도서 수정 실패: {str(e)}"}
        )

# (5) Delete: 도서 삭제
# DELETE /api/books/{id}
def delete_book(book_id: int):
    """
    도서를 삭제합니다.
    
    Args:
        book_id: 도서 ID
        
    Returns:
        dict: 삭제 성공 응답
        
    Raises:
        HTTPException: 도서를 찾을 수 없을 때 404
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 도서 존재 확인
        cursor.execute("SELECT id FROM books WHERE id = ?", (book_id,))
        if not cursor.fetchone():
            raise HTTPException(
                status_code=404,
                detail={"status": "error", "message": f"ID {book_id}에 해당하는 도서를 찾을 수 없습니다."}
            )
        
        # 도서 삭제
        cursor.execute("DELETE FROM books WHERE id = ?", (book_id,))
        conn.commit()
        conn.close()
        
        return {"status": "deleted"}
    
    except HTTPException:
        conn.close()
        raise
    except Exception as e:
        conn.close()
        raise HTTPException(
            status_code=500,
            detail={"status": "error", "message": f"도서 삭제 실패: {str(e)}"}
        )
