# AI 제스처 비서 프로젝트

웹캠을 통해 손가락 개수를 인식하고, 손가락 개수에 따라 OpenAI API를 호출하여 AI 응답을 받는 Flask 웹 애플리케이션입니다.

## 📋 목차

- [주요 기능](#주요-기능)
- [기술 스택](#기술-스택)
- [프로젝트 구조](#프로젝트-구조)
- [설치 방법](#설치-방법)
- [사용 방법](#사용-방법)
- [제스처 매핑](#제스처-매핑)
- [문제 해결](#문제-해결)
- [개발 환경](#개발-환경)

## ✨ 주요 기능

- **실시간 손가락 인식**: MediaPipe를 사용하여 웹캠에서 손가락 개수를 실시간으로 인식
- **AI 응답 생성**: 손가락 개수에 따라 OpenAI GPT-4o-mini를 호출하여 맞춤형 응답 생성
- **웹 스트리밍**: Flask를 통해 웹 브라우저에서 실시간 비디오 스트리밍
- **한글 텍스트 표시**: PIL을 사용하여 웹캠 화면에 한글 텍스트 오버레이
- **자동 웹캠 탐지**: 여러 웹캠 중 사용 가능한 웹캠을 자동으로 탐지

## 🛠 기술 스택

- **Python 3.11+**
- **Flask**: 웹 프레임워크
- **OpenCV (opencv-contrib-python)**: 비디오 처리
- **MediaPipe 0.10.9**: 손가락 인식
- **OpenAI API**: AI 응답 생성
- **Pillow (PIL)**: 이미지 처리 및 한글 텍스트 렌더링
- **NumPy**: 배열 처리

## 📁 프로젝트 구조

```
Gesture_Detector_Project/
├── app.py                 # 메인 Flask 애플리케이션
├── gesture_detector.py    # MediaPipe 손가락 인식 모듈
├── openai_client.py      # OpenAI API 연동 모듈
├── requirements.txt      # Python 패키지 의존성
├── .env                  # 환경 변수 (API 키) - 생성 필요
├── .gitignore           # Git 제외 파일
└── templates/
    └── index.html        # 웹 페이지 템플릿
```

## 🚀 설치 방법

### 1. 저장소 클론 또는 프로젝트 폴더 생성

```bash
mkdir Gesture_Detector_Project
cd Gesture_Detector_Project
```

### 2. 가상 환경 생성 (권장)

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 3. 패키지 설치

```bash
pip install -r requirements.txt
```

**중요**: `mediapipe==0.10.9` 버전을 사용해야 합니다. 최신 버전(0.10.32+)에서는 `solutions` API가 제거되어 작동하지 않습니다.

### 4. 환경 변수 설정

프로젝트 루트에 `.env` 파일을 생성하고 OpenAI API 키를 추가하세요:

```env
OPENAI_API_KEY=your_api_key_here
```

OpenAI API 키는 [OpenAI Platform](https://platform.openai.com/api-keys)에서 발급받을 수 있습니다.

### 5. .gitignore 설정 (선택사항)

`.env` 파일이 Git에 커밋되지 않도록 `.gitignore` 파일을 생성하세요:

```
.env
__pycache__/
*.pyc
venv/
```

## 📖 사용 방법

### 1. 애플리케이션 실행

```bash
python app.py
```

### 2. 웹 브라우저에서 접속

브라우저에서 다음 주소로 접속하세요:

```
http://127.0.0.1:5000
```

### 3. 제스처 사용

웹캠에 손을 보여주고 손가락 개수에 따라 AI 응답을 받을 수 있습니다:

- **1개 손가락**: 오늘 뉴스 요청
- **2개 손가락**: 날씨 정보 요청
- **3개 손가락**: 명언 요청
- **4개 손가락**: 운동 루틴 요청
- **5개 손가락**: 인사 요청

## 🎯 제스처 매핑

손가락 개수에 따라 다음과 같은 프롬프트가 OpenAI API로 전송됩니다:

| 손가락 개수 | 프롬프트 |
|------------|---------|
| 1 | "오늘 뉴스를 알려줘" |
| 2 | "오늘 날씨 어때?" |
| 3 | "유명한 명언 하나 알려줘" |
| 4 | "간단한 운동 루틴 알려줘" |
| 5 | "나에게 인사해줘" |

프롬프트를 변경하려면 `openai_client.py`의 `gesture_map` 딕셔너리를 수정하세요.

## 🔧 문제 해결

### 웹캠이 인식되지 않음

- 웹캠이 컴퓨터에 연결되어 있는지 확인
- 다른 프로그램에서 웹캠을 사용 중인지 확인
- 웹캠 드라이버가 올바르게 설치되어 있는지 확인
- 앱을 재시작하면 0, 1, 2번 카메라를 자동으로 시도합니다

### AttributeError: module 'mediapipe' has no attribute 'solutions'

**원인**: `mediapipe` 버전이 0.10.9가 아닌 경우

**해결 방법**:
```bash
pip uninstall mediapipe
pip install mediapipe==0.10.9
```

### 한글 폰트가 표시되지 않음

**Windows**: 기본적으로 `C:/Windows/Fonts/malgun.ttf`를 사용합니다.

**Linux**: `app.py`의 `draw_korean_text` 함수에서 폰트 경로를 수정하세요:
```python
font_path = '/usr/share/fonts/truetype/nanum/NanumGothic.ttf'
```

### OpenAI API 오류

- `.env` 파일에 올바른 API 키가 설정되어 있는지 확인
- API 키에 충분한 크레딧이 있는지 확인
- 인터넷 연결 상태 확인

### NumPy 버전 충돌

`numpy<2.0` 제약이 `requirements.txt`에 포함되어 있습니다. 만약 문제가 발생하면:

```bash
pip uninstall numpy
pip install "numpy<2.0"
```

## 💻 개발 환경

- **Python**: 3.11 이상
- **운영체제**: Windows 10/11, Linux, macOS
- **웹캠**: USB 웹캠 (내장 웹캠 포함)

## 📝 주요 파일 설명

### app.py
- Flask 애플리케이션의 메인 파일
- 웹캠 초기화 및 비디오 스트리밍 처리
- 한글 텍스트 오버레이 기능
- Flask 라우트 정의

### gesture_detector.py
- MediaPipe를 사용한 손가락 인식 클래스
- `count_fingers()` 메서드로 손가락 개수 반환 (0-4, 엄지 제외)

### openai_client.py
- OpenAI API 클라이언트 초기화
- 제스처 매핑 딕셔너리
- `get_ai_response()` 함수로 AI 응답 생성

### templates/index.html
- 웹 페이지 템플릿
- 비디오 스트림을 표시하는 간단한 HTML 페이지

## 🔄 향후 개선 사항

- [ ] 엄지 포함 손가락 카운팅
- [ ] 더 많은 제스처 지원 (주먹, 손바닥 등)
- [ ] CSS 스타일링 개선
- [ ] 응답 텍스트 자동 줄바꿈
- [ ] 로깅 기능 추가
- [ ] 설정 파일 분리
- [ ] 에러 처리 강화

## 📄 라이선스

이 프로젝트는 교육 목적으로 제작되었습니다.

## 👤 작성자

AI 제스처 비서 프로젝트

## 🙏 참고 자료

- [MediaPipe Hands](https://google.github.io/mediapipe/solutions/hands)
- [OpenAI API Documentation](https://platform.openai.com/docs)
- [Flask Documentation](https://flask.palletsprojects.com/)

---

**참고**: 이 프로젝트는 실시간 비디오 처리를 수행하므로 충분한 CPU 성능과 웹캠이 필요합니다.
