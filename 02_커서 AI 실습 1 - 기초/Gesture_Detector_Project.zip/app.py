from flask import Flask, render_template, Response
import cv2
from gesture_detector import GestureDetector
from openai_client import get_ai_response
from PIL import ImageFont, ImageDraw, Image
import numpy as np
import os

app = Flask(__name__)

# 웹캠 인덱스 찾기 (0부터 시도)
def find_camera():
    for i in range(3):  # 0, 1, 2번 카메라 시도
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            ret, _ = cap.read()
            if ret:
                print(f"웹캠 {i}번을 사용합니다.")
                return cap, i
            cap.release()
    return None, -1

cap, camera_index = find_camera()
if cap is None:
    print("웹캠을 찾을 수 없습니다. 기본 카메라(0번)를 시도합니다.")
    cap = cv2.VideoCapture(0)

detector = GestureDetector()

latest_fingers = 0
latest_response = ""

# 한글 텍스트를 프레임에 표시하는 함수
def draw_korean_text(frame, text, position=(10, 30), font_size=24, font_path=None):
    if font_path is None:
        font_path = "C:/Windows/Fonts/malgun.ttf"  # Windows 기준
        # Linux일 경우 예: '/usr/share/fonts/truetype/nanum/NanumGothic.ttf'

    image_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(image_pil, 'RGBA')
    font = ImageFont.truetype(font_path, font_size)
    
    # 텍스트 크기 측정
    bbox = draw.textbbox(position, text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    # 반투명 검은색 배경 추가
    padding = 5
    bg_coords = [
        bbox[0] - padding,
        bbox[1] - padding,
        bbox[2] + padding,
        bbox[3] + padding
    ]
    draw.rectangle(bg_coords, fill=(0, 0, 0, 180))  # 반투명 검은색
    
    # 텍스트에 검은색 테두리 추가 (아웃라인 효과)
    outline_width = 2
    for adj in range(-outline_width, outline_width + 1):
        for adj2 in range(-outline_width, outline_width + 1):
            if adj != 0 or adj2 != 0:
                draw.text((position[0] + adj, position[1] + adj2), text, font=font, fill=(0, 0, 0, 255))
    
    # 흰색 텍스트 그리기
    draw.text(position, text, font=font, fill=(255, 255, 255, 255))
    
    return cv2.cvtColor(np.array(image_pil), cv2.COLOR_RGB2BGR)

def gen_frames():
    global latest_fingers, latest_response
    
    # 웹캠이 열려있는지 확인
    if not cap.isOpened():
        # 웹캠이 열리지 않았을 때 에러 메시지 이미지 생성
        error_frame = np.zeros((480, 640, 3), dtype=np.uint8)
        error_frame = draw_korean_text(error_frame, '웹캠을 찾을 수 없습니다', (50, 200), font_size=24)
        error_frame = draw_korean_text(error_frame, '카메라가 연결되어 있는지 확인하세요', (50, 250), font_size=18)
        _, buffer = cv2.imencode('.jpg', error_frame)
        frame = buffer.tobytes()
        while True:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    
    while True:
        success, frame = cap.read()
        if not success:
            # 프레임 읽기 실패 시 검은 화면 표시
            frame = np.zeros((480, 640, 3), dtype=np.uint8)
            frame = draw_korean_text(frame, '웹캠 연결 오류', (50, 200), font_size=24)
        else:
            fingers = detector.count_fingers(frame)
            if fingers != latest_fingers and fingers > 0:
                latest_fingers = fingers
                latest_response = get_ai_response(fingers)

            # 한글 텍스트 표시
            frame = draw_korean_text(frame, f'손가락 수: {latest_fingers}', (10, 30), font_size=20)
            frame = draw_korean_text(frame, latest_response, (10, 60), font_size=16)

        _, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == '__main__':
    app.run(debug=False)