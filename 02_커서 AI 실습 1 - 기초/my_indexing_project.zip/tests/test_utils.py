# tests/test_utils.py
import pytest
from utils import is_number, validate_numbers

def test_is_number():
    assert is_number(10) is True
    assert is_number(3.14) is True
    assert is_number("hello") is False

def test_validate_numbers_success():
    validate_numbers(1, 2, 3)  # 예외 발생 안 함

def test_validate_numbers_failure():
    with pytest.raises(ValueError):
        validate_numbers(1, "abc", 3)

