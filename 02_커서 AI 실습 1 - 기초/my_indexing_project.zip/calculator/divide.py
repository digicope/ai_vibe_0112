# calculator/divide.py
def divide(a: float, b: float) -> float:
    """두 수를 나눈다. b가 0일 경우 ZeroDivisionError 발생"""
    if b == 0:
        raise ZeroDivisionError("0으로 나눌 수 없습니다.")
    return a / b
