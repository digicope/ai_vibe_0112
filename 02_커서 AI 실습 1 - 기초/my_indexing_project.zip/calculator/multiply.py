# calculator/multiply.py
def multiply(a: float, b: float) -> float:
    """두 수를 곱한다"""
    return a * b

