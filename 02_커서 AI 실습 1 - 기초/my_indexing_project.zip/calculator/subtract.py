# calculator/subtract.py
def subtract(a: float, b: float) -> float:
    """두 수를 뺀다"""
    return a - b

