# calculator/add.py

def add(a: float, b: float) -> float:
    """두 수를 더한다"""
    return a + b

