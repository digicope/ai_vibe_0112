# main.py
from calculator import add, subtract, multiply, divide
from utils import log, validate_numbers

if __name__ == "__main__":
    log("프로그램 시작")

    x, y = 10, 5
    validate_numbers(x, y)

    print("덧셈:", add(x, y))
    print("뺄셈:", subtract(x, y))
    print("곱셈:", multiply(x, y))
    print("나눗셈:", divide(x, y))

    log("프로그램 종료")
