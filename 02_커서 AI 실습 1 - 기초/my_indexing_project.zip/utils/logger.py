# utils/logger.py
import datetime

def log(message: str) -> None:
    """메시지를 콘솔에 로그 형식으로 출력"""
    print(f"[{datetime.datetime.now()}] {message}")

