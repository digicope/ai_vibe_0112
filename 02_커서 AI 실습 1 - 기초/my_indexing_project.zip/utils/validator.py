# utils/validator.py
def is_number(value) -> bool:
    """값이 숫자인지 확인한다"""
    return isinstance(value, (int, float))


def validate_numbers(*args) -> None:
    """모든 인자가 숫자인지 검증한다. 아니면 ValueError 발생"""
    for arg in args:
        if not is_number(arg):
            raise ValueError(f"숫자가 아닌 값이 입력됨: {arg}")

