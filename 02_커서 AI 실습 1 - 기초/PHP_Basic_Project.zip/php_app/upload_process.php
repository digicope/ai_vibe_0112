<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>파일 업로드 결과 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>파일 업로드 결과</h1>
        
        <?php
        $uploadDir = 'uploads/';
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf'];
        $error = null;
        $success = false;
        $savedPath = null;
        
        // 업로드 폴더가 없으면 생성
        if (!file_exists($uploadDir)) {
            if (!mkdir($uploadDir, 0755, true)) {
                $error = "업로드 폴더를 생성할 수 없습니다.";
            }
        }
        
        // 파일이 업로드되었는지 확인
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
            $file = $_FILES['file'];
            
            // 업로드 에러 확인
            if ($file['error'] !== UPLOAD_ERR_OK) {
                switch ($file['error']) {
                    case UPLOAD_ERR_INI_SIZE:
                    case UPLOAD_ERR_FORM_SIZE:
                        $error = "파일 크기가 너무 큽니다.";
                        break;
                    case UPLOAD_ERR_PARTIAL:
                        $error = "파일이 부분적으로만 업로드되었습니다.";
                        break;
                    case UPLOAD_ERR_NO_FILE:
                        $error = "파일이 선택되지 않았습니다.";
                        break;
                    default:
                        $error = "파일 업로드 중 오류가 발생했습니다.";
                }
            } else {
                // 파일 확장자 검증
                $fileName = $file['name'];
                $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                
                if (!in_array($fileExtension, $allowedExtensions)) {
                    $error = "허용되지 않은 파일 확장자입니다. (허용: jpg, png, pdf)";
                } else {
                    // 파일명 중복 방지: 시간 + 랜덤값 사용
                    $timestamp = time();
                    $randomString = bin2hex(random_bytes(4));
                    $newFileName = $timestamp . '_' . $randomString . '.' . $fileExtension;
                    $targetPath = $uploadDir . $newFileName;
                    
                    // 파일 이동
                    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                        $success = true;
                        $savedPath = $targetPath;
                    } else {
                        $error = "파일을 저장하는 중 오류가 발생했습니다.";
                    }
                }
            }
        } else {
            $error = "잘못된 접근입니다. 파일을 선택하여 업로드해주세요.";
        }
        
        // 결과 출력
        if ($error !== null) {
            echo '<div class="error-message">';
            echo '<h2>업로드 실패</h2>';
            echo '<p>' . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . '</p>';
            echo '</div>';
        } elseif ($success) {
            echo '<div class="success-message">';
            echo '<h2>업로드 성공</h2>';
            echo '<p>파일이 성공적으로 업로드되었습니다.</p>';
            echo '<p><strong>저장된 경로:</strong> ' . htmlspecialchars($savedPath, ENT_QUOTES, 'UTF-8') . '</p>';
            echo '<p><strong>원본 파일명:</strong> ' . htmlspecialchars($fileName, ENT_QUOTES, 'UTF-8') . '</p>';
            echo '</div>';
        }
        ?>
        
        <div class="back-link">
            <a href="upload.php">← 업로드 페이지로 돌아가기</a>
        </div>
    </div>
</body>
</html>
