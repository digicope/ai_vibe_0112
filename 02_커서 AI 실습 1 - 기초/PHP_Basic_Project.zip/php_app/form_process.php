<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>폼 처리 결과 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>폼 처리 결과</h1>
        
        <?php
        // 에러 메시지를 저장할 배열
        $errors = [];
        
        // POST 데이터 받기 및 검증
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // name 필수 검증
            if (empty($_POST['name'])) {
                $errors[] = "이름은 필수 입력 항목입니다.";
            } else {
                $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
            }
            
            // email 필수 검증
            if (empty($_POST['email'])) {
                $errors[] = "이메일은 필수 입력 항목입니다.";
            } else {
                $email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
                // 이메일 형식 검증
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errors[] = "올바른 이메일 형식이 아닙니다.";
                }
            }
            
            // age 검증 (선택 사항, 숫자만 허용)
            if (isset($_POST['age']) && $_POST['age'] !== '') {
                if (!is_numeric($_POST['age'])) {
                    $errors[] = "나이는 숫자만 입력 가능합니다.";
                } else {
                    $age = htmlspecialchars($_POST['age'], ENT_QUOTES, 'UTF-8');
                }
            } else {
                $age = null;
            }
            
            // 에러가 있으면 표시
            if (!empty($errors)) {
                echo '<div class="error-message">';
                echo '<h2>입력 오류</h2>';
                echo '<ul>';
                foreach ($errors as $error) {
                    echo '<li>' . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . '</li>';
                }
                echo '</ul>';
                echo '</div>';
            } else {
                // 성공적으로 처리된 경우 데이터 출력
                echo '<div class="success-message">';
                echo '<h2>입력된 정보</h2>';
                echo '<p><strong>이름:</strong> ' . $name . '</p>';
                echo '<p><strong>이메일:</strong> ' . $email . '</p>';
                if ($age !== null) {
                    echo '<p><strong>나이:</strong> ' . $age . '세</p>';
                } else {
                    echo '<p><strong>나이:</strong> 입력되지 않음</p>';
                }
                echo '</div>';
            }
        } else {
            echo '<div class="error-message">';
            echo '<p>잘못된 접근입니다. 폼을 통해 데이터를 제출해주세요.</p>';
            echo '</div>';
        }
        ?>
        
        <div class="back-link">
            <a href="form.php">← 폼으로 돌아가기</a>
        </div>
    </div>
</body>
</html>
