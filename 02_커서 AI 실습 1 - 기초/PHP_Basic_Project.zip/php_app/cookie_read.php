<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>쿠키 읽기 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>쿠키 관리 실습 - 쿠키 읽기</h1>
        
        <?php
        // 쿠키 읽기
        if (isset($_COOKIE['name'])) {
            $name = htmlspecialchars($_COOKIE['name'], ENT_QUOTES, 'UTF-8');
            
            echo '<div class="success-message">';
            echo '<h2>저장된 쿠키</h2>';
            echo '<p><strong>이름:</strong> ' . $name . '</p>';
            echo '</div>';
            
            echo '<div class="cookie-info">';
            echo '<h3>쿠키 정보</h3>';
            echo '<p>쿠키 이름: name</p>';
            echo '<p>쿠키 값: ' . $name . '</p>';
            echo '</div>';
        } else {
            echo '<div class="error-message">';
            echo '<h2>쿠키가 없습니다</h2>';
            echo '<p>저장된 쿠키가 없습니다. 먼저 쿠키를 설정해주세요.</p>';
            echo '</div>';
        }
        ?>
        
        <div class="action-links">
            <a href="cookie_set.php" class="button-link">쿠키 설정 페이지로 이동</a>
        </div>
        
        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
