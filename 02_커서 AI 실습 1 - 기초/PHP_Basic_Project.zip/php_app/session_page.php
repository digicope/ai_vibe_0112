<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>세션 페이지 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>세션 페이지</h1>
        
        <?php
        // 세션 시작
        session_start();
        
        // 로그인 여부 확인
        if (isset($_SESSION['username'])) {
            $username = htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8');
            
            echo '<div class="success-message">';
            echo '<h2>환영합니다!</h2>';
            echo '<p><strong>' . $username . '</strong>님, 로그인하신 것을 환영합니다.</p>';
            echo '</div>';
            
            echo '<div class="session-info">';
            echo '<h3>세션 정보</h3>';
            echo '<p>세션 ID: ' . htmlspecialchars(session_id(), ENT_QUOTES, 'UTF-8') . '</p>';
            echo '<p>저장된 사용자명: ' . $username . '</p>';
            echo '</div>';
            
            echo '<div class="action-links">';
            echo '<a href="logout.php" class="button-link">로그아웃</a>';
            echo '</div>';
        } else {
            echo '<div class="error-message">';
            echo '<h2>로그인이 필요합니다</h2>';
            echo '<p>이 페이지를 보려면 먼저 로그인해야 합니다.</p>';
            echo '<p><a href="session_start.php">로그인 페이지로 이동</a></p>';
            echo '</div>';
        }
        ?>
        
        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
