# PHP 기능 단계별 실습 프로젝트

PHP의 기본 기능을 단계별로 학습할 수 있는 실습 프로젝트입니다.

## 📋 목차

- [실행 방법](#실행-방법)
- [파일 목록](#파일-목록)
- [자주 발생하는 오류](#자주-발생하는-오류)
- [XAMPP 설치 및 실행](#xampp-설치-및-실행)

## 🚀 실행 방법

### 방법 1: PHP 내장 웹 서버 사용 (권장)

터미널에서 다음 명령어를 실행합니다:

```bash
php -S localhost:8000 -t php_app
```

브라우저에서 다음 주소로 접속합니다:
- **메인 페이지**: http://localhost:8000/index.php

### 방법 2: XAMPP 사용

XAMPP를 설치한 경우 아래의 [XAMPP 설치 및 실행](#xampp-설치-및-실행) 섹션을 참고하세요.

브라우저에서 다음 주소로 접속합니다:
- **메인 페이지**: http://localhost/php_app/index.php

## 📁 파일 목록

각 실습 파일의 목적은 다음과 같습니다:

| 파일명 | 목적 |
|--------|------|
| `index.php` | 메인 메뉴 페이지 - 모든 실습 항목으로 이동할 수 있는 링크 제공 |
| `hello.php` | PHP 기본 문법 실습 - 변수, 날짜/시간 출력, 조건문 예시 |
| `form.php` | 폼 입력 페이지 - 이름, 이메일, 나이를 입력받는 폼 |
| `form_process.php` | 폼 데이터 처리 - POST 데이터 검증 및 안전하게 출력 |
| `calc.php` | 계산기 실습 - 두 숫자와 연산자를 입력받아 계산 결과 출력 |
| `upload.php` | 파일 업로드 폼 - 단일 파일 업로드 입력 폼 |
| `upload_process.php` | 파일 업로드 처리 - 파일 검증 및 저장 (jpg, png, pdf만 허용) |
| `session_start.php` | 세션 시작 및 로그인 시뮬레이션 - username을 세션에 저장 |
| `session_page.php` | 세션 정보 확인 - 저장된 세션 데이터를 읽어 화면에 출력 |
| `logout.php` | 로그아웃 처리 - 세션 종료 및 로그아웃 완료 메시지 |
| `cookie_set.php` | 쿠키 설정 - name 쿠키를 1일 유효기간으로 저장 |
| `cookie_read.php` | 쿠키 읽기 - 저장된 쿠키를 읽어 화면에 출력 |
| `style.css` | 스타일시트 - 모든 페이지에 적용되는 공통 스타일 |

## ⚠️ 자주 발생하는 오류

### 1. 세션 관련 오류: "Warning: session_start(): Cannot send session cache limiter"

**원인**: `session_start()` 함수 호출 전에 HTML 출력이 발생한 경우

**해결 방법**:
- `session_start()`를 파일의 최상단, `<!DOCTYPE html>` 태그 이전에 위치시킵니다
- PHP 코드 블록이 HTML 이전에 오도록 파일 구조를 확인합니다

```php
<?php
session_start();
?>
<!DOCTYPE html>
<html>
...
```

### 2. 파일 업로드 오류: "The uploaded file exceeds the upload_max_filesize"

**원인**: PHP 설정에서 허용하는 최대 파일 크기를 초과한 경우

**해결 방법**:
- `php.ini` 파일에서 다음 설정값을 수정합니다:
  - `upload_max_filesize = 10M` (또는 원하는 크기)
  - `post_max_size = 10M` (upload_max_filesize보다 크게 설정)
- Apache를 재시작합니다 (XAMPP Control Panel 사용)

## 💻 XAMPP 설치 및 실행

### 1. XAMPP 설치

1. https://www.apachefriends.org/download.html 에서 XAMPP 다운로드 (약 144MB)
2. 다운로드한 설치 파일을 실행하여 설치 진행
3. 설치 완료 후 XAMPP Control Panel 실행

### 2. Apache 시작

1. XAMPP Control Panel을 실행합니다
2. Apache 옆의 "Start" 버튼을 클릭하여 Apache 서버를 시작합니다
3. Apache가 정상적으로 시작되면 초록색으로 표시됩니다

### 3. 소스 파일 복사

`C:\xampp\htdocs\` 아래에 `php_app` 폴더를 미리 생성한 후, PowerShell에서 다음 명령어를 실행합니다:

```powershell
Copy-Item -Path .\php_app\* -Destination 'C:\xampp\htdocs\php_app\' -Recurse -Force
```

또는 수동으로 `php_app` 폴더의 모든 파일을 `C:\xampp\htdocs\php_app\` 폴더로 복사합니다.

### 4. 브라우저에서 접속

브라우저에서 다음 주소로 접속합니다:
- **메인 페이지**: http://localhost/php_app/index.php

## 📝 참고사항

- 파일 업로드 기능을 사용하려면 `uploads/` 폴더가 자동으로 생성됩니다
- 세션과 쿠키는 브라우저를 닫아도 유지될 수 있습니다 (쿠키는 1일 유효)
- 모든 사용자 입력값은 `htmlspecialchars()` 함수로 XSS 공격을 방지합니다
