<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>쿠키 설정 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>쿠키 관리 실습 - 쿠키 설정</h1>
        
        <?php
        // 쿠키 설정 처리
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name'])) {
            $name = trim($_POST['name']);
            
            if (!empty($name)) {
                // 쿠키 유효기간: 1일 (86400초)
                $expire = time() + (86400 * 1);
                
                // 쿠키 설정
                setcookie('name', htmlspecialchars($name, ENT_QUOTES, 'UTF-8'), $expire, '/');
                
                echo '<div class="success-message">';
                echo '<h2>쿠키가 설정되었습니다</h2>';
                echo '<p>쿠키가 성공적으로 저장되었습니다. (유효기간: 1일)</p>';
                echo '<p><a href="cookie_read.php">쿠키 읽기 페이지로 이동</a></p>';
                echo '</div>';
            } else {
                echo '<div class="error-message">';
                echo '<p>이름을 입력해주세요.</p>';
                echo '</div>';
            }
        }
        ?>
        
        <form method="POST" action="cookie_set.php">
            <div class="form-group">
                <label for="name">이름:</label>
                <input type="text" id="name" name="name" 
                       value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8') : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <button type="submit">쿠키 저장</button>
            </div>
        </form>
        
        <div class="info-message">
            <p><strong>참고:</strong> 쿠키는 1일 동안 유효합니다.</p>
            <p><a href="cookie_read.php">쿠키 읽기 페이지로 이동</a></p>
        </div>
        
        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
