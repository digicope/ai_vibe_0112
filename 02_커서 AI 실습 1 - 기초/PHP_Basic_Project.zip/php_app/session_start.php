<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>세션 시작 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>세션 관리 실습 - 로그인</h1>
        
        <?php
        // 세션 시작
        session_start();
        
        // 이미 로그인되어 있는지 확인
        if (isset($_SESSION['username'])) {
            echo '<div class="info-message">';
            echo '<p>이미 로그인되어 있습니다. (' . htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8') . ')</p>';
            echo '<p><a href="session_page.php">세션 페이지로 이동</a></p>';
            echo '</div>';
        }
        
        // 로그인 처리
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
            $username = trim($_POST['username']);
            
            if (!empty($username)) {
                // 세션에 username 저장
                $_SESSION['username'] = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
                
                // session_page.php로 리다이렉트
                header('Location: session_page.php');
                exit();
            } else {
                echo '<div class="error-message">';
                echo '<p>사용자명을 입력해주세요.</p>';
                echo '</div>';
            }
        }
        ?>
        
        <?php if (!isset($_SESSION['username'])): ?>
        <form method="POST" action="session_start.php">
            <div class="form-group">
                <label for="username">사용자명:</label>
                <input type="text" id="username" name="username" 
                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username'], ENT_QUOTES, 'UTF-8') : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <button type="submit">로그인</button>
            </div>
        </form>
        <?php endif; ?>
        
        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
