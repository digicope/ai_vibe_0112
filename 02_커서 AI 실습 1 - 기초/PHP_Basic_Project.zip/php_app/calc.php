<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>계산기 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>계산기 실습</h1>
        
        <?php
        $result = null;
        $error = null;
        
        // 초기화 요청이 있는 경우 POST 데이터 무시
        $isReset = isset($_GET['reset']) && $_GET['reset'] == '1';
        
        // POST 요청이 있고 폼이 제출된 경우 (초기화 요청이 아닐 때만)
        if (!$isReset && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['num1']) && isset($_POST['num2']) && isset($_POST['op'])) {
            $num1 = $_POST['num1'];
            $num2 = $_POST['num2'];
            $op = $_POST['op'];
            
            // 숫자 검증
            if (is_numeric($num1) && is_numeric($num2)) {
                $num1 = (float)$num1;
                $num2 = (float)$num2;
                
                // 연산 수행
                switch ($op) {
                    case '+':
                        $result = $num1 + $num2;
                        break;
                    case '-':
                        $result = $num1 - $num2;
                        break;
                    case '*':
                        $result = $num1 * $num2;
                        break;
                    case '/':
                        if ($num2 == 0) {
                            $error = "0으로 나눌 수 없습니다.";
                        } else {
                            $result = $num1 / $num2;
                        }
                        break;
                    default:
                        $error = "올바른 연산자를 선택해주세요.";
                }
            } else {
                $error = "숫자만 입력 가능합니다.";
            }
        }
        ?>
        
        <form method="POST" action="calc.php">
            <div class="form-group">
                <label for="num1">첫 번째 숫자:</label>
                <input type="number" id="num1" name="num1" step="any" 
                       value="<?php echo (!$isReset && isset($_POST['num1'])) ? htmlspecialchars($_POST['num1'], ENT_QUOTES, 'UTF-8') : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label for="op">연산자:</label>
                <select id="op" name="op" required>
                    <option value="+" <?php echo (!$isReset && isset($_POST['op']) && $_POST['op'] === '+') ? 'selected' : ''; ?>>+ (더하기)</option>
                    <option value="-" <?php echo (!$isReset && isset($_POST['op']) && $_POST['op'] === '-') ? 'selected' : ''; ?>>- (빼기)</option>
                    <option value="*" <?php echo (!$isReset && isset($_POST['op']) && $_POST['op'] === '*') ? 'selected' : ''; ?>>× (곱하기)</option>
                    <option value="/" <?php echo (!$isReset && isset($_POST['op']) && $_POST['op'] === '/') ? 'selected' : ''; ?>>÷ (나누기)</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="num2">두 번째 숫자:</label>
                <input type="number" id="num2" name="num2" step="any" 
                       value="<?php echo (!$isReset && isset($_POST['num2'])) ? htmlspecialchars($_POST['num2'], ENT_QUOTES, 'UTF-8') : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <button type="submit">계산하기</button>
                <a href="calc.php?reset=1" class="button-link">초기화</a>
            </div>
        </form>
        
        <?php
        // 결과 또는 에러 메시지 표시
        if ($error !== null) {
            echo '<div class="error-message">';
            echo '<p>' . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . '</p>';
            echo '</div>';
        } elseif ($result !== null) {
            $num1_display = isset($_POST['num1']) ? htmlspecialchars($_POST['num1'], ENT_QUOTES, 'UTF-8') : '';
            $num2_display = isset($_POST['num2']) ? htmlspecialchars($_POST['num2'], ENT_QUOTES, 'UTF-8') : '';
            $op_display = isset($_POST['op']) ? htmlspecialchars($_POST['op'], ENT_QUOTES, 'UTF-8') : '';
            
            echo '<div class="success-message">';
            echo '<h2>계산 결과</h2>';
            echo '<p>' . $num1_display . ' ' . $op_display . ' ' . $num2_display . ' = <strong>' . $result . '</strong></p>';
            echo '</div>';
        }
        ?>
        
        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
