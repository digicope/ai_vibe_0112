<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello World - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Hello World - PHP 기본 문법 실습</h1>
        
        <?php
        // 한국(서울) 시간대 설정
        date_default_timezone_set('Asia/Seoul');
        ?>
        
        <section>
            <h2>1. 현재 날짜/시간 출력</h2>
            <p>현재 날짜/시간: <?php echo date('Y-m-d H:i:s'); ?></p>
        </section>

        <section>
            <h2>2. 변수 선언 및 문자열 합치기</h2>
            <?php
            $greeting = "안녕하세요";
            $name = "PHP 학습자";
            $message = $greeting . ", " . $name . "님!";
            ?>
            <p>변수 1: <?php echo $greeting; ?></p>
            <p>변수 2: <?php echo $name; ?></p>
            <p>합친 결과: <?php echo $message; ?></p>
        </section>

        <section>
            <h2>3. 조건문(if) 예시</h2>
            <?php
            $hour = (int)date('H');
            if ($hour < 12) {
                $timeGreeting = "좋은 아침입니다!";
            } elseif ($hour < 18) {
                $timeGreeting = "좋은 오후입니다!";
            } else {
                $timeGreeting = "좋은 저녁입니다!";
            }
            ?>
            <p>현재 시간: <?php echo $hour; ?>시</p>
            <p>인사말: <?php echo $timeGreeting; ?></p>
        </section>

        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
