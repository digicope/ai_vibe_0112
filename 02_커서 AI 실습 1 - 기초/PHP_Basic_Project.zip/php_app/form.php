<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>폼 처리 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>폼 처리 실습</h1>
        
        <form method="POST" action="form_process.php">
            <div class="form-group">
                <label for="name">이름:</label>
                <input type="text" id="name" name="name" required>
            </div>
            
            <div class="form-group">
                <label for="email">이메일:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="form-group">
                <label for="age">나이:</label>
                <input type="number" id="age" name="age" min="1" max="150" required>
            </div>
            
            <div class="form-group">
                <button type="submit">제출</button>
                <button type="reset">초기화</button>
            </div>
        </form>
        
        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
