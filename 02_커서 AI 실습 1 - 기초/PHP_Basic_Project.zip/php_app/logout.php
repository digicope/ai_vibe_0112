<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그아웃 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>로그아웃</h1>
        
        <?php
        // 세션 시작
        session_start();
        
        // 세션 변수 제거
        session_unset();
        
        // 세션 파괴
        session_destroy();
        ?>
        
        <div class="success-message">
            <h2>로그아웃 완료</h2>
            <p>성공적으로 로그아웃되었습니다.</p>
        </div>
        
        <div class="action-links">
            <a href="session_start.php" class="button-link">다시 로그인</a>
            <a href="index.php" class="button-link">메인 메뉴</a>
        </div>
    </div>
</body>
</html>
