<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>파일 업로드 - PHP 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>파일 업로드 실습</h1>
        
        <div class="upload-info">
            <p><strong>업로드 허용 확장자:</strong> jpg, png, pdf</p>
        </div>
        
        <form method="POST" action="upload_process.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="file">파일 선택:</label>
                <input type="file" id="file" name="file" accept=".jpg,.jpeg,.png,.pdf" required>
            </div>
            
            <div class="form-group">
                <button type="submit">업로드</button>
                <button type="reset">초기화</button>
            </div>
        </form>
        
        <div class="back-link">
            <a href="index.php">← 메인 메뉴로 돌아가기</a>
        </div>
    </div>
</body>
</html>
