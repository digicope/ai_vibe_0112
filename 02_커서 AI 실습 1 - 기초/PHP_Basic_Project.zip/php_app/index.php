<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP 기능 단계별 실습</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>PHP 기능 단계별 실습</h1>
        <nav class="menu">
            <ul>
                <li><a href="hello.php">Hello World</a></li>
                <li><a href="form.php">폼 처리</a></li>
                <li><a href="calc.php">계산기</a></li>
                <li><a href="upload.php">파일 업로드</a></li>
                <li><a href="session_start.php">세션 관리</a></li>
                <li><a href="cookie_set.php">쿠키 관리</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>
