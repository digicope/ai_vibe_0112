# Flask 기본 웹 서버 프로젝트

이 프로젝트는 Flask를 사용한 기본 웹 서버 실습 프로젝트입니다.

## 프로젝트 구조

```
/flask_app/
 ┣ app.py              # 기본 Flask 웹 서버
 ┣ api.py              # REST API CRUD 서버
 ┣ requirements.txt
 ┣ templates/
 ┃ ┗ index.html
 ┗ static/
     ┗ style.css
```

## 설치 및 실행 방법

### 1. requirements.txt 설치 방법

프로젝트에 필요한 패키지를 설치합니다.

**Windows (PowerShell 또는 CMD):**
```bash
pip install -r flask_app/requirements.txt
```

**macOS/Linux:**
```bash
pip3 install -r flask_app/requirements.txt
```

또는 가상 환경을 사용하는 경우:
```bash
# 가상 환경 생성 (선택사항)
python -m venv venv

# 가상 환경 활성화
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 패키지 설치
pip install -r flask_app/requirements.txt
```

### 2. Flask 서버 실행 명령어

**Windows (PowerShell 또는 CMD):**
```bash
python flask_app/app.py
```

**macOS/Linux:**
```bash
python3 flask_app/app.py
```

서버가 정상적으로 실행되면 다음과 같은 메시지가 표시됩니다:
```
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
 * Running on http://[your-ip]:5000
```

### 3. 브라우저에서 접속할 주소

서버 실행 후 다음 주소로 접속할 수 있습니다:

- **로컬 접속:** `http://localhost:5000` 또는 `http://127.0.0.1:5000`
- **네트워크 접속:** `http://0.0.0.0:5000` (같은 네트워크의 다른 기기에서도 접속 가능)

## 서버 동작 확인 방법

### 4. Flask 서버가 정상 동작하는지 확인하는 테스트 방법

서버가 정상적으로 실행되었는지 확인하는 방법:

1. **터미널 메시지 확인:**
   - 서버 실행 시 "Running on..." 메시지가 표시되면 정상 동작 중입니다.

2. **브라우저 접속 확인:**
   - 브라우저에서 `http://localhost:5000`으로 접속하여 페이지가 로드되는지 확인합니다.

3. **API 엔드포인트 테스트:**
   - `http://localhost:5000/api/hello`로 접속하여 JSON 응답을 확인합니다.

### 5. "/" 경로 접속 시 확인할 화면

브라우저에서 `http://localhost:5000`으로 접속하면 다음을 확인할 수 있습니다:

- **배경:** 연한 회색 배경
- **텍스트:** 화면 중앙에 "Flask 서버가 정상적으로 실행 중이다." 문구가 크게 표시됨
- **스타일:** CSS가 적용되어 텍스트가 중앙 정렬되고 크게 표시됨

### 6. "/api/hello" API 테스트 방법

#### 방법 1: 브라우저에서 직접 접속
브라우저 주소창에 다음 주소를 입력:
```
http://localhost:5000/api/hello
```

**예상 응답:**
```json
{
  "message": "Hello Flask API"
}
```

#### 방법 2: curl 명령어 사용 (터미널)
```bash
curl http://localhost:5000/api/hello
```

**예상 출력:**
```json
{"message":"Hello Flask API"}
```

#### 방법 3: PowerShell의 Invoke-WebRequest 사용 (Windows)
```powershell
Invoke-WebRequest -Uri http://localhost:5000/api/hello | Select-Object -ExpandProperty Content
```

#### 방법 4: Python requests 라이브러리 사용
```python
import requests

response = requests.get('http://localhost:5000/api/hello')
print(response.json())
```

## 자주 발생하는 오류 및 해결 방법

### 오류 1: ModuleNotFoundError: No module named 'flask'

**증상:**
```
Traceback (most recent call last):
  File "flask_app/app.py", line 2, in <module>
    from flask import Flask, render_template, jsonify
ModuleNotFoundError: No module named 'flask'
```

**원인:**
- Flask가 설치되지 않았거나, 다른 Python 환경에서 실행하고 있을 수 있습니다.

**해결 방법:**
1. requirements.txt를 사용하여 Flask를 설치합니다:
   ```bash
   pip install -r flask_app/requirements.txt
   ```

2. 또는 직접 Flask를 설치합니다:
   ```bash
   pip install Flask==3.1.2
   ```

3. 가상 환경을 사용하는 경우, 가상 환경이 활성화되어 있는지 확인합니다.

### 오류 2: Address already in use (포트 5000이 이미 사용 중)

**증상:**
```
OSError: [Errno 48] Address already in use
또는
OSError: [WinError 10048] Only one usage of each socket address (protocol/network address/port) is normally permitted
```

**원인:**
- 포트 5000이 이미 다른 프로세스에서 사용 중입니다.
- 이전에 실행한 Flask 서버가 아직 종료되지 않았을 수 있습니다.

**해결 방법:**
1. **이전 Flask 서버 종료:**
   - 실행 중인 터미널에서 `Ctrl + C`를 눌러 서버를 종료합니다.

2. **포트를 사용하는 프로세스 확인 및 종료 (Windows):**
   ```powershell
   # 포트 5000을 사용하는 프로세스 확인
   netstat -ano | findstr :5000
   
   # 프로세스 ID(PID)를 확인한 후 종료
   taskkill /PID [PID번호] /F
   ```

3. **포트를 사용하는 프로세스 확인 및 종료 (macOS/Linux):**
   ```bash
   # 포트 5000을 사용하는 프로세스 확인
   lsof -i :5000
   
   # 프로세스 종료
   kill -9 [PID번호]
   ```

4. **다른 포트 사용:**
   - `app.py` 파일에서 포트 번호를 변경할 수 있습니다:
   ```python
   app.run(host="0.0.0.0", port=5001, debug=True)  # 포트를 5001로 변경
   ```

## 추가 정보

- **디버그 모드:** 현재 `debug=True`로 설정되어 있어 코드 변경 시 자동으로 서버가 재시작됩니다.
- **호스트 설정:** `host="0.0.0.0"`으로 설정되어 있어 같은 네트워크의 다른 기기에서도 접속할 수 있습니다.
- **포트:** 기본 포트는 5000번입니다.

## 클라우드 VM 배포 가이드 (GCP Compute Engine 등)

클라우드 VM에 Flask 서버를 배포하여 외부에서 접속할 수 있도록 설정하는 방법입니다.

### 1. host=0.0.0.0의 의미

`host="0.0.0.0"` 설정은 Flask 서버가 **모든 네트워크 인터페이스**에서 들어오는 요청을 수신하도록 합니다.

**설명:**
- **`127.0.0.1` 또는 `localhost`:** 로컬 머신에서만 접속 가능 (VM 내부에서만 접속)
- **`0.0.0.0`:** 모든 네트워크 인터페이스에서 접속 허용 (외부에서도 접속 가능)

**왜 필요한가?**
- 클라우드 VM에 배포할 때는 외부 인터넷에서 접속해야 하므로 `0.0.0.0`으로 설정해야 합니다.
- `127.0.0.1`로 설정하면 VM 내부에서만 접속 가능하고, 외부에서는 접속할 수 없습니다.

**현재 설정 확인:**
```python
# app.py 파일의 마지막 부분
app.run(host="0.0.0.0", port=5000, debug=True)  # ✅ 외부 접속 가능
```

### 2. 외부 접속을 위한 방화벽 포트 설정

클라우드 VM에서 외부 접속을 허용하려면 **방화벽 규칙**을 설정해야 합니다.

#### GCP (Google Cloud Platform) Compute Engine 설정

1. **GCP 콘솔에서 방화벽 규칙 생성:**
   - GCP 콘솔 → VPC 네트워크 → 방화벽 규칙
   - "방화벽 규칙 만들기" 클릭

2. **방화벽 규칙 설정:**
   - **이름:** `allow-flask-5000` (원하는 이름)
   - **방향:** 수신 (Ingress)
   - **대상:** 네트워크의 모든 인스턴스
   - **소스 IP 범위:** `0.0.0.0/0` (모든 IP 허용) 또는 특정 IP만 허용
   - **프로토콜 및 포트:** 
     - TCP 체크
     - 포트: `5000` 입력
   - **작업:** 허용

3. **VM 인스턴스에 태그 추가 (선택사항):**
   - VM 인스턴스 편집 → 네트워크 태그에 `flask-server` 추가
   - 방화벽 규칙의 "대상"을 "지정된 대상 태그"로 설정하고 `flask-server` 입력

#### AWS EC2 설정

1. **보안 그룹 규칙 추가:**
   - EC2 콘솔 → 보안 그룹 선택
   - "인바운드 규칙 편집" 클릭
   - 규칙 추가:
     - **유형:** 사용자 지정 TCP
     - **포트 범위:** `5000`
     - **소스:** `0.0.0.0/0` (모든 IP) 또는 특정 IP
     - **설명:** Flask Server

#### Azure VM 설정

1. **네트워크 보안 그룹 설정:**
   - Azure Portal → 네트워크 보안 그룹 선택
   - "인바운드 보안 규칙" → "추가" 클릭
   - 설정:
     - **대상 포트 범위:** `5000`
     - **프로토콜:** TCP
     - **작업:** 허용
     - **우선순위:** 적절한 값 설정
     - **이름:** `AllowFlask5000`

#### 방화벽 설정 확인 방법

VM에 SSH 접속 후 다음 명령어로 포트가 열려있는지 확인:

```bash
# Linux/macOS
sudo netstat -tlnp | grep 5000
# 또는
sudo ss -tlnp | grep 5000

# 방화벽 상태 확인 (Ubuntu/Debian)
sudo ufw status

# 방화벽 상태 확인 (CentOS/RHEL)
sudo firewall-cmd --list-all
```

**로컬 방화벽도 확인:**
- VM 내부 방화벽(iptables, firewalld 등)도 포트 5000을 열어야 할 수 있습니다.

### 3. debug 모드 사용 시 주의사항

**⚠️ 프로덕션 환경에서는 `debug=False`로 설정해야 합니다!**

#### debug=True의 위험성

1. **보안 취약점:**
   - 디버그 모드는 **상세한 에러 정보**를 노출합니다.
   - 스택 트레이스에 소스 코드, 파일 경로, 변수 값 등이 포함될 수 있습니다.
   - 공격자가 애플리케이션 구조를 파악하는 데 악용될 수 있습니다.

2. **성능 문제:**
   - 디버그 모드는 코드 변경을 감지하기 위해 추가 리소스를 사용합니다.
   - 프로덕션 환경에서는 불필요한 오버헤드가 발생합니다.

3. **자동 재시작:**
   - 코드 변경 시 자동으로 서버가 재시작됩니다.
   - 프로덕션에서는 예상치 못한 다운타임을 유발할 수 있습니다.

#### 프로덕션 환경 설정 방법

**방법 1: app.py 파일 수정**
```python
# app.py 마지막 부분
if __name__ == "__main__":
    # 프로덕션 환경에서는 debug=False로 설정
    app.run(host="0.0.0.0", port=5000, debug=False)  # ✅ 프로덕션 설정
```

**방법 2: 환경 변수 사용 (권장)**
```python
import os

if __name__ == "__main__":
    # 환경 변수에서 디버그 모드 설정 (기본값은 False)
    debug_mode = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(host="0.0.0.0", port=5000, debug=debug_mode)
```

환경 변수 설정:
```bash
# 개발 환경
export FLASK_DEBUG=True
python flask_app/app.py

# 프로덕션 환경
export FLASK_DEBUG=False
python flask_app/app.py
```

**방법 3: WSGI 서버 사용 (프로덕션 권장)**

Flask 개발 서버는 프로덕션용이 아닙니다. 프로덕션에서는 Gunicorn, uWSGI 등의 WSGI 서버를 사용하세요:

```bash
# Gunicorn 설치
pip install gunicorn

# Gunicorn으로 실행
gunicorn -w 4 -b 0.0.0.0:5000 flask_app.app:app
```

#### 배포 체크리스트

- [ ] `debug=False`로 설정
- [ ] 방화벽 포트 5000 열기
- [ ] `host="0.0.0.0"` 설정 확인
- [ ] VM의 외부 IP 주소 확인
- [ ] 보안 그룹/방화벽 규칙 적용 확인
- [ ] (선택) HTTPS 설정 (프로덕션 권장)
- [ ] (선택) WSGI 서버 사용 (Gunicorn 등)

#### 외부 접속 테스트

방화벽 설정 후 외부에서 접속 테스트:

```bash
# 외부 IP로 접속 테스트 (VM의 외부 IP 주소 사용)
curl http://[VM-외부-IP]:5000
curl http://[VM-외부-IP]:5000/api/hello
```

브라우저에서도 접속 가능:
```
http://[VM-외부-IP]:5000
http://[VM-외부-IP]:5000/api/hello
```

## REST API CRUD 연산 테스트 방법

`api.py` 파일은 사용자 관리 REST API를 제공합니다. SQLite 데이터베이스를 사용하여 사용자 정보를 CRUD(생성, 조회, 수정, 삭제)할 수 있습니다.

### API 서버 실행

**Windows (PowerShell 또는 CMD):**
```bash
python flask_app/api.py
```

**macOS/Linux:**
```bash
python3 flask_app/api.py
```

서버는 포트 5001에서 실행됩니다 (기본 app.py는 5000 포트 사용).

### API 엔드포인트

- **POST** `/api/users` - 사용자 생성
- **GET** `/api/users` - 사용자 목록 조회
- **GET** `/api/users/<id>` - 사용자 1명 조회
- **PUT** `/api/users/<id>` - 사용자 수정
- **DELETE** `/api/users/<id>` - 사용자 삭제

### 테스트 예시

#### (1) Create: 사용자 추가 (POST)

**curl (Linux/macOS/Git Bash):**
```bash
curl -X POST http://localhost:5001/api/users \
  -H "Content-Type: application/json" \
  -d '{"name": "김민수", "email": "minsu@example.com", "age": 32}'
```

**PowerShell (Windows):**

> **⚠️ 중요 사항:**
> 1. **Flask 서버 재시작 필수**: `api.py` 파일을 수정했다면 서버를 재시작해야 합니다 (`Ctrl+C`로 종료 후 다시 실행)
> 2. **인코딩 설정 필수**: PowerShell에서 한글을 올바르게 표시하려면 인코딩 설정이 필요합니다
> 3. **서버 설정 확인**: `api.py`에 `JSON_AS_ASCII = False` 설정이 있는지 확인하세요

> **💡 PowerShell JSON 전송 방법:**
> - **방법 1 (권장)**: `ConvertTo-Json` 사용 - PowerShell 객체를 JSON으로 변환하여 안전하고 읽기 쉬움
> - **방법 2**: JSON 문자열 직접 사용 - 간단하지만 큰따옴표 이스케이프 주의 필요
> - 복잡한 JSON이나 변수를 사용할 때는 방법 1을 권장합니다.

```powershell
# ⚠️ 1단계: 인코딩 설정 (한글 표시를 위해 필수)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

# 방법 1: ConvertTo-Json 사용 (권장) - 에러 응답도 올바르게 처리
$body = @{
    name = "김민수"
    email = "minsu@example.com"
    age = 32
} | ConvertTo-Json -Compress

try {
    Invoke-RestMethod -Uri http://localhost:5001/api/users `
        -Method POST `
        -ContentType "application/json; charset=utf-8" `
        -Body $body
} catch {
    # 에러 응답도 UTF-8로 디코딩하여 한글이 올바르게 표시되도록 함
    $errorResponse = $_.Exception.Response
    if ($errorResponse) {
        $stream = $errorResponse.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
        $responseBody = $reader.ReadToEnd()
        $reader.Close()
        $stream.Close()
        $responseBody | ConvertFrom-Json
    } else {
        Write-Error $_.Exception.Message
    }
}

# 방법 2: JSON 문자열 직접 사용 (간단한 경우)
try {
    Invoke-RestMethod -Uri http://localhost:5001/api/users `
        -Method POST `
        -ContentType "application/json; charset=utf-8" `
        -Body '{"name": "김민수", "email": "minsu@example.com", "age": 32}'
} catch {
    # 에러 응답 처리
    $errorResponse = $_.Exception.Response
    if ($errorResponse) {
        $stream = $errorResponse.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
        $responseBody = $reader.ReadToEnd()
        $reader.Close()
        $stream.Close()
        $responseBody | ConvertFrom-Json
    }
}
```

**예상 응답:**
```json
{
  "status": "success",
  "id": 1
}
```

#### (2) Read: 사용자 목록 조회 (GET)

**curl (Linux/macOS/Git Bash):**
```bash
curl http://localhost:5001/api/users
```

**PowerShell (Windows):**
```powershell
# 인코딩 설정 후 실행 (한글 표시를 위해 필수)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Invoke-RestMethod -Uri http://localhost:5001/api/users -Method GET
```

**예상 응답:**
```json
[
  {
    "id": 1,
    "name": "김민수",
    "email": "minsu@example.com",
    "age": 32,
    "reg_date": "2024-01-15"
  }
]
```

#### (3) Read: 사용자 1명 조회 (GET)

**curl (Linux/macOS/Git Bash):**
```bash
curl http://localhost:5001/api/users/1
```

**PowerShell (Windows):**
```powershell
# 인코딩 설정 후 실행 (한글 표시를 위해 필수)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Invoke-RestMethod -Uri http://localhost:5001/api/users/1 -Method GET
```

**예상 응답:**
```json
{
  "id": 1,
  "name": "김민수",
  "email": "minsu@example.com",
  "age": 32,
  "reg_date": "2024-01-15"
}
```

#### (4) Update: 사용자 수정 (PUT)

**curl (Linux/macOS/Git Bash):**
```bash
curl -X PUT http://localhost:5001/api/users/1 \
  -H "Content-Type: application/json" \
  -d '{"name": "김민수", "email": "minsu2@example.com", "age": 33}'
```

**PowerShell (Windows):**
```powershell
# 인코딩 설정 후 실행 (한글 표시를 위해 필수)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 방법 1: ConvertTo-Json 사용 (권장)
$body = @{
    name = "김민수"
    email = "minsu2@example.com"
    age = 33
} | ConvertTo-Json

Invoke-RestMethod -Uri http://localhost:5001/api/users/1 `
  -Method PUT `
  -ContentType "application/json" `
  -Body $body

# 방법 2: JSON 문자열 직접 사용 (간단한 경우)
Invoke-RestMethod -Uri http://localhost:5001/api/users/1 `
  -Method PUT `
  -ContentType "application/json" `
  -Body '{"name": "김민수", "email": "minsu2@example.com", "age": 33}'
```

**예상 응답:**
```json
{
  "id": 1,
  "name": "김민수",
  "email": "minsu2@example.com",
  "age": 33,
  "reg_date": "2024-01-15"
}
```

#### (5) Delete: 사용자 삭제 (DELETE)

**curl (Linux/macOS/Git Bash):**
```bash
curl -X DELETE http://localhost:5001/api/users/1
```

**PowerShell (Windows):**
```powershell
# 인코딩 설정 후 실행 (한글 표시를 위해 필수)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Invoke-RestMethod -Uri http://localhost:5001/api/users/1 -Method DELETE
```

**예상 응답:**
```json
{
  "status": "deleted"
}
```

### 에러 응답 예시

**존재하지 않는 사용자 조회 시 (404):**
```json
{
  "status": "error",
  "message": "ID 999에 해당하는 사용자를 찾을 수 없습니다."
}
```

**필수 필드 누락 시 (400):**
```json
{
  "status": "error",
  "message": "name은 필수 입력 항목입니다."
}
```

**중복된 email 입력 시 (400):**
```json
{
  "status": "error",
  "message": "이미 존재하는 email입니다."
}
```

### 데이터베이스 파일

- **파일명:** `app.db` (프로젝트 루트에 생성됨)
- **테이블:** `users`
- 서버 실행 시 자동으로 테이블이 생성됩니다.

### PowerShell에서 한글 인코딩 문제 해결 방법

PowerShell에서 `Invoke-RestMethod`를 사용할 때 한글이 `???`로 표시되는 경우, 다음 방법으로 해결할 수 있습니다:

#### 방법 1: PowerShell 인코딩 설정 (권장)

PowerShell 세션 시작 시 UTF-8 인코딩을 설정:
```powershell
# PowerShell 인코딩을 UTF-8로 설정
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

# 그 다음 API 호출
Invoke-RestMethod -Uri http://localhost:5001/api/users -Method GET
```

#### 방법 2: 응답을 UTF-8로 디코딩 (에러 응답 포함)

에러 응답도 포함하여 모든 응답을 올바르게 처리:
```powershell
# 에러 응답도 올바르게 처리하는 방법
try {
    $response = Invoke-WebRequest -Uri http://localhost:5001/api/users -Method POST `
        -ContentType "application/json" `
        -Body '{"name": "김민수", "email": "minsu@example.com", "age": 32}'
    [System.Text.Encoding]::UTF8.GetString($response.Content) | ConvertFrom-Json
} catch {
    # 에러 응답도 UTF-8로 디코딩
    $errorResponse = $_.Exception.Response
    $stream = $errorResponse.GetResponseStream()
    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
    $responseBody = $reader.ReadToEnd()
    $responseBody | ConvertFrom-Json
}
```

#### 방법 3: PowerShell 함수로 래핑 (가장 편리)

PowerShell 프로필에 다음 함수를 추가하면 매번 인코딩 설정을 할 필요가 없습니다:
```powershell
function Invoke-UTF8RestMethod {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Uri,
        [string]$Method = "GET",
        [string]$ContentType,
        [string]$Body
    )
    
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    
    $params = @{
        Uri = $Uri
        Method = $Method
    }
    
    if ($ContentType) {
        $params['ContentType'] = $ContentType
    }
    
    if ($Body) {
        $params['Body'] = $Body
    }
    
    try {
        Invoke-RestMethod @params
    } catch {
        Write-Error "요청 실패: $_"
        throw
    }
}

# 사용 예시
Invoke-UTF8RestMethod -Uri http://localhost:5001/api/users -Method GET
```

#### 방법 4: Flask 설정 확인

`api.py` 파일에 다음 설정이 포함되어 있는지 확인:
```python
app.config['JSON_AS_ASCII'] = False  # 한글 등 비ASCII 문자를 그대로 유지
```

이 설정이 있으면 Flask가 한글을 유니코드 이스케이프 시퀀스로 변환하지 않고 그대로 반환합니다.

#### ⚠️ 한글이 여전히 `\uc774\ubbf8...`로 표시되는 경우 - 완전한 해결 방법

**문제 원인:**
- Flask 서버가 재시작되지 않아 변경사항이 적용되지 않음
- PowerShell이 에러 응답을 올바르게 디코딩하지 못함

**✅ 확실한 해결 방법 (에러 응답 포함):**

**1단계: Flask 서버 재시작 (필수!)**
```powershell
# 서버가 실행 중인 터미널에서 Ctrl + C로 종료
# 그 다음 다시 시작:
python flask_app/api.py
```

**2단계: 에러 응답도 올바르게 처리하는 PowerShell 스크립트 사용**

다음 스크립트를 복사해서 사용하세요:

```powershell
# 인코딩 설정
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'

# 에러 응답도 올바르게 처리하는 함수
function Invoke-UTF8RestMethod {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Uri,
        [string]$Method = "GET",
        [string]$ContentType,
        [string]$Body
    )
    
    try {
        $params = @{
            Uri = $Uri
            Method = $Method
        }
        
        if ($ContentType) {
            $params['ContentType'] = $ContentType
        }
        
        if ($Body) {
            $params['Body'] = $Body
        }
        
        # 정상 응답
        Invoke-RestMethod @params
    } catch {
        # 에러 응답 처리
        $errorResponse = $_.Exception.Response
        if ($errorResponse) {
            $stream = $errorResponse.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
            $responseBody = $reader.ReadToEnd()
            $reader.Close()
            $stream.Close()
            
            # JSON 파싱
            $jsonResponse = $responseBody | ConvertFrom-Json
            Write-Host "에러 응답:" -ForegroundColor Red
            $jsonResponse | Format-List
            return $jsonResponse
        } else {
            Write-Error $_.Exception.Message
            throw
        }
    }
}

# 사용 예시 - 이제 에러 메시지도 한글로 표시됩니다!
$body = @{
    name = "김민수"
    email = "minsu@example.com"
    age = 32
} | ConvertTo-Json -Compress

Invoke-UTF8RestMethod -Uri http://localhost:5001/api/users `
    -Method POST `
    -ContentType "application/json; charset=utf-8" `
    -Body $body
```

**3단계: 간단한 테스트 (에러 응답 확인)**
```powershell
# 인코딩 설정
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 에러 응답 테스트 (중복된 email로 에러 발생)
try {
    $response = Invoke-WebRequest -Uri http://localhost:5001/api/users `
        -Method POST `
        -ContentType "application/json; charset=utf-8" `
        -Body '{"name": "김민수", "email": "minsu@example.com", "age": 32}'
    [System.Text.Encoding]::UTF8.GetString($response.Content) | ConvertFrom-Json
} catch {
    # 에러 응답을 UTF-8로 디코딩
    $errorResponse = $_.Exception.Response
    $stream = $errorResponse.GetResponseStream()
    $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
    $responseBody = $reader.ReadToEnd()
    $reader.Close()
    $stream.Close()
    
    # 한글이 올바르게 표시됩니다
    $responseBody | ConvertFrom-Json
}
```

### 전체 테스트 시나리오 예시

**PowerShell에서 순차적으로 실행:**
```powershell
# 먼저 인코딩 설정 (한글 표시를 위해 필수)
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 1. 사용자 생성
$createBody = @{
    name = "김민수"
    email = "minsu@example.com"
    age = 32
} | ConvertTo-Json

$user1 = Invoke-RestMethod -Uri http://localhost:5001/api/users `
    -Method POST `
    -ContentType "application/json" `
    -Body $createBody
Write-Host "생성된 사용자 ID: $($user1.id)"

# 2. 사용자 목록 조회
$users = Invoke-RestMethod -Uri http://localhost:5001/api/users -Method GET
Write-Host "전체 사용자 수: $($users.Count)"

# 3. 특정 사용자 조회
$user = Invoke-RestMethod -Uri "http://localhost:5001/api/users/$($user1.id)" -Method GET
Write-Host "사용자 이름: $($user.name)"

# 4. 사용자 수정
$updateBody = @{
    name = "김민수"
    email = "minsu2@example.com"
    age = 33
} | ConvertTo-Json

$updated = Invoke-RestMethod -Uri "http://localhost:5001/api/users/$($user1.id)" `
    -Method PUT `
    -ContentType "application/json" `
    -Body $updateBody
Write-Host "수정된 나이: $($updated.age)"

# 5. 사용자 삭제
$deleted = Invoke-RestMethod -Uri "http://localhost:5001/api/users/$($user1.id)" -Method DELETE
Write-Host "삭제 상태: $($deleted.status)"
```

## 서버 종료 방법

서버를 종료하려면 서버가 실행 중인 터미널에서:
- **Windows/Linux/macOS:** `Ctrl + C`를 누릅니다.
