# Flask 웹 프레임워크를 import 합니다
from flask import Flask, render_template, jsonify, request
import sqlite3
import os
from datetime import datetime

# Flask 애플리케이션 인스턴스를 생성합니다
# __name__은 현재 모듈의 이름을 의미하며, Flask가 템플릿과 정적 파일을 찾는 데 사용됩니다
app = Flask(__name__)

# 데이터베이스 파일 경로
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app.db")


def init_db():
    """데이터베이스 초기화 함수 - users 테이블이 없으면 생성"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            age INTEGER,
            reg_date TEXT DEFAULT (datetime('now', 'localtime'))
        )
    """)
    conn.commit()
    conn.close()


def get_db_connection():
    """데이터베이스 연결을 반환하는 헬퍼 함수"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # 딕셔너리 형태로 결과 반환
    return conn


# "/" 경로에 대한 라우트를 정의합니다
# 이 경로로 GET 요청이 오면 아래 함수가 실행됩니다
@app.route("/")
def index():
    """
    메인 페이지를 렌더링하는 함수입니다.
    templates/index.html 파일을 찾아서 HTML을 반환합니다.
    """
    # render_template 함수는 templates 폴더에서 지정한 HTML 파일을 찾아 렌더링합니다
    return render_template("index.html")


# "/api/hello" 경로에 대한 라우트를 정의합니다
# methods=['GET']을 명시하여 GET 요청만 처리하도록 설정합니다 (기본값이 GET이지만 명시적으로 표시)
@app.route("/api/hello", methods=["GET"])
def hello_api():
    """
    API 엔드포인트 함수입니다.
    JSON 형식의 응답을 반환합니다.
    """
    # jsonify 함수를 사용하여 Python 딕셔너리를 JSON 형식으로 변환하여 반환합니다
    return jsonify({"message": "Hello Flask API"})


# ========== REST API CRUD 엔드포인트 ==========

# (1) Create: 사용자 추가
@app.route("/api/users", methods=["POST"])
def create_user():
    """새 사용자를 생성합니다"""
    try:
        data = request.get_json()
        
        # 입력값 검증
        if not data:
            return jsonify({"status": "error", "message": "요청 데이터가 없습니다"}), 400
        
        name = data.get("name")
        email = data.get("email")
        age = data.get("age")
        
        if not name or not email:
            return jsonify({"status": "error", "message": "name과 email은 필수입니다"}), 400
        
        if age is not None:
            try:
                age = int(age)
            except (ValueError, TypeError):
                return jsonify({"status": "error", "message": "age는 정수여야 합니다"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                "INSERT INTO users (name, email, age) VALUES (?, ?, ?)",
                (name, email, age)
            )
            conn.commit()
            user_id = cursor.lastrowid
            conn.close()
            return jsonify({"status": "success", "id": user_id}), 201
        except sqlite3.IntegrityError:
            conn.close()
            return jsonify({"status": "error", "message": "이미 존재하는 email입니다"}), 400
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# (2) Read: 사용자 목록 조회
@app.route("/api/users", methods=["GET"])
def get_users():
    """모든 사용자 목록을 반환합니다"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users ORDER BY id")
        rows = cursor.fetchall()
        conn.close()
        
        users = []
        for row in rows:
            # reg_date를 "YYYY-MM-DD" 형태로 포맷
            reg_date = row["reg_date"]
            if reg_date:
                try:
                    # "YYYY-MM-DD HH:MM:SS" 형태를 "YYYY-MM-DD"로 변환
                    reg_date = reg_date.split()[0]
                except:
                    pass
            
            users.append({
                "id": row["id"],
                "name": row["name"],
                "email": row["email"],
                "age": row["age"],
                "reg_date": reg_date
            })
        
        return jsonify(users), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# (3) Read: 사용자 1명 조회
@app.route("/api/users/<int:user_id>", methods=["GET"])
def get_user(user_id):
    """특정 사용자 정보를 반환합니다"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return jsonify({"status": "error", "message": "사용자를 찾을 수 없습니다"}), 404
        
        # reg_date를 "YYYY-MM-DD" 형태로 포맷
        reg_date = row["reg_date"]
        if reg_date:
            try:
                reg_date = reg_date.split()[0]
            except:
                pass
        
        user = {
            "id": row["id"],
            "name": row["name"],
            "email": row["email"],
            "age": row["age"],
            "reg_date": reg_date
        }
        
        return jsonify(user), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# (4) Update: 사용자 수정
@app.route("/api/users/<int:user_id>", methods=["PUT"])
def update_user(user_id):
    """사용자 정보를 수정합니다"""
    try:
        data = request.get_json()
        
        # 입력값 검증
        if not data:
            return jsonify({"status": "error", "message": "요청 데이터가 없습니다"}), 400
        
        name = data.get("name")
        email = data.get("email")
        age = data.get("age")
        
        if not name or not email:
            return jsonify({"status": "error", "message": "name과 email은 필수입니다"}), 400
        
        if age is not None:
            try:
                age = int(age)
            except (ValueError, TypeError):
                return jsonify({"status": "error", "message": "age는 정수여야 합니다"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # 사용자 존재 여부 확인
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({"status": "error", "message": "사용자를 찾을 수 없습니다"}), 404
        
        try:
            cursor.execute(
                "UPDATE users SET name = ?, email = ?, age = ? WHERE id = ?",
                (name, email, age, user_id)
            )
            conn.commit()
            
            # 업데이트된 사용자 정보 조회
            cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            row = cursor.fetchone()
            conn.close()
            
            # reg_date를 "YYYY-MM-DD" 형태로 포맷
            reg_date = row["reg_date"]
            if reg_date:
                try:
                    reg_date = reg_date.split()[0]
                except:
                    pass
            
            user = {
                "id": row["id"],
                "name": row["name"],
                "email": row["email"],
                "age": row["age"],
                "reg_date": reg_date
            }
            
            return jsonify(user), 200
        except sqlite3.IntegrityError:
            conn.close()
            return jsonify({"status": "error", "message": "이미 존재하는 email입니다"}), 400
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# (5) Delete: 사용자 삭제
@app.route("/api/users/<int:user_id>", methods=["DELETE"])
def delete_user(user_id):
    """사용자를 삭제합니다"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # 사용자 존재 여부 확인
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({"status": "error", "message": "사용자를 찾을 수 없습니다"}), 404
        
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
        
        return jsonify({"status": "deleted"}), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# ========== 웹페이지 라우트 ==========

# "/users" 경로에 대한 라우트를 정의합니다
@app.route("/users")
def users_page():
    """CRUD 테스트 페이지를 렌더링합니다"""
    return render_template("users.html")


# 이 파일이 직접 실행될 때만 아래 코드가 실행됩니다
# (다른 파일에서 import 되었을 때는 실행되지 않습니다)
if __name__ == "__main__":
    # 데이터베이스 초기화
    init_db()
    
    # Flask 개발 서버를 실행합니다
    # host='0.0.0.0': 모든 네트워크 인터페이스에서 접속을 허용합니다 (로컬호스트뿐만 아니라 외부에서도 접속 가능)
    # port=5000: 서버가 5000번 포트에서 실행됩니다
    # debug=True: 디버그 모드를 활성화합니다 (코드 변경 시 자동으로 서버가 재시작되고, 에러 발생 시 상세한 에러 페이지가 표시됩니다)
    app.run(host="0.0.0.0", port=5000, debug=True)
