// API 기본 URL
const API_BASE = '/api/users';

// 알림 표시 함수
function showAlert(message, type = 'success') {
    const alertArea = document.getElementById('alert-area');
    alertArea.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
        alertArea.innerHTML = '';
    }, 5000);
}

// 사용자 목록 불러오기
async function loadUsers() {
    try {
        const response = await fetch(API_BASE);
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || '목록을 불러오는데 실패했습니다');
        }
        const users = await response.json();
        renderUsersTable(users);
    } catch (error) {
        showAlert(`오류: ${error.message}`, 'error');
    }
}

// 사용자 테이블 렌더링
function renderUsersTable(users) {
    const tbody = document.getElementById('users-tbody');
    tbody.innerHTML = '';
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">등록된 사용자가 없습니다</td></tr>';
        return;
    }
    
    users.forEach(user => {
        const tr = document.createElement('tr');
        tr.setAttribute('data-id', user.id);
        
        // 편집 모드 여부 확인
        const isEditing = tr.classList.contains('editing');
        
        if (isEditing) {
            // 편집 모드
            tr.innerHTML = `
                <td>${user.id}</td>
                <td><input type="text" class="edit-input" data-field="name" value="${user.name || ''}" required></td>
                <td><input type="email" class="edit-input" data-field="email" value="${user.email || ''}" required></td>
                <td><input type="number" class="edit-input" data-field="age" value="${user.age || ''}"></td>
                <td>${user.reg_date || ''}</td>
                <td>
                    <button class="btn-save" onclick="saveUser(${user.id}, this)">저장</button>
                    <button class="btn-cancel" onclick="cancelEdit(${user.id})">취소</button>
                </td>
            `;
        } else {
            // 일반 모드
            tr.innerHTML = `
                <td>${user.id}</td>
                <td>${user.name || ''}</td>
                <td>${user.email || ''}</td>
                <td>${user.age || ''}</td>
                <td>${user.reg_date || ''}</td>
                <td>
                    <button class="btn-edit" onclick="editUser(${user.id})">수정</button>
                    <button class="btn-delete" onclick="deleteUser(${user.id})">삭제</button>
                </td>
            `;
        }
        
        tbody.appendChild(tr);
    });
}

// 사용자 추가
document.getElementById('add-user-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('add-name').value.trim(),
        email: document.getElementById('add-email').value.trim(),
        age: document.getElementById('add-age').value ? parseInt(document.getElementById('add-age').value) : null
    };
    
    try {
        const response = await fetch(API_BASE, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || '추가에 실패했습니다');
        }
        
        showAlert(`사용자가 추가되었습니다 (ID: ${result.id})`, 'success');
        document.getElementById('add-user-form').reset();
        loadUsers();
    } catch (error) {
        showAlert(`오류: ${error.message}`, 'error');
    }
});

// 단일 사용자 조회
document.getElementById('get-user-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const userId = document.getElementById('get-user-id').value;
    const resultDiv = document.getElementById('single-user-result');
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`);
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || '조회에 실패했습니다');
        }
        
        resultDiv.innerHTML = `<pre>${JSON.stringify(result, null, 2)}</pre>`;
        showAlert('조회가 완료되었습니다', 'success');
    } catch (error) {
        resultDiv.innerHTML = '';
        showAlert(`오류: ${error.message}`, 'error');
    }
});

// 사용자 수정 (편집 모드로 전환)
function editUser(userId) {
    const tr = document.querySelector(`tr[data-id="${userId}"]`);
    if (!tr) return;
    
    const cells = tr.querySelectorAll('td');
    const name = cells[1].textContent.trim();
    const email = cells[2].textContent.trim();
    const age = cells[3].textContent.trim();
    
    tr.classList.add('editing');
    cells[1].innerHTML = `<input type="text" class="edit-input" data-field="name" value="${name}" required>`;
    cells[2].innerHTML = `<input type="email" class="edit-input" data-field="email" value="${email}" required>`;
    cells[3].innerHTML = `<input type="number" class="edit-input" data-field="age" value="${age}">`;
    cells[5].innerHTML = `
        <button class="btn-save" onclick="saveUser(${userId}, this)">저장</button>
        <button class="btn-cancel" onclick="cancelEdit(${userId})">취소</button>
    `;
}

// 수정 취소
function cancelEdit(userId) {
    loadUsers(); // 목록 다시 불러오기
}

// 사용자 저장 (수정 완료)
async function saveUser(userId, button) {
    const tr = document.querySelector(`tr[data-id="${userId}"]`);
    if (!tr) return;
    
    const inputs = tr.querySelectorAll('.edit-input');
    const formData = {};
    
    inputs.forEach(input => {
        const field = input.getAttribute('data-field');
        const value = input.value.trim();
        
        if (field === 'age') {
            formData[field] = value ? parseInt(value) : null;
        } else {
            formData[field] = value;
        }
    });
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || '수정에 실패했습니다');
        }
        
        showAlert('사용자 정보가 수정되었습니다', 'success');
        loadUsers();
    } catch (error) {
        showAlert(`오류: ${error.message}`, 'error');
    }
}

// 사용자 삭제
async function deleteUser(userId) {
    if (!confirm(`정말로 사용자 ID ${userId}를 삭제하시겠습니까?`)) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/${userId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || '삭제에 실패했습니다');
        }
        
        showAlert('사용자가 삭제되었습니다', 'success');
        loadUsers();
    } catch (error) {
        showAlert(`오류: ${error.message}`, 'error');
    }
}

// 페이지 로드 시 사용자 목록 불러오기
document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
});
