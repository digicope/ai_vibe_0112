"""
OpenAI Vision API 응답 파싱 유틸리티
분석 결과에서 감정과 설명을 추출
"""

import re
from typing import Dict, Optional, Tuple, Any


def parse_emotion_from_text(text: str) -> Optional[str]:
    """
    텍스트에서 감정 키워드를 추출
    
    Args:
        text: 분석 결과 텍스트
        
    Returns:
        str: 감정 키워드 (행복, 슬픔, 분노, 놀람, 중립, 긴장/불안), None if not found
    """
    if not text:
        return None
    
    # 감정 키워드 정의
    emotion_keywords = {
        '행복': ['행복', '기쁨', '즐거움', '웃음', '미소', '기쁘', '행복하'],
        '슬픔': ['슬픔', '슬프', '우울', '비애', '눈물', '슬퍼'],
        '분노': ['분노', '화', '짜증', '성난', '분노하', '화나'],
        '놀람': ['놀람', '놀라', '당황', '깜짝', '놀랍'],
        '중립': ['중립', '평온', '무표정', '차분', '평범', '일반'],
        '긴장/불안': ['긴장', '불안', '걱정', '불안하', '긴장되', '초조', '걱정되']
    }
    
    text_lower = text.lower()
    
    # 각 감정별로 점수 계산
    emotion_scores = {}
    for emotion, keywords in emotion_keywords.items():
        score = sum(1 for keyword in keywords if keyword in text_lower)
        if score > 0:
            emotion_scores[emotion] = score
    
    # 가장 높은 점수의 감정 반환
    if emotion_scores:
        return max(emotion_scores.items(), key=lambda x: x[1])[0]
    
    return None


def extract_emotion_and_summary(text: str) -> Tuple[Optional[str], Optional[str]]:
    """
    분석 결과 텍스트에서 감정과 요약 설명을 추출
    
    Args:
        text: OpenAI API 응답 텍스트
        
    Returns:
        Tuple[감정, 설명]: (감정 키워드, 간단한 설명 문장)
    """
    if not text:
        return None, None
    
    # "주요 감정" 섹션에서 감정 추출
    emotion_patterns = [
        r'\*\*주요 감정\*\*[:\s]*([^\n]+)',
        r'주요 감정[:\s]*([^\n]+)',
        r'감정[:\s]*([^\n]+)',
    ]
    
    extracted_emotion = None
    for pattern in emotion_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            emotion_text = match.group(1).strip()
            # 괄호나 특수문자 제거
            emotion_text = re.sub(r'[\[\]()]', '', emotion_text)
            # 감정 키워드 추출
            extracted_emotion = parse_emotion_from_text(emotion_text)
            if extracted_emotion:
                break
    
    # 감정을 찾지 못한 경우 전체 텍스트에서 추출 시도
    if not extracted_emotion:
        extracted_emotion = parse_emotion_from_text(text)
    
    # "추론 근거 요약" 섹션에서 설명 추출
    summary_patterns = [
        r'\*\*추론 근거 요약\*\*[:\s]*([^\n]+(?:\n[^\n]+){0,2})',
        r'추론 근거 요약[:\s]*([^\n]+(?:\n[^\n]+){0,2})',
        r'요약[:\s]*([^\n]+(?:\n[^\n]+){0,2})',
    ]
    
    extracted_summary = None
    for pattern in summary_patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
        if match:
            extracted_summary = match.group(1).strip()
            # 마크다운 형식 제거
            extracted_summary = re.sub(r'\*\*', '', extracted_summary)
            if len(extracted_summary) > 10:  # 최소 길이 확인
                break
    
    # 요약을 찾지 못한 경우 첫 번째 문단 사용
    if not extracted_summary:
        # 첫 번째 의미있는 문장 추출
        sentences = re.split(r'[.\n]', text)
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 20 and not sentence.startswith('#'):
                extracted_summary = sentence
                break
    
    return extracted_emotion, extracted_summary


def check_face_detection_error(text: str) -> bool:
    """
    얼굴 인식 불가 오류인지 확인
    
    Args:
        text: 분석 결과 텍스트
        
    Returns:
        bool: 얼굴 인식 불가 여부
    """
    if not text:
        return True
    
    error_keywords = [
        '얼굴', '인식', '불가', '찾을 수 없', '없음', '없다',
        '사람', '인물', '없', 'cannot', 'not found', 'no face',
        'detect', 'recognize', 'see', 'visible'
    ]
    
    text_lower = text.lower()
    
    # OpenAI의 거부 응답 패턴 감지
    refusal_patterns = [
        r"can't help",
        r"cannot help",
        r"i'm sorry",
        r"i can't",
        r"unable to",
        r"not.*able.*to.*analyze",
        r"not.*able.*to.*identify",
        r"analyzing.*people",
        r"identifying.*people",
        r"privacy.*concern",
    ]
    
    for pattern in refusal_patterns:
        if re.search(pattern, text_lower):
            return True
    
    # 부정 키워드와 함께 얼굴 관련 키워드가 있으면 오류로 판단
    negative_patterns = [
        r'얼굴.*(?:없|못|안|불가)',
        r'(?:없|못|안).*얼굴',
        r'사람.*(?:없|못|안)',
        r'(?:없|못|안).*사람',
        r'cannot.*(?:see|detect|find|recognize)',
        r'no.*(?:face|person)',
    ]
    
    for pattern in negative_patterns:
        if re.search(pattern, text_lower):
            return True
    
    return False


def parse_analysis_response(result: Dict) -> Dict[str, Any]:
    """
    OpenAI API 응답을 파싱하여 구조화된 결과 반환
    
    Args:
        result: OpenAI API 응답 딕셔너리
        
    Returns:
        Dict: 파싱된 결과
        {
            "success": bool,
            "emotion": str,
            "summary": str,
            "full_analysis": str,
            "error_type": str (optional),
            "error_message": str (optional)
        }
    """
    # API 호출 실패
    if not result.get("success", False):
        return {
            "success": False,
            "error_type": "api_error",
            "error_message": result.get("error", "알 수 없는 오류가 발생했습니다."),
            "emotion": None,
            "summary": None,
            "full_analysis": None
        }
    
    analysis_text = result.get("analysis", "")
    
    if not analysis_text:
        return {
            "success": False,
            "error_type": "empty_response",
            "error_message": "분석 결과가 비어있습니다.",
            "emotion": None,
            "summary": None,
            "full_analysis": None
        }
    
    # OpenAI 거부 응답 확인
    if "can't help" in analysis_text.lower() or "cannot help" in analysis_text.lower() or "i'm sorry" in analysis_text.lower():
        return {
            "success": False,
            "error_type": "api_refusal",
            "error_message": "OpenAI가 이 요청을 처리할 수 없습니다. 프롬프트를 수정하여 다시 시도해주세요.",
            "emotion": None,
            "summary": None,
            "full_analysis": analysis_text
        }
    
    # 얼굴 인식 불가 확인
    if check_face_detection_error(analysis_text):
        return {
            "success": False,
            "error_type": "face_not_detected",
            "error_message": "이미지에서 얼굴을 인식할 수 없습니다. 얼굴이 명확하게 보이는 이미지를 사용해주세요.",
            "emotion": None,
            "summary": None,
            "full_analysis": analysis_text
        }
    
    # 감정과 설명 추출
    emotion, summary = extract_emotion_and_summary(analysis_text)
    
    # 감정을 찾지 못한 경우
    if not emotion:
        return {
            "success": False,
            "error_type": "emotion_not_detected",
            "error_message": "감정을 판단할 수 없습니다. 더 명확한 얼굴 표정이 필요합니다.",
            "emotion": None,
            "summary": summary or "감정 분석에 실패했습니다.",
            "full_analysis": analysis_text
        }
    
    # 성공적인 파싱
    return {
        "success": True,
        "emotion": emotion,
        "summary": summary or "표정 분석이 완료되었습니다.",
        "full_analysis": analysis_text,
        "usage": result.get("usage"),
        "model": result.get("model")
    }


# 감정별 이모지 매핑
EMOTION_EMOJI = {
    '행복': '😊',
    '슬픔': '😢',
    '분노': '😠',
    '놀람': '😲',
    '중립': '😐',
    '긴장/불안': '😰'
}


def get_emotion_emoji(emotion: Optional[str]) -> str:
    """
    감정에 해당하는 이모지 반환
    
    Args:
        emotion: 감정 키워드
        
    Returns:
        str: 이모지
    """
    if not emotion:
        return '❓'
    return EMOTION_EMOJI.get(emotion, '😐')
