"""
이미지 처리 유틸리티 모듈
웹캠 이미지 캡처 및 전처리 기능
"""

import io
import base64
from typing import Optional, Tuple, Union
from PIL import Image
import numpy as np


def streamlit_image_to_pil(streamlit_image) -> Optional[Image.Image]:
    """
    Streamlit의 camera_input에서 받은 이미지를 PIL Image 객체로 변환
    
    Args:
        streamlit_image: Streamlit의 camera_input 위젯에서 반환된 이미지 객체
        
    Returns:
        PIL.Image.Image: 변환된 PIL Image 객체, None if error
    """
    try:
        if streamlit_image is None:
            return None
        
        # Streamlit의 camera_input은 UploadedFile 객체를 반환
        # 이를 PIL Image로 직접 열 수 있음
        image = Image.open(streamlit_image)
        
        # RGB 모드로 변환 (RGBA나 다른 모드일 경우 대비)
        if image.mode != 'RGB':
            image = image.convert('RGB')
            
        return image
    except Exception as e:
        print(f"이미지 변환 오류: {e}")
        return None


def pil_to_bytes(image: Image.Image, format: str = 'JPEG', quality: int = 85) -> Optional[bytes]:
    """
    PIL Image를 bytes로 변환
    
    Args:
        image: PIL Image 객체
        format: 이미지 포맷 ('JPEG', 'PNG' 등)
        quality: JPEG 품질 (1-100, PNG는 무시됨)
        
    Returns:
        bytes: 이미지 바이트 데이터, None if error
    """
    try:
        if image is None:
            return None
        
        # 메모리 버퍼에 이미지 저장 (임시 파일 없이)
        buffer = io.BytesIO()
        image.save(buffer, format=format, quality=quality)
        buffer.seek(0)  # 버퍼의 시작 위치로 이동
        image_bytes = buffer.getvalue()
        buffer.close()
        
        return image_bytes
    except Exception as e:
        print(f"Bytes 변환 오류: {e}")
        return None


def pil_to_base64(image: Image.Image, format: str = 'JPEG', quality: int = 85) -> Optional[str]:
    """
    PIL Image를 base64 인코딩된 문자열로 변환
    OpenAI API의 Vision 모델에 전송하기 위한 형식
    
    Args:
        image: PIL Image 객체
        format: 이미지 포맷 ('JPEG', 'PNG' 등)
        quality: JPEG 품질 (1-100)
        
    Returns:
        str: base64 인코딩된 이미지 문자열 (data URL 형식), None if error
    """
    try:
        if image is None:
            return None
        
        # PIL Image를 bytes로 변환
        image_bytes = pil_to_bytes(image, format=format, quality=quality)
        
        if image_bytes is None:
            return None
        
        # base64로 인코딩
        base64_string = base64.b64encode(image_bytes).decode('utf-8')
        
        # MIME 타입 결정
        mime_type = f"image/{format.lower()}"
        
        # data URL 형식으로 반환 (OpenAI API에서 사용 가능)
        data_url = f"data:{mime_type};base64,{base64_string}"
        
        return data_url
    except Exception as e:
        print(f"Base64 변환 오류: {e}")
        return None


def resize_image(image: Image.Image, max_size: int = 1024, maintain_aspect: bool = True) -> Image.Image:
    """
    이미지 크기 조정 (OpenAI API 제한에 맞춤)
    
    Args:
        image: PIL Image 객체
        max_size: 최대 크기 (가로 또는 세로)
        maintain_aspect: 종횡비 유지 여부
        
    Returns:
        PIL.Image.Image: 리사이즈된 이미지
    """
    if image is None:
        return None
    
    width, height = image.size
    
    # 이미 최대 크기보다 작으면 그대로 반환
    if max(width, height) <= max_size:
        return image
    
    if maintain_aspect:
        # 종횡비 유지하며 리사이즈
        if width > height:
            new_width = max_size
            new_height = int(height * (max_size / width))
        else:
            new_height = max_size
            new_width = int(width * (max_size / height))
        
        resized_image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
    else:
        # 정사각형으로 리사이즈
        resized_image = image.resize((max_size, max_size), Image.Resampling.LANCZOS)
    
    return resized_image


def process_streamlit_image(
    streamlit_image,
    max_size: int = 1024,
    format: str = 'JPEG',
    quality: int = 85
) -> Tuple[Optional[Image.Image], Optional[bytes], Optional[str]]:
    """
    Streamlit 이미지를 처리하여 PIL, bytes, base64 형태로 모두 반환
    통합 처리 함수
    
    Args:
        streamlit_image: Streamlit의 camera_input에서 받은 이미지
        max_size: 최대 이미지 크기
        format: 이미지 포맷
        quality: 이미지 품질
        
    Returns:
        Tuple[PIL.Image, bytes, str]: (PIL Image, bytes 데이터, base64 문자열)
    """
    # 1. PIL Image로 변환
    pil_image = streamlit_image_to_pil(streamlit_image)
    
    if pil_image is None:
        return None, None, None
    
    # 2. 이미지 리사이즈 (필요한 경우)
    resized_image = resize_image(pil_image, max_size=max_size)
    
    # 3. bytes로 변환
    image_bytes = pil_to_bytes(resized_image, format=format, quality=quality)
    
    # 4. base64로 변환
    base64_string = pil_to_base64(resized_image, format=format, quality=quality)
    
    return resized_image, image_bytes, base64_string


def get_image_info(image: Image.Image) -> dict:
    """
    이미지 정보를 딕셔너리로 반환
    
    Args:
        image: PIL Image 객체
        
    Returns:
        dict: 이미지 정보 (크기, 모드, 포맷 등)
    """
    if image is None:
        return {}
    
    return {
        'width': image.size[0],
        'height': image.size[1],
        'mode': image.mode,
        'format': getattr(image, 'format', None),
    }


# 사용 예시 및 설명
"""
=== 이미지 처리 방식 설명 ===

1. 메모리 기반 처리 (권장)
   - io.BytesIO()를 사용하여 임시 파일 없이 메모리에서 처리
   - 디스크 I/O 없이 빠른 처리
   - 보안상 안전 (임시 파일 생성 없음)
   
2. PIL Image 형태
   - 이미지 조작 및 전처리에 사용
   - 리사이즈, 크롭, 필터 적용 등
   
3. Bytes 형태
   - 바이너리 데이터로 저장/전송
   - 파일로 저장하거나 네트워크 전송에 사용
   
4. Base64 형태
   - OpenAI API의 Vision 모델에 전송하기 위한 형식
   - data URL 형식: "data:image/jpeg;base64,..."
   - JSON에 직접 포함 가능

=== OpenAI API 전송 형식 ===
OpenAI Vision API는 다음 형식을 지원:
- base64 인코딩된 이미지 (data URL 형식)
- 이미지 URL (공개 접근 가능한 URL)

이 모듈은 base64 형식을 사용합니다.
"""
