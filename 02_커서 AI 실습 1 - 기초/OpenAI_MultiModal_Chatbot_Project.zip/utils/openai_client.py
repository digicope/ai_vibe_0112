"""
OpenAI API 클라이언트 모듈
Vision 모델을 사용한 이미지 분석 기능
"""

from typing import Optional, Dict, Any
from openai import OpenAI
from config.settings import OPENAI_API_KEY, OPENAI_MODEL


class OpenAIVisionClient:
    """OpenAI Vision API 클라이언트 클래스"""
    
    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        """
        OpenAI 클라이언트 초기화
        
        Args:
            api_key: OpenAI API 키 (None이면 설정 파일에서 로드)
            model: 사용할 모델명 (None이면 설정 파일에서 로드)
        """
        self.api_key = api_key or OPENAI_API_KEY
        self.model = model or OPENAI_MODEL
        
        if not self.api_key:
            raise ValueError("OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인하세요.")
        
        # 최신 OpenAI Python SDK 초기화
        self.client = OpenAI(api_key=self.api_key)
    
    def analyze_facial_expression(
        self,
        image_base64: str,
        custom_prompt: Optional[str] = None,
        max_completion_tokens: int = 400,
        detail: str = "auto"
    ) -> Dict[str, Any]:
        """
        얼굴 표정을 분석하는 메서드
        
        Args:
            image_base64: base64 인코딩된 이미지 (data URL 형식)
            custom_prompt: 사용자 정의 프롬프트 (None이면 기본 프롬프트 사용)
            max_completion_tokens: 최대 완성 토큰 수 (GPT-5.2는 max_completion_tokens 사용)
            detail: 이미지 상세도 ("low", "high", "auto")
            
        Returns:
            Dict: 분석 결과 및 메타데이터
        """
        # 기본 프롬프트 (얼굴 표정 분석에 초점)
        default_prompt = """이 이미지에서 보이는 표정(facial expression)의 감정적 특성을 분석해주세요. 
이것은 교육 목적의 감정 인식 학습 프로젝트입니다. 표정의 감정적 특성만 분석하며, 개인 식별이나 신원 확인은 하지 않습니다.

다음 형식으로 한국어로 답변해주세요:

## 감정 판단

다음 감정 범주 중 하나 이상을 선택하여 판단해주세요:
- 행복
- 슬픔
- 분노
- 놀람
- 중립
- 긴장/불안

**주요 감정**: [위 범주 중 가장 두드러지는 감정 1-2개 선택]
**감정 강도**: [약함/보통/강함]

## 추론 근거 (간단히 설명)

다음 요소들을 바탕으로 감정을 판단한 근거를 짧게 설명해주세요:

1. **눈과 눈썹**:
   - 눈썹의 위치와 모양
   - 눈의 크기와 모양
   - 시선의 방향

2. **입과 입꼬리**:
   - 입꼬리의 방향 (올라감/내려감/수평)
   - 입의 모양 (웃음/찡그림/일직선 등)
   - 입술의 긴장도

3. **얼굴 근육과 전체적인 긴장도**:
   - 이마의 주름
   - 볼의 긴장도
   - 전체적인 얼굴 근육의 상태

각 감정 범주의 특징:
- **행복**: 입꼬리가 올라가고, 눈이 반쯤 감기며, 볼이 올라감
- **슬픔**: 입꼬리가 내려가고, 눈썹이 내려가며, 눈이 습기 있음
- **분노**: 눈썹이 찡그려지고, 입이 일직선이거나 아래로, 이마에 주름
- **놀람**: 눈과 입이 크게 벌어지고, 눈썹이 올라감
- **중립**: 얼굴 근육이 편안하고, 특별한 감정 표현이 없음
- **긴장/불안**: 눈썹이 약간 올라가고, 입이 약간 긴장되며, 전체적으로 경직됨

**추론 근거 요약**: [위의 관찰사항을 바탕으로 감정을 판단한 핵심 근거를 2-3문장으로 간단히 설명]

분석은 객관적이고 명확하게 작성해주세요. 표정의 감정적 특성에만 집중해주세요."""
        
        prompt = custom_prompt or default_prompt
        
        try:
            # base64 문자열 검증 및 정리
            if not image_base64:
                return {
                    "success": False,
                    "error": "이미지 데이터가 비어있습니다.",
                    "error_type": "EmptyImageError"
                }
            
            # base64 문자열에서 data URL 접두사 제거 (필요한 경우)
            base64_data = image_base64
            if image_base64.startswith("data:image"):
                # data URL 형식에서 base64 부분만 추출
                if "," in image_base64:
                    base64_data = image_base64.split(",", 1)[1]
                else:
                    return {
                        "success": False,
                        "error": "잘못된 이미지 데이터 형식입니다.",
                        "error_type": "InvalidImageFormatError"
                    }
            
            # base64 데이터 검증 (최소 길이 확인)
            if len(base64_data) < 100:
                return {
                    "success": False,
                    "error": "이미지 데이터가 너무 작습니다.",
                    "error_type": "ImageDataTooSmallError"
                }
            
            # OpenAI Vision API 호출
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_data}",
                                    "detail": detail
                                }
                            }
                        ]
                    }
                ],
                max_completion_tokens=max_completion_tokens,
                temperature=0.7  # 창의성과 일관성의 균형
            )
            
            # 응답 검증
            if not response or not response.choices:
                return {
                    "success": False,
                    "error": "OpenAI API에서 빈 응답을 받았습니다.",
                    "error_type": "EmptyResponseError"
                }
            
            # 응답 추출
            analysis_text = response.choices[0].message.content
            
            if not analysis_text:
                return {
                    "success": False,
                    "error": "분석 결과가 비어있습니다.",
                    "error_type": "EmptyAnalysisError"
                }
            
            # 메타데이터 추출
            usage = response.usage
            
            return {
                "success": True,
                "analysis": analysis_text,
                "model": response.model,
                "usage": {
                    "prompt_tokens": usage.prompt_tokens,
                    "completion_tokens": usage.completion_tokens,
                    "total_tokens": usage.total_tokens
                },
                "response_id": response.id
            }
            
        except Exception as e:
            error_msg = str(e)
            error_type = type(e).__name__
            
            # 더 자세한 오류 정보 제공
            if "api_key" in error_msg.lower() or "authentication" in error_msg.lower():
                error_msg = "OpenAI API 키가 유효하지 않습니다. .env 파일을 확인하세요."
            elif "rate limit" in error_msg.lower():
                error_msg = "API 사용량 한도에 도달했습니다. 잠시 후 다시 시도하세요."
            elif "invalid" in error_msg.lower() and "image" in error_msg.lower():
                error_msg = "이미지 형식이 올바르지 않습니다."
            
            return {
                "success": False,
                "error": error_msg,
                "error_type": error_type
            }
    
    def analyze_with_custom_prompt(
        self,
        image_base64: str,
        prompt: str,
        max_completion_tokens: int = 300,
        temperature: float = 0.7,
        detail: str = "auto"
    ) -> Dict[str, Any]:
        """
        사용자 정의 프롬프트로 이미지 분석
        
        Args:
            image_base64: base64 인코딩된 이미지
            prompt: 사용자 정의 프롬프트
            max_completion_tokens: 최대 완성 토큰 수 (GPT-5.2는 max_completion_tokens 사용)
            temperature: 온도 파라미터 (0.0-2.0)
            detail: 이미지 상세도
            
        Returns:
            Dict: 분석 결과
        """
        try:
            # base64 문자열에서 data URL 접두사 제거 (필요한 경우)
            if image_base64.startswith("data:image"):
                image_base64 = image_base64.split(",")[1] if "," in image_base64 else image_base64
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{image_base64}",
                                    "detail": detail
                                }
                            }
                        ]
                    }
                ],
                max_completion_tokens=max_completion_tokens,
                temperature=temperature
            )
            
            analysis_text = response.choices[0].message.content
            usage = response.usage
            
            return {
                "success": True,
                "analysis": analysis_text,
                "model": response.model,
                "usage": {
                    "prompt_tokens": usage.prompt_tokens,
                    "completion_tokens": usage.completion_tokens,
                    "total_tokens": usage.total_tokens
                },
                "response_id": response.id
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "error_type": type(e).__name__
            }


# 편의 함수: 싱글톤 패턴으로 클라이언트 인스턴스 관리
_client_instance: Optional[OpenAIVisionClient] = None


def get_openai_client() -> OpenAIVisionClient:
    """
    OpenAI 클라이언트 인스턴스 반환 (싱글톤 패턴)
    
    Returns:
        OpenAIVisionClient: 클라이언트 인스턴스
    """
    global _client_instance
    if _client_instance is None:
        _client_instance = OpenAIVisionClient()
    return _client_instance


def analyze_facial_expression(
    image_base64: str,
    custom_prompt: Optional[str] = None
) -> Dict[str, Any]:
    """
    얼굴 표정 분석 편의 함수
    
    Args:
        image_base64: base64 인코딩된 이미지
        custom_prompt: 사용자 정의 프롬프트
        
    Returns:
        Dict: 분석 결과
    """
    client = get_openai_client()
    return client.analyze_facial_expression(image_base64, custom_prompt)


# 사용 예시 및 설명
"""
=== OpenAI Vision API 사용 방법 ===

1. 기본 사용법:
   ```python
   from utils.openai_client import analyze_facial_expression
   
   result = analyze_facial_expression(image_base64_string)
   if result["success"]:
       print(result["analysis"])
   ```

2. 클라이언트 직접 사용:
   ```python
   from utils.openai_client import OpenAIVisionClient
   
   client = OpenAIVisionClient()
   result = client.analyze_facial_expression(image_base64_string)
   ```

3. 사용자 정의 프롬프트:
   ```python
   custom_prompt = "이 사람의 표정에서 무엇을 느낄 수 있나요?"
   result = client.analyze_with_custom_prompt(image_base64_string, custom_prompt)
   ```

=== API 요청 형식 ===
OpenAI Vision API는 다음과 같은 형식으로 요청을 보냅니다:

{
    "model": "gpt-4-vision-preview",
    "messages": [
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "프롬프트 텍스트"
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "data:image/jpeg;base64,...",
                        "detail": "auto"
                    }
                }
            ]
        }
    ],
    "max_completion_tokens": 300
}

=== 이미지 형식 ===
- Base64 인코딩된 JPEG 또는 PNG 이미지
- Data URL 형식: "data:image/jpeg;base64,{base64_string}"
- 최대 이미지 크기: 모델에 따라 다름 (일반적으로 20MB 이하)
"""
