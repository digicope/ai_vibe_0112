# OpenAI MultiModal Chatbot Project

## 프로젝트 개요

OpenAI API의 멀티모달 기능을 활용하여 웹캠으로 촬영한 얼굴 이미지를 분석하고, 얼굴 표정(감정 상태)을 텍스트로 설명해주는 멀티모달 챗봇 프로젝트입니다.

## 주요 기능

- 웹캠을 통한 실시간 얼굴 이미지 촬영
- OpenAI Vision 모델을 활용한 얼굴 표정 분석
- 감정 상태를 텍스트로 설명 제공
- Streamlit 기반 웹 UI

## 기술 스택

- **Python**: 메인 프로그래밍 언어
- **Streamlit**: 웹 UI 프레임워크
- **OpenAI API**: Vision 모델 (GPT-4 Vision)
- **OpenCV**: 웹캠 이미지 캡처
- **Pillow**: 이미지 처리

## 프로젝트 구조

```
OpenAI_MultiModal_Chatbot_Project/
├── app.py                 # Streamlit 메인 애플리케이션
├── requirements.txt       # Python 패키지 의존성
├── .env.example          # 환경 변수 예시 파일
├── .gitignore            # Git 무시 파일
├── README.md             # 프로젝트 설명서
├── config/               # 설정 파일
│   └── settings.py       # 애플리케이션 설정
├── utils/                # 유틸리티 모듈
│   ├── __init__.py
│   ├── openai_client.py  # OpenAI API 클라이언트
│   └── image_processor.py # 이미지 처리 유틸리티
├── assets/               # 정적 리소스
│   └── .gitkeep
└── tests/                # 테스트 파일
    ├── __init__.py
    └── test_image_processor.py
```

## 설치 방법

1. 프로젝트 클론 또는 다운로드
2. 가상 환경 생성 및 활성화
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```
3. 의존성 패키지 설치
   ```bash
   pip install -r requirements.txt
   ```
4. 환경 변수 설정
   - `.env.example` 파일을 참고하여 `.env` 파일 생성
   - OpenAI API 키 입력

## 실행 방법

```bash
streamlit run app.py
```

## 환경 변수

`.env` 파일에 다음 변수를 설정해야 합니다:

```
OPENAI_API_KEY=your_openai_api_key_here
```

## 사용 방법

1. 애플리케이션 실행 후 웹 브라우저에서 열림
2. 웹캠 접근 권한 허용
3. "촬영" 버튼을 클릭하여 얼굴 이미지 캡처
4. OpenAI Vision 모델이 이미지를 분석하여 감정 상태 설명 제공

## 라이선스

MIT License
