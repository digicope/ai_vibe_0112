# GPT-4o에서 GPT-5.2로 마이그레이션 가이드

## 개요

OpenAI의 최신 모델인 GPT-5.2는 GPT-4o와 비교하여 API 파라미터와 사용 방법에 일부 변경사항이 있습니다. 이 문서는 두 모델 간의 주요 차이점과 마이그레이션 방법을 설명합니다.

---

## 주요 변경사항

### 1. 모델명 변경

#### GPT-4o
```python
OPENAI_MODEL = "gpt-4o"
```

#### GPT-5.2
```python
OPENAI_MODEL = "gpt-5.2"
```

**사용 가능한 GPT-5.2 라인업:**
- `gpt-5.2` - 기본 모델
- `gpt-5.2-pro` - 고성능 버전
- `gpt-5-mini` - 경량 버전

---

### 2. 토큰 제한 파라미터 변경 ⚠️ **중요**

가장 중요한 변경사항은 토큰 제한 파라미터명입니다.

#### GPT-4o (이전)
```python
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[...],
    max_tokens=400,  # ❌ GPT-5.2에서 사용 불가
    temperature=0.7
)
```

#### GPT-5.2 (현재)
```python
response = client.chat.completions.create(
    model="gpt-5.2",
    messages=[...],
    max_completion_tokens=400,  # ✅ 새로운 파라미터명
    temperature=0.7
)
```

**변경 이유:**
- GPT-5.2는 응답 생성 토큰 수를 더 명확하게 구분하기 위해 `max_completion_tokens`를 사용합니다.
- `max_tokens`는 더 이상 지원되지 않으며, 사용 시 `BadRequestError`가 발생합니다.

---

### 3. 함수 시그니처 변경

#### GPT-4o (이전)
```python
def analyze_facial_expression(
    self,
    image_base64: str,
    custom_prompt: Optional[str] = None,
    max_tokens: int = 400,  # ❌
    detail: str = "auto"
) -> Dict[str, Any]:
    # ...
    response = self.client.chat.completions.create(
        model=self.model,
        messages=[...],
        max_tokens=max_tokens,  # ❌
        temperature=0.7
    )
```

#### GPT-5.2 (현재)
```python
def analyze_facial_expression(
    self,
    image_base64: str,
    custom_prompt: Optional[str] = None,
    max_completion_tokens: int = 400,  # ✅
    detail: str = "auto"
) -> Dict[str, Any]:
    # ...
    response = self.client.chat.completions.create(
        model=self.model,
        messages=[...],
        max_completion_tokens=max_completion_tokens,  # ✅
        temperature=0.7
    )
```

---

## 마이그레이션 체크리스트

### ✅ 필수 변경사항

1. **모델명 변경**
   - [ ] `config/settings.py`에서 `OPENAI_MODEL` 값을 `gpt-5.2`로 변경
   - [ ] `.env` 파일에서 `OPENAI_MODEL=gpt-5.2` 설정

2. **파라미터명 변경**
   - [ ] 모든 `max_tokens` 파라미터를 `max_completion_tokens`로 변경
   - [ ] 함수 시그니처의 파라미터명 변경
   - [ ] API 호출 시 파라미터명 변경

3. **에러 처리 업데이트**
   - [ ] `BadRequestError` 처리 로직 확인
   - [ ] "unsupported_parameter" 에러 메시지 처리

### 🔍 선택적 개선사항

1. **프롬프트 최적화**
   - GPT-5.2의 향상된 성능을 활용한 프롬프트 개선

2. **토큰 제한 조정**
   - GPT-5.2는 더 긴 응답을 생성할 수 있으므로 필요시 `max_completion_tokens` 값 조정

---

## 코드 예제 비교

### 완전한 예제: 얼굴 표정 분석

#### GPT-4o 버전
```python
from openai import OpenAI

client = OpenAI(api_key="your-api-key")

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "이 이미지의 표정을 분석해주세요."
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "data:image/jpeg;base64,...",
                        "detail": "auto"
                    }
                }
            ]
        }
    ],
    max_tokens=400,  # ❌
    temperature=0.7
)

result = response.choices[0].message.content
```

#### GPT-5.2 버전
```python
from openai import OpenAI

client = OpenAI(api_key="your-api-key")

response = client.chat.completions.create(
    model="gpt-5.2",
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "이 이미지의 표정을 분석해주세요."
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "data:image/jpeg;base64,...",
                        "detail": "auto"
                    }
                }
            ]
        }
    ],
    max_completion_tokens=400,  # ✅
    temperature=0.7
)

result = response.choices[0].message.content
```

---

## 에러 처리

### 일반적인 에러

#### 1. Unsupported Parameter Error
```
Error code: 400 - {'error': {
    'message': "Unsupported parameter: 'max_tokens' is not supported with this model. Use 'max_completion_tokens' instead.",
    'type': 'invalid_request_error',
    'param': 'max_tokens',
    'code': 'unsupported_parameter'
}}
```

**해결 방법:**
- `max_tokens`를 `max_completion_tokens`로 변경

#### 2. Model Not Found Error
```
Error code: 404 - {'error': {
    'message': 'The model gpt-5.2 does not exist',
    'type': 'invalid_request_error',
    'code': 'model_not_found'
}}
```

**해결 방법:**
- 모델명 확인: `gpt-5.2`, `gpt-5.2-pro`, `gpt-5-mini`
- API 키에 해당 모델 접근 권한이 있는지 확인

---

## GPT-5.2 모델 특징

### 성능 개선
- **더 정확한 감정 분석**: GPT-4o 대비 향상된 Vision 성능
- **더 긴 컨텍스트**: 40만 토큰 컨텍스트 길이 지원
- **더 긴 응답**: 최대 13만 출력 토큰 지원

### 가격 정보 (참고)
- **GPT-5.2**: 입력 $1.75/1M 토큰, 출력 $14.00/1M 토큰
- **GPT-5.2-pro**: 입력 $21.00/1M 토큰, 출력 $168.00/1M 토큰
- **GPT-5-mini**: 입력 $0.25/1M 토큰, 출력 $2.00/1M 토큰

### 지식 컷오프
- **2025년 8월 31일**: 최신 정보까지 포함

---

## 호환성 고려사항

### 하위 호환성
- ❌ GPT-5.2는 `max_tokens` 파라미터를 지원하지 않음
- ✅ Vision 기능은 동일하게 작동
- ✅ 메시지 구조는 동일

### 모델 선택 전략
```python
# 모델에 따라 파라미터를 동적으로 선택하는 예제
def create_completion(model: str, messages: list, max_tokens: int = 400):
    params = {
        "model": model,
        "messages": messages,
        "temperature": 0.7
    }
    
    # GPT-5.2 계열 모델 체크
    if model.startswith("gpt-5"):
        params["max_completion_tokens"] = max_tokens
    else:
        params["max_tokens"] = max_tokens
    
    return client.chat.completions.create(**params)
```

---

## 테스트 방법

### 1. 모델 확인
```python
from config.settings import OPENAI_MODEL
print(f"현재 모델: {OPENAI_MODEL}")
```

### 2. API 호출 테스트
```python
from utils.openai_client import analyze_facial_expression

# 테스트 이미지로 API 호출
result = analyze_facial_expression(test_image_base64)

if result.get("success"):
    print("✅ GPT-5.2 모델 작동 정상")
    print(result["analysis"])
else:
    print(f"❌ 오류: {result.get('error')}")
```

---

## 참고 자료

- [OpenAI API 문서](https://platform.openai.com/docs)
- [OpenAI 가격 정보](https://platform.openai.com/docs/pricing)
- [GPT-5.2 모델 정보](https://platform.openai.com/docs/models)

---

## 요약

| 항목 | GPT-4o | GPT-5.2 |
|------|--------|---------|
| 모델명 | `gpt-4o` | `gpt-5.2` |
| 토큰 파라미터 | `max_tokens` | `max_completion_tokens` |
| Vision 지원 | ✅ | ✅ |
| 컨텍스트 길이 | 128K | 400K |
| 최대 출력 토큰 | 16K | 130K |
| 지식 컷오프 | 2024년 4월 | 2025년 8월 31일 |

---

**작성일:** 2024년  
**최종 업데이트:** GPT-5.2 출시 후
