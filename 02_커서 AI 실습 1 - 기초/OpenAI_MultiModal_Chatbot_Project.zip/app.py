"""
Streamlit 메인 애플리케이션 파일
웹캠을 통한 얼굴 이미지 촬영 및 OpenAI Vision 모델을 활용한 감정 분석

실행 방법:
    streamlit run app.py
"""

import streamlit as st
from PIL import Image
import sys
import os

# 프로젝트 루트를 Python 경로에 추가
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 유틸리티 모듈 import
from utils.image_processor import (
    process_streamlit_image,
    get_image_info,
    pil_to_bytes,
    pil_to_base64
)
from utils.openai_client import analyze_facial_expression
from utils.response_parser import parse_analysis_response, get_emotion_emoji
from config.settings import (
    MAX_IMAGE_SIZE, 
    IMAGE_QUALITY, 
    IMAGE_FORMAT,
    OPENAI_API_KEY
)

# ============================================================================
# 페이지 설정
# ============================================================================
st.set_page_config(
    page_title="얼굴 표정 분석 챗봇",
    page_icon="😊",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# ============================================================================
# API 키 확인
# ============================================================================
if not OPENAI_API_KEY:
    st.error("⚠️ **OpenAI API 키가 설정되지 않았습니다.**")
    st.info("""
    `.env` 파일을 생성하고 다음 내용을 추가해주세요:
    ```
    OPENAI_API_KEY=your_api_key_here
    ```
    """)
    st.stop()

# ============================================================================
# 메인 UI
# ============================================================================
st.title("😊 얼굴 표정 분석 챗봇")
st.markdown("---")
st.markdown("### 웹캠으로 얼굴 이미지를 촬영하고 감정 상태를 분석해보세요!")

# ============================================================================
# 세션 상태 초기화
# ============================================================================
if 'captured_image' not in st.session_state:
    st.session_state.captured_image = None
if 'image_bytes' not in st.session_state:
    st.session_state.image_bytes = None
if 'image_base64' not in st.session_state:
    st.session_state.image_base64 = None
if 'image_info' not in st.session_state:
    st.session_state.image_info = None
if 'analysis_result' not in st.session_state:
    st.session_state.analysis_result = None
if 'parsed_result' not in st.session_state:
    st.session_state.parsed_result = None
if 'is_analyzing' not in st.session_state:
    st.session_state.is_analyzing = False
if 'image_captured' not in st.session_state:
    st.session_state.image_captured = False

# ============================================================================
# 메인 레이아웃: 웹캠 촬영 영역
# ============================================================================
col1, col2 = st.columns(2)

with col1:
    st.markdown("#### 📷 웹캠 촬영")
    
    # 웹캠 입력 (이미지가 캡처되지 않았을 때만 활성화)
    if not st.session_state.image_captured:
        camera_image = st.camera_input(
            label="웹캠에서 얼굴을 촬영하세요",
            key="camera_input"
        )
        
        # 촬영 버튼 (이미지가 있을 때만 활성화)
        if camera_image is not None:
            col_btn1, col_btn2 = st.columns(2)
            
            with col_btn1:
                if st.button("📸 이미지 캡처", use_container_width=True, type="primary", key="capture_btn"):
                    try:
                        # 이미지 처리: PIL, bytes, base64 형태로 모두 변환
                        pil_img, img_bytes, img_base64 = process_streamlit_image(
                            camera_image,
                            max_size=MAX_IMAGE_SIZE,
                            format=IMAGE_FORMAT,
                            quality=IMAGE_QUALITY
                        )
                        
                        if pil_img is not None:
                            # 세션 상태에 저장
                            st.session_state.captured_image = pil_img
                            st.session_state.image_bytes = img_bytes
                            st.session_state.image_base64 = img_base64
                            st.session_state.image_info = get_image_info(pil_img)
                            st.session_state.image_captured = True
                            # 이전 분석 결과 초기화
                            st.session_state.analysis_result = None
                            st.session_state.parsed_result = None
                            
                            st.success("✅ 이미지가 성공적으로 캡처되었습니다!")
                            # rerun 대신 페이지가 자동으로 새로고침됨
                        else:
                            st.error("❌ 이미지 처리 중 오류가 발생했습니다.")
                    except Exception as e:
                        st.error(f"❌ 이미지 처리 오류: {str(e)}")
            
            with col_btn2:
                if st.button("🔄 초기화", use_container_width=True, key="reset_btn"):
                    # 모든 세션 상태 초기화
                    st.session_state.captured_image = None
                    st.session_state.image_bytes = None
                    st.session_state.image_base64 = None
                    st.session_state.image_info = None
                    st.session_state.analysis_result = None
                    st.session_state.parsed_result = None
                    st.session_state.is_analyzing = False
                    st.session_state.image_captured = False
    else:
        # 이미지가 캡처된 경우 다시 촬영 버튼만 표시
        if st.button("📷 다시 촬영하기", use_container_width=True, key="retake_btn"):
            st.session_state.image_captured = False
            st.session_state.captured_image = None
            st.session_state.image_bytes = None
            st.session_state.image_base64 = None
            st.session_state.image_info = None
            st.session_state.analysis_result = None
            st.session_state.parsed_result = None

# ============================================================================
# 메인 레이아웃: 이미지 미리보기 및 분석 영역
# ============================================================================
with col2:
    st.markdown("#### 🖼️ 촬영된 이미지 미리보기")
    
    # 촬영된 이미지가 있으면 표시
    if st.session_state.captured_image is not None:
        st.image(
            st.session_state.captured_image,
            caption="촬영된 얼굴 이미지"
        )
        
        # 이미지 정보 표시
        if st.session_state.image_info:
            info = st.session_state.image_info
            st.info(f"""
            **📐 이미지 정보:**
            - 크기: {info['width']} x {info['height']} 픽셀
            - 모드: {info['mode']}
            - 포맷: {info.get('format', IMAGE_FORMAT)}
            """)
        
        # 이미지 처리 결과 표시 (확장 가능 영역)
        with st.expander("🔍 이미지 처리 상세 정보", expanded=False):
            if st.session_state.image_bytes:
                bytes_size = len(st.session_state.image_bytes)
                st.write(f"**Bytes 크기:** {bytes_size:,} bytes ({bytes_size / 1024:.2f} KB)")
            
            if st.session_state.image_base64:
                base64_size = len(st.session_state.image_base64)
                st.write(f"**Base64 문자열 길이:** {base64_size:,} characters")
                st.write("**Base64 미리보기:**")
                st.code(st.session_state.image_base64[:100] + "...", language="text")
            
            st.write("**처리 방식:** 메모리 기반 (임시 파일 없음)")
            st.write("**OpenAI API 전송 준비:** ✅ 완료")
        
        # 분석 버튼
        st.markdown("---")
        if st.button("🤖 얼굴 표정 분석하기", use_container_width=True, type="primary"):
            if st.session_state.image_base64:
                try:
                    # base64 데이터 검증
                    if not st.session_state.image_base64 or len(st.session_state.image_base64) < 100:
                        st.error("❌ 이미지 데이터가 유효하지 않습니다. 다시 촬영해주세요.")
                    else:
                        with st.spinner("🔍 OpenAI Vision 모델이 이미지를 분석 중입니다..."):
                            st.session_state.is_analyzing = True
                            
                            # OpenAI Vision API 호출
                            result = analyze_facial_expression(st.session_state.image_base64)
                            st.session_state.analysis_result = result
                            
                            # 결과 확인 및 디버깅
                            if not result.get("success", False):
                                # 오류가 발생한 경우 즉시 표시
                                error_msg = result.get("error", "알 수 없는 오류")
                                error_type = result.get("error_type", "Unknown")
                                st.error(f"❌ API 호출 오류 ({error_type}): {error_msg}")
                                
                                # 디버깅 정보 표시
                                with st.expander("🔍 디버깅 정보", expanded=True):
                                    st.write("**오류 타입:**", error_type)
                                    st.write("**오류 메시지:**", error_msg)
                                    st.write("**이미지 데이터 길이:**", len(st.session_state.image_base64) if st.session_state.image_base64 else 0)
                                    if st.session_state.image_base64:
                                        st.write("**이미지 데이터 형식:**", "data URL" if st.session_state.image_base64.startswith("data:") else "base64")
                                
                                st.session_state.parsed_result = parse_analysis_response(result)
                            else:
                                # 성공한 경우 응답 파싱
                                parsed = parse_analysis_response(result)
                                st.session_state.parsed_result = parsed
                                
                                # 파싱 결과 확인
                                if not parsed.get("success", False):
                                    st.warning(f"⚠️ 분석은 성공했지만 파싱 중 문제가 발생했습니다: {parsed.get('error_message', '알 수 없는 오류')}")
                            
                            st.session_state.is_analyzing = False
                            # rerun 제거 - Streamlit이 자동으로 업데이트함
                except Exception as e:
                    st.error(f"❌ 분석 중 예외가 발생했습니다: {str(e)}")
                    # st.exception은 재귀 오류를 유발할 수 있으므로 제거
                    st.session_state.is_analyzing = False
            else:
                st.error("❌ 분석할 이미지가 없습니다.")
    else:
        st.info("👆 왼쪽 웹캠에서 이미지를 촬영하고 '이미지 캡처' 버튼을 클릭해주세요.")
        st.image(
            "https://via.placeholder.com/400x300?text=No+Image",
            caption="이미지가 촬영되면 여기에 표시됩니다"
        )

# ============================================================================
# 분석 결과 표시 영역
# ============================================================================
if st.session_state.parsed_result is not None:
    st.markdown("---")
    st.markdown("### 📊 얼굴 표정 분석 결과")
    
    parsed = st.session_state.parsed_result
    
    if parsed.get("success", False):
        # 성공적인 분석 결과
        emotion = parsed.get("emotion")
        summary = parsed.get("summary")
        emoji = get_emotion_emoji(emotion)
        
        # 감정 카드 표시
        col1, col2 = st.columns([1, 3])
        
        with col1:
            st.markdown(f"""
            <div style='text-align: center; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                        border-radius: 15px; color: white;'>
                <div style='font-size: 80px; margin-bottom: 10px;'>{emoji}</div>
                <div style='font-size: 24px; font-weight: bold;'>{emotion}</div>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown("#### 💭 간단한 설명")
            st.info(f"**{summary}**")
        
        # 전체 분석 결과 (확장 가능)
        with st.expander("📝 전체 분석 결과 보기", expanded=False):
            st.markdown(parsed.get("full_analysis", ""))
        
        # 사용량 정보
        with st.expander("📈 API 사용량 정보", expanded=False):
            if "usage" in parsed:
                usage = parsed["usage"]
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("프롬프트 토큰", f"{usage.get('prompt_tokens', 0):,}")
                with col2:
                    st.metric("응답 토큰", f"{usage.get('completion_tokens', 0):,}")
                with col3:
                    st.metric("총 토큰", f"{usage.get('total_tokens', 0):,}")
            
            if "model" in parsed:
                st.write(f"**사용된 모델:** {parsed['model']}")
    
    else:
        # 오류 처리
        error_type = parsed.get("error_type", "unknown")
        error_message = parsed.get("error_message", "알 수 없는 오류가 발생했습니다.")
        
        if error_type == "api_refusal":
            st.error("🚫 **API 거부 응답**")
            st.warning(f"{error_message}")
            st.info("""
            💡 **해결 방법:**
            - 다른 이미지로 다시 시도해보세요
            - 이미지가 명확하고 얼굴이 잘 보이는지 확인하세요
            - 잠시 후 다시 시도해보세요
            """)
        
        elif error_type == "face_not_detected":
            st.error("👤 **얼굴 인식 실패**")
            st.warning(f"{error_message}")
            st.info("""
            💡 **해결 방법:**
            - 얼굴이 명확하게 보이는 이미지를 사용하세요
            - 조명이 충분한 환경에서 촬영하세요
            - 얼굴이 가려지지 않았는지 확인하세요
            """)
        
        elif error_type == "emotion_not_detected":
            st.warning("❓ **감정 판단 불가**")
            st.info(f"{error_message}")
            if parsed.get("summary"):
                st.write(f"**추출된 설명:** {parsed['summary']}")
        
        elif error_type == "api_error":
            st.error("🔴 **API 오류**")
            st.error(f"{error_message}")
            st.info("""
            💡 **해결 방법:**
            - OpenAI API 키가 올바른지 확인하세요
            - 인터넷 연결을 확인하세요
            - API 사용량 한도를 확인하세요
            """)
        
        elif error_type == "empty_response":
            st.error("⚠️ **응답 오류**")
            st.error(f"{error_message}")
        
        else:
            st.error("❌ **오류 발생**")
            st.error(f"{error_message}")
        
        # 전체 분석 결과가 있으면 표시
        if parsed.get("full_analysis"):
            with st.expander("📝 원본 응답 보기", expanded=False):
                st.markdown(parsed["full_analysis"])

# ============================================================================
# 하단 안내 메시지
# ============================================================================
st.markdown("---")
st.markdown("""
<div style='text-align: center; color: #666; padding: 20px;'>
    <p>💡 <strong>사용 방법:</strong></p>
    <p>1. 웹캠 접근 권한을 허용해주세요</p>
    <p>2. 웹캠에 얼굴을 맞춰주세요</p>
    <p>3. 웹캠 화면에서 이미지가 표시되면 "이미지 캡처" 버튼을 클릭하세요</p>
    <p>4. 촬영된 이미지가 표시되면 "얼굴 표정 분석하기" 버튼을 클릭하세요</p>
    <p>5. OpenAI Vision 모델이 얼굴 표정을 분석하여 결과를 표시합니다</p>
</div>
""", unsafe_allow_html=True)

# ============================================================================
# 사이드바: 기술 정보
# ============================================================================
with st.sidebar:
    st.markdown("### 🔧 기술 정보")
    st.markdown(f"""
    **이미지 처리 방식:**
    - **PIL Image**: 이미지 조작 및 표시
    - **Bytes**: 바이너리 데이터 형태
    - **Base64**: OpenAI API 전송 형식
    
    **처리 특징:**
    - ✅ 메모리 기반 처리 (임시 파일 없음)
    - ✅ 자동 리사이즈 (최대 {MAX_IMAGE_SIZE}px)
    - ✅ 이미지 최적화 (품질: {IMAGE_QUALITY}%)
    
    **지원 감정:**
    - 😊 행복
    - 😢 슬픔
    - 😠 분노
    - 😲 놀람
    - 😐 중립
    - 😰 긴장/불안
    """)
    
    st.markdown("---")
    st.markdown("### 📚 프로젝트 정보")
    st.markdown("""
    **OpenAI MultiModal Chatbot Project**
    
    얼굴 표정 분석을 위한
    멀티모달 챗봇 애플리케이션
    """)
