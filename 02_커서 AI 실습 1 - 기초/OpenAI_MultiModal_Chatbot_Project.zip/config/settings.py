"""
애플리케이션 설정 파일
환경 변수 로드 및 설정 관리
"""

import os
from dotenv import load_dotenv

# .env 파일에서 환경 변수 로드
load_dotenv()

# OpenAI API 설정
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
# 사용 가능한 Vision 모델: 
# - "gpt-5.2" (최신, Vision 지원)
# - "gpt-5.2-pro" (고성능 버전)
# - "gpt-5-mini" (경량 버전)
# - "gpt-4o" (이전 최신 모델)
# 참고: "gpt-4-vision-preview"는 더 이상 사용 불가 (deprecated)
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.2")

# 이미지 처리 설정
MAX_IMAGE_SIZE = int(os.getenv("MAX_IMAGE_SIZE", "1024"))
IMAGE_QUALITY = int(os.getenv("IMAGE_QUALITY", "85"))
IMAGE_FORMAT = os.getenv("IMAGE_FORMAT", "JPEG")

# API 키 검증
if not OPENAI_API_KEY:
    print("⚠️ 경고: OPENAI_API_KEY가 설정되지 않았습니다. .env 파일을 확인하세요.")
