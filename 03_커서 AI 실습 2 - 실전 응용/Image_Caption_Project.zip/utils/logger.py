import logging
import os
from pathlib import Path
from logging.handlers import RotatingFileHandler


def setup_logger(name: str = "app", log_file: str = "logs/app.log", level: int = logging.INFO):
    """
    로거 설정
    
    Args:
        name: 로거 이름
        log_file: 로그 파일 경로
        level: 로깅 레벨 (기본값: INFO)
    
    Returns:
        설정된 로거 객체
    """
    # 로그 디렉토리 생성
    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 로거 생성
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 기존 핸들러 제거 (중복 방지)
    if logger.handlers:
        logger.handlers.clear()
    
    # 파일 핸들러 설정 (회전 로그 파일)
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(level)
    
    # 에러 레벨 이상은 상세 포맷 사용 (스택 트레이스 포함)
    class DetailedFormatter(logging.Formatter):
        def format(self, record):
            # 에러 레벨 이상일 때만 스택 트레이스 포함
            if record.levelno >= logging.ERROR and record.exc_info:
                # 기본 포맷에 스택 트레이스 추가
                result = super().format(record)
                result += '\n' + self.formatException(record.exc_info)
                return result
            # 일반 레벨은 기본 포맷
            return super().format(record)
    
    # 포맷 설정
    detailed_formatter = DetailedFormatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(detailed_formatter)
    
    # 핸들러 추가
    logger.addHandler(file_handler)
    
    return logger
