import cv2
import numpy as np
import base64
from io import BytesIO
from typing import Optional, Union
import streamlit as st


def decode_bytes_to_opencv_image(file_bytes: bytes) -> Optional[np.ndarray]:
    """
    업로드된 파일 바이트를 OpenCV 이미지로 디코딩
    
    Args:
        file_bytes: 이미지 파일의 바이트 데이터
    
    Returns:
        OpenCV 이미지 (numpy array, BGR 형식) 또는 None (디코딩 실패 시)
    
    Raises:
        Exception: 디코딩 중 오류 발생 시
    """
    try:
        if file_bytes is None or len(file_bytes) == 0:
            raise ValueError("파일 바이트가 비어있습니다.")
        
        # 바이트를 numpy array로 변환
        nparr = np.frombuffer(file_bytes, np.uint8)
        
        # OpenCV로 이미지 디코딩
        # cv2.IMREAD_COLOR: 컬러 이미지로 로드 (BGR 형식)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if image is None:
            # 그레이스케일로 시도
            image = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
            if image is not None:
                # 그레이스케일을 BGR로 변환
                image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        
        if image is None:
            raise ValueError("이미지 디코딩에 실패했습니다. 지원되지 않는 형식이거나 손상된 파일일 수 있습니다.")
        
        return image
        
    except ValueError as e:
        raise ValueError(f"이미지 디코딩 오류: {str(e)}")
    except Exception as e:
        raise Exception(f"이미지 디코딩 중 예상치 못한 오류 발생: {str(e)}")


def encode_opencv_image_to_base64(
    image: np.ndarray, 
    format: str = "JPEG",
    quality: int = 95
) -> str:
    """
    OpenCV 이미지를 PNG/JPG로 인코딩 후 base64 문자열로 변환
    
    Args:
        image: OpenCV 이미지 (numpy array, BGR 형식)
        format: 인코딩 포맷 ("JPEG" 또는 "PNG")
        quality: JPEG 품질 (1-100, 기본값: 95). PNG는 무시됨
    
    Returns:
        Base64로 인코딩된 이미지 문자열
    
    Raises:
        ValueError: 잘못된 입력 또는 포맷
        Exception: 인코딩 중 오류 발생 시
    """
    try:
        if image is None:
            raise ValueError("이미지가 None입니다.")
        
        if not isinstance(image, np.ndarray):
            raise ValueError("이미지는 numpy array여야 합니다.")
        
        if len(image.shape) < 2:
            raise ValueError("유효하지 않은 이미지 형식입니다.")
        
        # 포맷 검증 및 변환
        format_upper = format.upper()
        if format_upper not in ["JPEG", "JPG", "PNG"]:
            raise ValueError(f"지원되지 않는 포맷: {format}. JPEG 또는 PNG만 지원됩니다.")
        
        # OpenCV 인코딩 파라미터 설정
        if format_upper in ["JPEG", "JPG"]:
            # JPEG 인코딩
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
            ext = '.jpg'
        else:  # PNG
            # PNG 인코딩 (압축 레벨 0-9, 기본값 3)
            encode_param = [int(cv2.IMWRITE_PNG_COMPRESSION), 3]
            ext = '.png'
        
        # OpenCV로 이미지 인코딩
        success, encoded_image = cv2.imencode(ext, image, encode_param)
        
        if not success:
            raise Exception("이미지 인코딩에 실패했습니다.")
        
        # 바이트로 변환
        image_bytes = encoded_image.tobytes()
        
        # Base64로 인코딩
        base64_string = base64.b64encode(image_bytes).decode('utf-8')
        
        return base64_string
        
    except ValueError as e:
        raise ValueError(f"이미지 인코딩 오류: {str(e)}")
    except Exception as e:
        raise Exception(f"이미지 인코딩 중 예상치 못한 오류 발생: {str(e)}")


def load_image(uploaded_file) -> Optional[np.ndarray]:
    """
    Streamlit 업로드 파일을 OpenCV 이미지로 변환
    (기존 호환성을 위한 래퍼 함수)
    
    Args:
        uploaded_file: Streamlit file_uploader로 업로드된 파일 객체
    
    Returns:
        OpenCV 이미지 (numpy array, BGR 형식) 또는 None (로드 실패 시)
    """
    try:
        # 파일 바이트 읽기
        uploaded_file.seek(0)
        file_bytes = uploaded_file.read()
        
        # 바이트를 OpenCV 이미지로 디코딩
        image = decode_bytes_to_opencv_image(file_bytes)
        
        return image
        
    except Exception as e:
        st.error(f"이미지 로드 오류: {str(e)}")
        return None


def encode_image_to_base64(uploaded_file, format: str = "JPEG") -> str:
    """
    업로드된 이미지 파일을 base64 문자열로 인코딩
    (기존 호환성을 위한 래퍼 함수)
    
    Args:
        uploaded_file: Streamlit file_uploader로 업로드된 파일 객체
        format: 이미지 포맷 (JPEG, PNG 등)
    
    Returns:
        Base64로 인코딩된 이미지 문자열
    
    Raises:
        Exception: 인코딩 실패 시
    """
    try:
        # 먼저 OpenCV 이미지로 로드
        image = load_image(uploaded_file)
        
        if image is None:
            raise Exception("이미지를 로드할 수 없습니다.")
        
        # OpenCV 이미지를 base64로 인코딩
        base64_string = encode_opencv_image_to_base64(image, format=format)
        
        return base64_string
        
    except Exception as e:
        raise Exception(f"이미지 인코딩 오류: {str(e)}")


def resize_image(image: np.ndarray, max_width: int = 1024, max_height: int = 1024) -> np.ndarray:
    """
    이미지 크기 조정 (비율 유지)
    
    Args:
        image: OpenCV 이미지 (numpy array)
        max_width: 최대 너비
        max_height: 최대 높이
    
    Returns:
        크기 조정된 이미지
    
    Raises:
        ValueError: 잘못된 입력
    """
    try:
        if image is None:
            raise ValueError("이미지가 None입니다.")
        
        if not isinstance(image, np.ndarray):
            raise ValueError("이미지는 numpy array여야 합니다.")
        
        height, width = image.shape[:2]
        
        # 비율 계산
        ratio = min(max_width / width, max_height / height)
        
        if ratio < 1:
            new_width = int(width * ratio)
            new_height = int(height * ratio)
            resized_image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
            return resized_image
        
        return image
        
    except Exception as e:
        raise ValueError(f"이미지 리사이즈 오류: {str(e)}")
