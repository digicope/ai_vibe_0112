import os
from openai import OpenAI
from typing import Optional


class ImageCaptioner:
    """이미지 캡션 생성을 위한 클래스"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        ImageCaptioner 초기화
        
        Args:
            api_key: OpenAI API 키 (없으면 환경 변수에서 로드)
        """
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.client = None
        if self.api_key:
            self.client = OpenAI(api_key=self.api_key)
    
    def set_api_key(self, api_key: str):
        """
        API 키 설정
        
        Args:
            api_key: OpenAI API 키
        """
        self.api_key = api_key
        self.client = OpenAI(api_key=self.api_key)
    
    def generate_caption(
        self,
        base64_image: str,
        model: str = "gpt-4o",
        custom_prompt: str = "이 이미지를 자세히 분석하고 한국어로 설명해주세요."
    ) -> str:
        """
        이미지 캡션 생성
        
        Args:
            base64_image: Base64로 인코딩된 이미지 문자열
            model: 사용할 OpenAI 모델 (기본값: gpt-4o)
            custom_prompt: 커스텀 프롬프트 (기본값: 한국어 설명 요청)
        
        Returns:
            생성된 캡션 문자열
        
        Raises:
            ValueError: API 키가 설정되지 않은 경우
            Exception: OpenAI API 호출 실패 시
        """
        if not self.client:
            raise ValueError("API 키가 설정되지 않았습니다. set_api_key()를 호출하거나 환경 변수를 설정해주세요.")
        
        try:
            response = self.client.chat.completions.create(
                model=model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": custom_prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_image}"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=500
            )
            
            caption = response.choices[0].message.content
            return caption
            
        except Exception as e:
            raise Exception(f"캡션 생성 중 오류 발생: {str(e)}")
