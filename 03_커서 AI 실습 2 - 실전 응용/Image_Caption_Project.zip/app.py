import streamlit as st
import os
import cv2
import numpy as np
from dotenv import load_dotenv
from services.captioner import ImageCaptioner
from utils.image_utils import load_image, encode_image_to_base64
from utils.logger import setup_logger

# 로거 설정
logger = setup_logger()

# 환경 변수 로드
load_dotenv()

# 페이지 설정
st.set_page_config(
    page_title="자동 이미지 캡션 생성기",
    page_icon="🖼️",
    layout="wide"
)

# 세션 상태 초기화
if 'captioner' not in st.session_state:
    st.session_state.captioner = ImageCaptioner()

if 'generated_caption' not in st.session_state:
    st.session_state.generated_caption = None

if 'loaded_image' not in st.session_state:
    st.session_state.loaded_image = None

# 메인 타이틀
st.title("🖼️ 자동 이미지 캡션 생성기")
st.markdown("---")

# 사이드바
with st.sidebar:
    st.header("⚙️ 설정")
    
    # API 키 입력
    api_key = st.text_input(
        "OpenAI API Key",
        type="password",
        value=os.getenv("OPENAI_API_KEY", ""),
        help="OpenAI API 키를 입력하세요. .env 파일에 설정하거나 여기에 직접 입력할 수 있습니다."
    )
    
    if api_key:
        st.session_state.captioner.set_api_key(api_key)
        st.success("✅ API 키가 설정되었습니다")
    else:
        st.warning("⚠️ API 키를 입력해주세요")
    
    st.markdown("---")
    
    # 모델 선택
    model = st.selectbox(
        "모델 선택",
        ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo"],
        index=0,
        help="이미지 캡션 생성에 사용할 모델을 선택하세요."
    )
    
    # 프롬프트 커스터마이징
    st.markdown("---")
    st.subheader("프롬프트 설정")
    custom_prompt = st.text_area(
        "커스텀 프롬프트 (선택사항)",
        value="이 이미지를 자세히 분석하고 한국어로 설명해주세요.",
        help="이미지 분석에 대한 추가 지시사항을 입력할 수 있습니다."
    )
    
    # 도움말
    st.markdown("---")
    with st.expander("📖 도움말"):
        st.info("""
        **사용 방법:**
        1. OpenAI API 키를 입력하세요
        2. 이미지를 업로드하세요
        3. '캡션 생성' 버튼을 클릭하세요
        
        **지원 형식:**
        - JPG, PNG, GIF, WebP
        - 최대 20MB
        """)

# 메인 컨텐츠 영역
col1, col2 = st.columns([1, 1])

with col1:
    st.subheader("📤 이미지 업로드")
    uploaded_file = st.file_uploader(
        "이미지를 선택하세요",
        type=['jpg', 'jpeg', 'png', 'gif', 'webp'],
        help="이미지 파일을 업로드하세요"
    )
    
    # 업로드 파일이 없는 경우
    if uploaded_file is None:
        st.info("📁 이미지 파일을 업로드해주세요.")
        st.session_state.loaded_image = None
    else:
        # 이미지 크기 체크 (5MB 초과 시 경고 후 중단)
        MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
        file_size_mb = uploaded_file.size / (1024 * 1024)
        
        if uploaded_file.size > MAX_FILE_SIZE:
            error_msg = f"⚠️ 이미지 파일 크기가 너무 큽니다. (현재: {file_size_mb:.2f}MB, 최대: 5MB)\n\n더 작은 이미지를 업로드하거나 이미지를 압축해주세요."
            st.error(error_msg)
            logger.warning(f"이미지 크기 초과: {uploaded_file.name}, 크기: {file_size_mb:.2f}MB")
            st.session_state.loaded_image = None
        else:
            # OpenCV로 이미지 로드 시도
            try:
                logger.info(f"이미지 업로드 시작: {uploaded_file.name}, 크기: {file_size_mb:.2f}MB")
                with st.spinner("이미지를 로드하는 중..."):
                    # OpenCV로 이미지 읽기
                    cv_image = load_image(uploaded_file)
                    
                    if cv_image is not None:
                        # OpenCV 이미지 정보 표시
                        height, width = cv_image.shape[:2]
                        channels = cv_image.shape[2] if len(cv_image.shape) == 3 else 1
                        
                        # OpenCV는 BGR 형식이므로 RGB로 변환하여 Streamlit에 표시
                        rgb_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
                        
                        # 이미지 미리보기 표시
                        st.image(rgb_image, caption="업로드된 이미지 (OpenCV 미리보기)")
                        
                        # 세션 상태에 저장
                        st.session_state.loaded_image = cv_image
                        
                        # 파일 정보
                        st.success("✅ 이미지가 성공적으로 로드되었습니다!")
                        file_details = {
                            "파일명": uploaded_file.name,
                            "파일 타입": uploaded_file.type,
                            "파일 크기": f"{file_size_mb:.2f} MB",
                            "이미지 크기": f"{width} x {height}",
                            "채널 수": channels
                        }
                        st.json(file_details)
                        logger.info(f"이미지 로드 성공: {uploaded_file.name}, 해상도: {width}x{height}")
                    else:
                        error_msg = "❌ 이미지를 로드할 수 없습니다.\n\n파일이 손상되었거나 지원되지 않는 형식일 수 있습니다."
                        st.error(error_msg)
                        logger.error(f"이미지 로드 실패: {uploaded_file.name}")
                        st.session_state.loaded_image = None
                        
            except Exception as e:
                error_msg = f"❌ 이미지 로드 중 오류가 발생했습니다.\n\n오류 내용: {str(e)}\n\n다른 이미지 파일을 시도해주세요."
                st.error(error_msg)
                logger.error(f"이미지 로드 중 예외 발생: {uploaded_file.name}", exc_info=True)
                st.session_state.loaded_image = None

with col2:
    st.subheader("📝 생성된 캡션")
    
    if uploaded_file is not None and st.session_state.loaded_image is not None:
        # 캡션 생성 버튼
        if st.button("✨ 캡션 생성", type="primary", use_container_width=True):
            # API 키 확인
            if not api_key:
                error_msg = "⚠️ API 키를 먼저 입력해주세요!\n\n사이드바에서 OpenAI API 키를 입력하거나 .env 파일에 설정해주세요."
                st.error(error_msg)
                logger.warning("캡션 생성 시도: API 키 미설정")
            else:
                # 진행 중 spinner 표시
                with st.spinner("캡션을 생성하는 중..."):
                    try:
                        logger.info(f"캡션 생성 시작: 모델={model}, 파일={uploaded_file.name}")
                        
                        # 1. 업로드 이미지를 base64로 변환
                        base64_image = encode_image_to_base64(uploaded_file)
                        
                        # 2. Base64 길이 체크 (OpenAI API 제한: 약 20MB, base64는 약 26.7MB)
                        # 안전을 위해 20MB로 제한 (base64 문자열 길이로 계산)
                        MAX_BASE64_SIZE = 20 * 1024 * 1024  # 20MB
                        base64_size_mb = len(base64_image) / (1024 * 1024)
                        
                        if len(base64_image) > MAX_BASE64_SIZE:
                            error_msg = f"⚠️ 인코딩된 이미지 크기가 너무 큽니다. (현재: {base64_size_mb:.2f}MB, 최대: 20MB)\n\n더 작은 이미지를 업로드하거나 이미지를 압축해주세요."
                            st.error(error_msg)
                            logger.warning(f"Base64 크기 초과: {base64_size_mb:.2f}MB")
                        else:
                            logger.info(f"Base64 인코딩 완료: 크기={base64_size_mb:.2f}MB")
                            
                            # 3. services/captioner.py로 캡션 생성 호출
                            caption = st.session_state.captioner.generate_caption(
                                base64_image=base64_image,
                                model=model,
                                custom_prompt=custom_prompt
                            )
                            
                            # 4. 결과 캡션을 세션 상태에 저장
                            st.session_state.generated_caption = caption
                            st.success("✅ 캡션이 생성되었습니다!")
                            logger.info(f"캡션 생성 성공: 모델={model}, 캡션 길이={len(caption)}자")
                        
                    except ValueError as e:
                        error_msg = f"❌ 입력 오류가 발생했습니다.\n\n오류 내용: {str(e)}\n\n입력값을 확인하고 다시 시도해주세요."
                        st.error(error_msg)
                        logger.error(f"캡션 생성 중 ValueError: {str(e)}", exc_info=True)
                    except Exception as e:
                        error_msg = f"❌ 캡션 생성 중 오류가 발생했습니다.\n\n오류 내용: {str(e)}\n\n다시 시도하거나 다른 이미지를 업로드해주세요."
                        st.error(error_msg)
                        logger.error(f"캡션 생성 중 예외 발생: {str(e)}", exc_info=True)
        
        # 생성된 캡션 표시
        if st.session_state.generated_caption:
            st.markdown("---")
            st.markdown("### 📄 생성된 설명:")
            st.write(st.session_state.generated_caption)
            
            # 캡션 코드 블록으로 표시
            st.code(st.session_state.generated_caption, language=None)
            
            # 캡션 복사 안내
            st.info("💡 위의 캡션을 선택하여 복사할 수 있습니다.")
    else:
        st.info("👈 왼쪽에서 이미지를 업로드해주세요")

# 푸터
st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: gray;'>자동 이미지 캡션 생성기 v1.0</div>",
    unsafe_allow_html=True
)
