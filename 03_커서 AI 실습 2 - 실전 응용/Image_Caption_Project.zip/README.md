# 🖼️ 자동 이미지 캡션 생성기

OpenAI Vision API를 활용하여 업로드된 이미지를 분석하고 자세한 한국어 설명을 자동으로 생성하는 Streamlit 기반 웹 애플리케이션입니다.

## 📋 목차

- [주요 기능](#주요-기능)
- [프로젝트 구조](#프로젝트-구조)
- [설치 방법](#설치-방법)
- [환경 설정](#환경-설정)
- [실행 방법](#실행-방법)
- [사용 방법](#사용-방법)
- [자주 발생하는 오류](#자주-발생하는-오류)
- [기술 스택](#기술-스택)
- [로깅](#로깅)

## ✨ 주요 기능

- **이미지 업로드 및 미리보기**: OpenCV를 사용한 이미지 로드 및 표시
- **AI 기반 캡션 생성**: OpenAI Vision API를 통한 자동 이미지 분석 및 설명 생성
- **커스텀 프롬프트**: 원하는 스타일의 설명을 위한 프롬프트 커스터마이징
- **다양한 모델 지원**: GPT-4o, GPT-4o-mini, GPT-4-turbo 모델 선택 가능
- **안정성 검증**: 이미지 크기 및 Base64 인코딩 크기 자동 검증
- **로깅 시스템**: 모든 작업 및 오류를 로그 파일에 기록

## 📁 프로젝트 구조

```
Image_Caption_Project/
├── app.py                 # Streamlit 메인 애플리케이션
├── requirements.txt       # 프로젝트 의존성 패키지
├── .env                   # 환경 변수 (API 키 등)
├── README.md              # 프로젝트 문서
├── services/
│   └── captioner.py       # OpenAI API 호출 및 캡션 생성 로직
├── utils/
│   ├── image_utils.py     # 이미지 처리 유틸리티 (OpenCV, base64)
│   └── logger.py          # 로깅 시스템
├── templates/
│   └── help.html          # 도움말 HTML
└── logs/
    └── app.log            # 애플리케이션 로그 파일
```

## 🚀 설치 방법

### 1. 저장소 클론 또는 프로젝트 폴더로 이동

```bash
cd Image_Caption_Project
```

### 2. 가상 환경 생성 (권장)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. 패키지 설치

```bash
pip install -r requirements.txt
```

설치되는 주요 패키지:
- `streamlit`: 웹 애플리케이션 프레임워크
- `opencv-python`: 이미지 처리
- `python-dotenv`: 환경 변수 관리
- `openai`: OpenAI API 클라이언트
- `Pillow`: 이미지 처리
- `numpy`: 수치 연산

## ⚙️ 환경 설정

### .env 파일 생성

프로젝트 루트 디렉토리에 `.env` 파일을 생성하고 OpenAI API 키를 설정하세요.

```env
OPENAI_API_KEY=your_openai_api_key_here
```

**중요 사항:**
- `.env` 파일은 절대 공개 저장소에 커밋하지 마세요!
- OpenAI API 키는 [OpenAI Platform](https://platform.openai.com/api-keys)에서 발급받을 수 있습니다.
- API 키가 없어도 애플리케이션은 실행되지만, 사이드바에서 직접 입력할 수 있습니다.

### .env 파일 예시

```env
# OpenAI API 키
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## ▶️ 실행 방법

### 1. 환경 변수 확인

`.env` 파일이 올바르게 설정되었는지 확인하세요.

### 2. Streamlit 애플리케이션 실행

```bash
streamlit run app.py
```

### 3. 브라우저에서 접속

실행 후 자동으로 브라우저가 열리거나, 터미널에 표시된 URL로 접속하세요.

일반적으로: `http://localhost:8501`

## 📖 사용 방법

1. **API 키 설정**
   - 사이드바에서 OpenAI API 키를 입력하거나
   - `.env` 파일에 미리 설정

2. **모델 선택**
   - 사이드바에서 사용할 모델 선택 (gpt-4o, gpt-4o-mini, gpt-4-turbo)

3. **이미지 업로드**
   - 왼쪽 영역에서 이미지 파일 업로드
   - 지원 형식: JPG, JPEG, PNG, GIF, WebP
   - 최대 크기: 5MB

4. **프롬프트 설정 (선택사항)**
   - 사이드바에서 커스텀 프롬프트 입력
   - 기본값: "이 이미지를 자세히 분석하고 한국어로 설명해주세요."

5. **캡션 생성**
   - "✨ 캡션 생성" 버튼 클릭
   - 생성된 캡션을 오른쪽 영역에서 확인

## ⚠️ 자주 발생하는 오류

### 1. API 키 미설정 오류

**오류 메시지:**
```
⚠️ API 키를 먼저 입력해주세요!
```

**원인:**
- `.env` 파일에 API 키가 설정되지 않았거나
- 사이드바에서 API 키를 입력하지 않았을 때

**해결 방법:**
1. `.env` 파일을 생성하고 `OPENAI_API_KEY=your_key` 형식으로 설정
2. 또는 사이드바의 "OpenAI API Key" 입력란에 직접 입력
3. API 키는 [OpenAI Platform](https://platform.openai.com/api-keys)에서 발급

---

### 2. 파일 형식 문제

**오류 메시지:**
```
❌ 이미지를 로드할 수 없습니다.
파일이 손상되었거나 지원되지 않는 형식일 수 있습니다.
```

**원인:**
- 지원되지 않는 이미지 형식 (예: BMP, TIFF)
- 손상된 이미지 파일
- OpenCV가 디코딩할 수 없는 형식

**해결 방법:**
1. 지원되는 형식으로 변환: JPG, JPEG, PNG, GIF, WebP
2. 이미지 편집 프로그램으로 다시 저장
3. 다른 이미지 파일로 시도

---

### 3. 이미지 크기 초과 오류

**오류 메시지:**
```
⚠️ 이미지 파일 크기가 너무 큽니다. (현재: X.XXMB, 최대: 5MB)
```

**원인:**
- 업로드한 이미지 파일이 5MB를 초과할 때

**해결 방법:**
1. 이미지 압축 도구 사용 (온라인 또는 이미지 편집 프로그램)
2. 이미지 해상도 축소
3. 이미지 품질 조정 (JPEG 품질 낮추기)

---

### 4. Base64 인코딩 크기 초과

**오류 메시지:**
```
⚠️ 인코딩된 이미지 크기가 너무 큽니다. (현재: X.XXMB, 최대: 20MB)
```

**원인:**
- Base64로 인코딩된 이미지가 OpenAI API 제한(20MB)을 초과할 때

**해결 방법:**
1. 이미지 크기 축소 (해상도 낮추기)
2. 이미지 압축
3. 더 작은 이미지 파일 사용

---

### 5. OpenAI API 호출 실패

**오류 메시지:**
```
❌ 캡션 생성 중 오류가 발생했습니다.
```

**원인:**
- API 키가 유효하지 않음
- API 사용량 제한 초과
- 네트워크 연결 문제
- OpenAI 서버 오류

**해결 방법:**
1. API 키가 올바른지 확인
2. OpenAI 계정의 사용량 및 크레딧 확인
3. 인터넷 연결 확인
4. 잠시 후 다시 시도

## 🛠️ 기술 스택

- **Frontend**: Streamlit
- **AI API**: OpenAI Vision API (GPT-4o, GPT-4o-mini, GPT-4-turbo)
- **이미지 처리**: OpenCV, PIL (Pillow)
- **환경 변수 관리**: python-dotenv
- **로깅**: Python logging 모듈

## 📝 로깅

애플리케이션의 모든 작업과 오류는 `logs/app.log` 파일에 기록됩니다.

### 로그 레벨

- **INFO**: 일반 작업 정보 (이미지 업로드, 캡션 생성 등)
- **WARNING**: 경고 메시지 (크기 초과 등)
- **ERROR**: 오류 발생 시 상세 스택 트레이스 포함

### 로그 파일 관리

- 최대 파일 크기: 10MB
- 백업 파일 수: 5개
- 자동 로그 회전 지원

### 로그 확인 방법

```bash
# Windows
type logs\app.log

# macOS/Linux
cat logs/app.log

# 실시간 로그 확인 (tail)
tail -f logs/app.log
```

## 📄 라이선스

이 프로젝트는 교육 및 개인 사용 목적으로 제작되었습니다.

## 🤝 기여

버그 리포트나 기능 제안은 이슈로 등록해주세요.

## 📧 문의

프로젝트 관련 문의사항이 있으시면 이슈를 생성해주세요.

---

**자동 이미지 캡션 생성기 v1.0** | Made with ❤️
