"""
네이버 뉴스 검색 테스트 스크립트
실제 HTML 구조를 분석하여 문제를 파악합니다.
"""
import requests
from bs4 import BeautifulSoup
import urllib.parse
import re

def test_naver_news_search(keyword='인공지능'):
    """네이버 뉴스 검색 테스트"""
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7'
    }
    
    # URL 생성
    encoded_keyword = urllib.parse.quote(keyword)
    search_url = f"https://search.naver.com/search.naver?where=news&query={encoded_keyword}"
    
    print("=" * 80)
    print(f"검색 키워드: {keyword}")
    print(f"검색 URL: {search_url}")
    print("=" * 80)
    
    try:
        # 요청 보내기
        response = requests.get(search_url, headers=headers, timeout=15)
        response.raise_for_status()
        response.encoding = 'utf-8'
        
        print(f"\n[OK] 응답 성공")
        print(f"   상태 코드: {response.status_code}")
        print(f"   응답 길이: {len(response.text):,} bytes")
        print(f"   인코딩: {response.encoding}")
        
        # HTML 파싱
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 1. 모든 링크 분석
        print("\n" + "=" * 80)
        print("1. 모든 링크 분석")
        print("=" * 80)
        
        all_links = soup.find_all('a', href=True)
        print(f"전체 링크 수: {len(all_links)}")
        
        news_links = []
        for link in all_links:
            href = link.get('href', '')
            if 'news.naver.com' in href or 'n.news.naver.com' in href:
                title = link.get_text(strip=True)
                news_links.append({
                    'href': href,
                    'title': title,
                    'class': link.get('class', []),
                    'element': link
                })
        
        print(f"\n뉴스 관련 링크: {len(news_links)}개")
        print("\n처음 10개 링크:")
        for i, news in enumerate(news_links[:10], 1):
            print(f"\n{i}. 제목: {news['title'][:60]}")
            print(f"   링크: {news['href']}")
            print(f"   클래스: {news['class']}")
        
        # 2. news_wrap 클래스 찾기
        print("\n" + "=" * 80)
        print("2. news_wrap 클래스 요소 찾기")
        print("=" * 80)
        
        news_wraps = soup.find_all('div', class_='news_wrap')
        print(f"news_wrap 요소: {len(news_wraps)}개")
        
        if news_wraps:
            print("\n첫 번째 news_wrap 내용:")
            print(news_wraps[0].prettify()[:500])
        
        # 3. 다른 가능한 클래스 찾기
        print("\n" + "=" * 80)
        print("3. 뉴스 관련 가능한 클래스 찾기")
        print("=" * 80)
        
        # news 관련 클래스 찾기
        news_classes = set()
        for elem in soup.find_all(class_=True):
            classes = elem.get('class', [])
            for cls in classes:
                if 'news' in cls.lower() or 'article' in cls.lower():
                    news_classes.add(cls)
        
        print(f"뉴스 관련 클래스: {sorted(news_classes)}")
        
        # 4. ul, li 구조 찾기
        print("\n" + "=" * 80)
        print("4. ul, li 구조 찾기")
        print("=" * 80)
        
        ul_elements = soup.find_all('ul')
        print(f"ul 요소: {len(ul_elements)}개")
        
        for i, ul in enumerate(ul_elements[:5], 1):
            classes = ul.get('class', [])
            li_count = len(ul.find_all('li'))
            print(f"\n{i}. ul 클래스: {classes}, li 개수: {li_count}")
            if li_count > 0:
                first_li = ul.find('li')
                if first_li:
                    print(f"   첫 번째 li 클래스: {first_li.get('class', [])}")
        
        # 5. 특정 패턴의 div 찾기
        print("\n" + "=" * 80)
        print("5. 뉴스 관련 div 요소 찾기")
        print("=" * 80)
        
        # api_ani_send, bx 등
        special_divs = soup.find_all('div', class_=re.compile(r'api|bx|news|article', re.I))
        print(f"특수 div 요소: {len(special_divs)}개")
        
        if special_divs:
            print("\n처음 3개 div의 클래스:")
            for i, div in enumerate(special_divs[:3], 1):
                print(f"{i}. {div.get('class', [])}")
        
        # 6. 실제 뉴스 기사 링크 필터링 테스트
        print("\n" + "=" * 80)
        print("6. 실제 뉴스 기사 링크 필터링 테스트")
        print("=" * 80)
        
        valid_news = []
        exclude_patterns = ['channelPromotion', 'static', 'promotion', 'main/static']
        
        for news in news_links:
            href = news['href']
            title = news['title']
            
            # 제외 패턴 확인
            should_exclude = any(pattern in href.lower() for pattern in exclude_patterns)
            
            # article 경로 확인
            has_article = '/article/' in href
            
            if not should_exclude and has_article and len(title) > 10:
                valid_news.append(news)
        
        print(f"유효한 뉴스 기사: {len(valid_news)}개")
        for i, news in enumerate(valid_news[:5], 1):
            print(f"\n{i}. {news['title'][:60]}")
            print(f"   {news['href']}")
        
        # 7. HTML 샘플 저장 (디버깅용)
        print("\n" + "=" * 80)
        print("7. HTML 샘플 저장")
        print("=" * 80)
        
        # 처음 5000자만 저장
        with open('test_naver_news_sample.html', 'w', encoding='utf-8') as f:
            f.write(response.text[:10000])
        print("HTML 샘플이 'test_naver_news_sample.html' 파일로 저장되었습니다.")
        
        # 8. JSON 데이터 구조 확인
        print("\n" + "=" * 80)
        print("8. JSON 데이터 확인 (동적 로딩)")
        print("=" * 80)
        
        # 네이버는 종종 JSON으로 데이터를 전달합니다
        scripts = soup.find_all('script')
        json_data_found = False
        for script in scripts:
            script_text = script.string
            if script_text and ('news' in script_text.lower() or 'article' in script_text.lower()):
                if len(script_text) > 100:
                    print(f"스크립트에서 데이터 발견 (길이: {len(script_text)})")
                    # JSON 패턴 찾기
                    json_matches = re.findall(r'\{[^{}]*"title"[^{}]*\}', script_text)
                    if json_matches:
                        print(f"JSON 패턴 발견: {len(json_matches)}개")
                        json_data_found = True
                        print("처음 3개 샘플:")
                        for match in json_matches[:3]:
                            print(f"  {match[:100]}...")
        
        if not json_data_found:
            print("JSON 데이터를 찾을 수 없습니다.")
        
        print("\n" + "=" * 80)
        print("테스트 완료!")
        print("=" * 80)
        
        return {
            'total_links': len(all_links),
            'news_links': len(news_links),
            'valid_news': len(valid_news),
            'news_wraps': len(news_wraps)
        }
        
    except Exception as e:
        print(f"\n[ERROR] 오류 발생: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    print("네이버 뉴스 검색 테스트 시작...\n")
    result = test_naver_news_search('인공지능')
    
    if result:
        print("\n[요약]")
        print(f"   전체 링크: {result['total_links']}개")
        print(f"   뉴스 링크: {result['news_links']}개")
        print(f"   유효한 뉴스: {result['valid_news']}개")
        print(f"   news_wrap 요소: {result['news_wraps']}개")
