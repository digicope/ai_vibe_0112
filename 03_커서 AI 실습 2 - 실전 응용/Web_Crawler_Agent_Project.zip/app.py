"""
뉴스 및 부동산 이슈 기사 수집과 AI 요약을 위한 Streamlit 대시보드
"""
import streamlit as st
import pandas as pd
import os
from datetime import datetime
from dotenv import load_dotenv
import json
import logging
from openai import OpenAI
import plotly.express as px
import plotly.graph_objects as go
from collections import Counter
import re

from scrapers.news_scraper import NewsScraper
from scrapers.article_extractor import ArticleExtractor

# 환경 변수 로드
load_dotenv()

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/app.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 페이지 설정
st.set_page_config(
    page_title="뉴스 & 부동산 이슈 요약 대시보드",
    page_icon="📰",
    layout="wide"
)


def get_openai_client():
    """OpenAI 클라이언트를 안전하게 초기화"""
    if 'openai_client' not in st.session_state:
        openai_api_key = os.getenv('OPENAI_API_KEY')
        if openai_api_key and openai_api_key != 'your_openai_api_key_here':
            try:
                st.session_state.openai_client = OpenAI(api_key=openai_api_key)
            except Exception as e:
                logger.error(f"OpenAI 클라이언트 초기화 실패: {e}")
                st.session_state.openai_client = None
        else:
            st.session_state.openai_client = None
            if not hasattr(st.session_state, 'api_key_warning_shown'):
                st.warning("⚠️ OpenAI API 키가 설정되지 않았습니다. .env 파일에 OPENAI_API_KEY를 설정해주세요.")
                st.session_state.api_key_warning_shown = True
    
    return st.session_state.get('openai_client', None)

# 데이터 디렉토리 확인
os.makedirs('data', exist_ok=True)
os.makedirs('logs', exist_ok=True)


def save_data(data: list, filename: str):
    """데이터를 JSON 파일로 저장"""
    filepath = os.path.join('data', filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    logger.info(f"데이터 저장 완료: {filepath}")


def load_data(filename: str) -> list:
    """JSON 파일에서 데이터 로드"""
    filepath = os.path.join('data', filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []


def summarize_with_ai_3lines(text: str) -> str:
    """OpenAI API를 사용하여 기사 본문을 3줄로 요약"""
    client = get_openai_client()
    if not client:
        return "OpenAI API 키가 설정되지 않아 요약할 수 없습니다."
    
    try:
        # 텍스트 길이 제한 (4000자)
        if not text or len(text.strip()) == 0:
            logger.warning("빈 텍스트로 요약 시도")
            return "본문이 비어있어 요약할 수 없습니다."
        
        text_limited = text[:4000] if len(text) > 4000 else text
        logger.debug(f"요약 요청: 텍스트 길이 {len(text)} -> {len(text_limited)}")
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "당신은 뉴스 기사를 정확하고 간결하게 요약하는 전문가입니다. 반드시 3줄로 요약해주세요."},
                {"role": "user", "content": f"다음 기사 본문을 정확히 3줄로 요약해주세요. 각 줄은 핵심 내용을 담아야 합니다. 한국어로 답변해주세요:\n\n{text_limited}"}
            ],
            max_tokens=300,
            temperature=0.7,
            timeout=30  # API 호출 timeout
        )
        summary = response.choices[0].message.content.strip()
        # 3줄로 강제 (줄바꿈으로 분리)
        lines = [line.strip() for line in summary.split('\n') if line.strip()]
        if len(lines) > 3:
            return '\n'.join(lines[:3])
        return summary
    except Exception as e:
        logger.error(f"AI 요약 중 오류: {e}", exc_info=True)
        return f"요약 중 오류가 발생했습니다: {str(e)}"


def extract_keywords_5(text: str) -> str:
    """OpenAI API를 사용하여 기사 핵심 키워드 5개 추출"""
    client = get_openai_client()
    if not client:
        return "OpenAI API 키가 설정되지 않아 키워드를 추출할 수 없습니다."
    
    try:
        # 텍스트 길이 제한 (4000자)
        if not text or len(text.strip()) == 0:
            logger.warning("빈 텍스트로 키워드 추출 시도")
            return "본문이 비어있어 키워드를 추출할 수 없습니다."
        
        text_limited = text[:4000] if len(text) > 4000 else text
        logger.debug(f"키워드 추출 요청: 텍스트 길이 {len(text)} -> {len(text_limited)}")
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "당신은 뉴스 기사에서 핵심 키워드를 추출하는 전문가입니다. 반드시 5개의 키워드를 추출해주세요."},
                {"role": "user", "content": f"다음 기사 본문에서 가장 중요한 핵심 키워드를 정확히 5개 추출해주세요. 키워드는 쉼표로 구분하여 나열해주세요. 한국어로 답변해주세요:\n\n{text_limited}"}
            ],
            max_tokens=100,
            temperature=0.5,
            timeout=30  # API 호출 timeout
        )
        keywords = response.choices[0].message.content.strip()
        # 키워드 정리 (쉼표로 분리, 최대 5개)
        keyword_list = [k.strip() for k in keywords.split(',') if k.strip()]
        return ', '.join(keyword_list[:5])
    except Exception as e:
        logger.error(f"키워드 추출 중 오류: {e}", exc_info=True)
        return f"키워드 추출 중 오류가 발생했습니다: {str(e)}"


def summarize_all_articles_5lines(articles: list) -> str:
    """모든 기사를 종합해서 이슈 전체 요약을 5줄로 생성"""
    client = get_openai_client()
    if not client:
        return "OpenAI API 키가 설정되지 않아 요약할 수 없습니다."
    
    try:
        if not articles:
            logger.warning("빈 기사 리스트로 요약 시도")
            return "요약할 기사가 없습니다."
        
        # 모든 기사의 제목과 요약을 결합
        combined_text = ""
        for idx, article in enumerate(articles, 1):
            title = article.get('title', '제목 없음')
            summary = article.get('summary', '요약 없음')
            combined_text += f"\n[기사 {idx}] {title}\n{summary}\n"
        
        # 텍스트 길이 제한 (6000자)
        text_limited = combined_text[:6000] if len(combined_text) > 6000 else combined_text
        logger.debug(f"전체 요약 요청: 텍스트 길이 {len(combined_text)} -> {len(text_limited)}")
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "당신은 여러 뉴스 기사를 종합하여 전체 이슈를 요약하는 전문가입니다. 반드시 5줄로 요약해주세요."},
                {"role": "user", "content": f"다음 여러 기사의 제목과 요약을 종합하여 해당 이슈의 전체적인 흐름과 핵심 내용을 정확히 5줄로 요약해주세요. 각 줄은 중요한 내용을 담아야 합니다. 한국어로 답변해주세요:\n\n{text_limited}"}
            ],
            max_tokens=400,
            temperature=0.7,
            timeout=30  # API 호출 timeout
        )
        summary = response.choices[0].message.content.strip()
        # 5줄로 강제 (줄바꿈으로 분리)
        lines = [line.strip() for line in summary.split('\n') if line.strip()]
        if len(lines) > 5:
            return '\n'.join(lines[:5])
        return summary
    except Exception as e:
        logger.error(f"전체 요약 생성 중 오류: {e}", exc_info=True)
        return f"전체 요약 생성 중 오류가 발생했습니다: {str(e)}"


def generate_comprehensive_report(articles: list, keyword: str) -> dict:
    """종합 리포트 생성"""
    client = get_openai_client()
    if not client:
        return {
            'overall_summary': "OpenAI API 키가 설정되지 않아 리포트를 생성할 수 없습니다.",
            'key_points': [],
            'top_keywords': []
        }
    
    try:
        if not articles:
            logger.warning("빈 기사 리스트로 리포트 생성 시도")
            return {
                'overall_summary': "리포트를 생성할 기사가 없습니다.",
                'key_points': [],
                'top_keywords': []
            }
        
        # 모든 기사의 제목과 요약을 결합
        combined_text = ""
        for idx, article in enumerate(articles, 1):
            title = article.get('title', '제목 없음')
            summary = article.get('summary', '요약 없음')
            keywords = article.get('keywords', '')
            combined_text += f"\n[기사 {idx}] {title}\n요약: {summary}\n키워드: {keywords}\n"
        
        # 텍스트 길이 제한 (6000자)
        text_limited = combined_text[:6000] if len(combined_text) > 6000 else combined_text
        logger.debug(f"리포트 생성 요청: 텍스트 길이 {len(combined_text)} -> {len(text_limited)}")
        
        # 전체 요약 문단 생성
        summary_response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "당신은 뉴스 기사를 종합하여 전체적인 요약 문단을 작성하는 전문가입니다."},
                {"role": "user", "content": f"다음 여러 기사의 제목과 요약을 종합하여 '{keyword}' 관련 이슈의 전체적인 흐름과 핵심 내용을 하나의 문단으로 요약해주세요. 한국어로 답변해주세요:\n\n{text_limited}"}
            ],
            max_tokens=500,
            temperature=0.7,
            timeout=30  # API 호출 timeout
        )
        overall_summary = summary_response.choices[0].message.content.strip()
        
        # 핵심 포인트 5개 생성
        points_response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "당신은 뉴스 기사에서 핵심 포인트를 추출하는 전문가입니다. 반드시 5개의 핵심 포인트를 추출해주세요."},
                {"role": "user", "content": f"다음 여러 기사의 제목과 요약을 분석하여 '{keyword}' 관련 이슈의 핵심 포인트를 정확히 5개 추출해주세요. 각 포인트는 한 줄로 작성해주세요. 한국어로 답변해주세요:\n\n{text_limited}"}
            ],
            max_tokens=300,
            temperature=0.7,
            timeout=30  # API 호출 timeout
        )
        points_text = points_response.choices[0].message.content.strip()
        # 포인트를 리스트로 변환
        key_points = [p.strip() for p in points_text.split('\n') if p.strip() and not p.strip().startswith('#')]
        # 숫자나 기호 제거
        key_points = [re.sub(r'^[\d\.\-\*•]\s*', '', p) for p in key_points]
        key_points = [p for p in key_points if len(p) > 5][:5]
        
        # 주요 키워드 TOP 10 추출 (모든 기사의 키워드를 수집)
        all_keywords = []
        for article in articles:
            keywords_str = article.get('keywords', '')
            if keywords_str and keywords_str != '키워드 추출 불가':
                keywords_list = [k.strip() for k in keywords_str.split(',') if k.strip()]
                all_keywords.extend(keywords_list)
        
        # 키워드 빈도 계산
        keyword_counter = Counter(all_keywords)
        top_keywords = [{'keyword': k, 'count': v} for k, v in keyword_counter.most_common(10)]
        
        return {
            'overall_summary': overall_summary,
            'key_points': key_points,
            'top_keywords': top_keywords
        }
    except Exception as e:
        logger.error(f"종합 리포트 생성 중 오류: {e}", exc_info=True)
        return {
            'overall_summary': f"리포트 생성 중 오류가 발생했습니다: {str(e)}",
            'key_points': [],
            'top_keywords': []
        }


def news_search_summary():
    """뉴스 검색 요약 페이지"""
    st.header("🔍 뉴스 검색 요약")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        keyword = st.text_input("검색 키워드", placeholder="예: 인공지능, 부동산 정책 등")
    
    with col2:
        max_results = st.number_input("최대 결과 수", min_value=1, max_value=50, value=10)
    
    if st.button("검색 및 요약", type="primary"):
        if not keyword:
            st.error("검색 키워드를 입력해주세요.")
            return
        
        # 단계별 진행 상황 표시
        step_container = st.container()
        
        try:
            with step_container:
                # 1단계: 뉴스 목록 수집
                st.subheader("📰 1단계: 뉴스 목록 수집")
                with st.spinner("뉴스를 검색 중입니다..."):
                    try:
                        scraper = NewsScraper()
                        news_list = scraper.search_news(keyword, max_results=max_results)
                        
                        if not news_list:
                            st.warning("검색 결과가 없습니다.")
                            return
                        
                        st.success(f"✅ {len(news_list)}개의 뉴스 기사를 찾았습니다.")
                    except Exception as e:
                        logger.error(f"뉴스 검색 중 오류: {e}", exc_info=True)
                        st.error(f"❌ 뉴스 검색 중 오류가 발생했습니다: {str(e)}")
                        return
            
                # 2단계: 기사 본문 추출
                st.subheader("📄 2단계: 기사 본문 추출")
                try:
                    extractor = ArticleExtractor()
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    news_with_content = []
                    for idx, news in enumerate(news_list):
                        try:
                            status_text.text(f"본문 추출 중: {news['title'][:50]}... ({idx+1}/{len(news_list)})")
                            content = extractor.extract_content(news['link'])
                            news_with_content.append({
                                **news,
                                'content': content
                            })
                            progress_bar.progress((idx + 1) / len(news_list))
                        except Exception as e:
                            logger.error(f"기사 본문 추출 중 오류 ({news.get('link', 'unknown')}): {e}", exc_info=True)
                            # 오류가 발생해도 계속 진행
                            news_with_content.append({
                                **news,
                                'content': None
                            })
                            progress_bar.progress((idx + 1) / len(news_list))
                    
                    status_text.empty()
                    progress_bar.empty()
                    st.success(f"✅ {len([n for n in news_with_content if n['content']])}개의 기사 본문을 추출했습니다.")
                except Exception as e:
                    logger.error(f"기사 본문 추출 단계 오류: {e}", exc_info=True)
                    st.error(f"❌ 기사 본문 추출 중 오류가 발생했습니다: {str(e)}")
                    return
            
                # 3단계: AI 요약 및 키워드 생성
                st.subheader("🤖 3단계: AI 요약 및 키워드 생성")
                try:
                    results = []
                    progress_bar = st.progress(0)
                    status_text = st.empty()
                    
                    for idx, news in enumerate(news_with_content):
                        try:
                            status_text.text(f"AI 처리 중: {news['title'][:50]}... ({idx+1}/{len(news_with_content)})")
                            
                            content = news.get('content')
                            if content:
                                # 3줄 요약
                                summary = summarize_with_ai_3lines(content)
                                # 키워드 5개 추출
                                keywords = extract_keywords_5(content)
                            else:
                                summary = "본문을 추출할 수 없습니다."
                                keywords = "키워드 추출 불가"
                            
                            results.append({
                                **news,
                                'summary': summary,
                                'keywords': keywords
                            })
                            
                            progress_bar.progress((idx + 1) / len(news_with_content))
                        except Exception as e:
                            logger.error(f"AI 처리 중 오류 ({news.get('title', 'unknown')}): {e}", exc_info=True)
                            # 오류가 발생해도 계속 진행
                            results.append({
                                **news,
                                'summary': f"요약 중 오류: {str(e)[:50]}",
                                'keywords': "키워드 추출 불가"
                            })
                            progress_bar.progress((idx + 1) / len(news_with_content))
                    
                    status_text.empty()
                    progress_bar.empty()
                    st.success(f"✅ {len(results)}개의 기사를 처리했습니다.")
                    
                    # 데이터 저장
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = f"news_{keyword}_{timestamp}.json"
                    save_data(results, filename)
                    st.info(f"💾 데이터가 저장되었습니다: {filename}")
                except Exception as e:
                    logger.error(f"AI 요약 및 키워드 생성 단계 오류: {e}", exc_info=True)
                    st.error(f"❌ AI 요약 및 키워드 생성 중 오류가 발생했습니다: {str(e)}")
                    return
        except Exception as e:
            logger.error(f"전체 프로세스 중 예상치 못한 오류: {e}", exc_info=True)
            st.error(f"❌ 처리 중 예상치 못한 오류가 발생했습니다: {str(e)}")
            return
        
        # 4단계: 결과를 데이터프레임으로 화면에 출력
        st.subheader("📊 4단계: 결과 출력")
        
        # 데이터프레임 생성
        df_data = []
        for r in results:
            df_data.append({
                '제목': r['title'],
                '언론사': r.get('press', '언론사 없음'),
                '날짜': r.get('date', '날짜 없음'),
                '요약 (3줄)': r.get('summary', '요약 없음'),
                '핵심 키워드 (5개)': r.get('keywords', '키워드 없음'),
                '링크': r['link']
            })
        
        df = pd.DataFrame(df_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        # 상세 보기
        st.subheader("📄 상세 보기")
        for idx, result in enumerate(results):
            with st.expander(f"{idx+1}. {result['title']}"):
                st.write(f"**언론사:** {result.get('press', '언론사 없음')}")
                st.write(f"**날짜:** {result.get('date', '날짜 없음')}")
                st.write(f"**링크:** {result['link']}")
                st.write(f"**요약 (3줄):**")
                st.write(result.get('summary', '요약 없음'))
                st.write(f"**핵심 키워드 (5개):** {result.get('keywords', '키워드 없음')}")
                if result.get('content'):
                    st.write(f"**본문 미리보기:** {result['content'][:500]}...")


def real_estate_summary():
    """부동산 이슈 키워드 요약 페이지"""
    st.header("🏠 부동산 이슈 키워드 요약")
    
    # 키워드 버튼 제공
    st.subheader("📌 키워드 선택")
    predefined_keywords = ['금리', '전세', '분양', '재건축', '청약', '대출', '규제']
    
    # 버튼으로 키워드 선택
    selected_keyword = None
    cols = st.columns(7)
    for idx, keyword in enumerate(predefined_keywords):
        with cols[idx]:
            if st.button(keyword, key=f"keyword_btn_{keyword}"):
                selected_keyword = keyword
                st.session_state.real_estate_keyword = keyword
    
    # 또는 직접 입력
    st.subheader("✏️ 또는 직접 키워드 입력")
    custom_keyword = st.text_input("키워드 입력", placeholder="예: 아파트, 부동산 정책 등", key="custom_keyword")
    
    # 선택된 키워드 표시
    final_keyword = None
    if 'real_estate_keyword' in st.session_state:
        final_keyword = st.session_state.real_estate_keyword
    elif custom_keyword:
        final_keyword = custom_keyword
    
    if final_keyword:
        st.info(f"선택된 키워드: **{final_keyword}**")
    
    # 설정
    col1, col2 = st.columns(2)
    with col1:
        max_results = st.number_input("기사당 최대 결과 수", min_value=1, max_value=20, value=5, key="re_max")
    with col2:
        articles_per_keyword = st.number_input("키워드당 기사 수", min_value=1, max_value=10, value=3, key="re_per_keyword")
    
    if st.button("부동산 뉴스 수집 및 요약", type="primary"):
        if not final_keyword:
            st.error("키워드를 선택하거나 입력해주세요.")
            return
        
        # 단계별 진행 상황 표시
        step_container = st.container()
        
        with step_container:
            # 1단계: 뉴스 목록 수집
            st.subheader("📰 1단계: 뉴스 목록 수집")
            with st.spinner(f"'{final_keyword}' 키워드로 뉴스를 검색 중입니다..."):
                scraper = NewsScraper()
                news_list = scraper.search_news(final_keyword, max_results=max_results)
                
                if not news_list:
                    st.warning("검색 결과가 없습니다.")
                    return
                
                st.success(f"✅ {len(news_list)}개의 뉴스 기사를 찾았습니다.")
            
            # 2단계: 기사 본문 추출
            st.subheader("📄 2단계: 기사 본문 추출")
            extractor = ArticleExtractor()
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            news_with_content = []
            for idx, news in enumerate(news_list):
                status_text.text(f"본문 추출 중: {news['title'][:50]}... ({idx+1}/{len(news_list)})")
                content = extractor.extract_content(news['link'])
                news_with_content.append({
                    **news,
                    'content': content,
                    'keyword': final_keyword
                })
                progress_bar.progress((idx + 1) / len(news_list))
            
            status_text.empty()
            progress_bar.empty()
            st.success(f"✅ {len([n for n in news_with_content if n['content']])}개의 기사 본문을 추출했습니다.")
            
            # 3단계: AI 요약 및 키워드 생성
            st.subheader("🤖 3단계: AI 요약 및 키워드 생성")
            results = []
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            for idx, news in enumerate(news_with_content):
                status_text.text(f"AI 처리 중: {news['title'][:50]}... ({idx+1}/{len(news_with_content)})")
                
                content = news.get('content')
                if content:
                    # 3줄 요약
                    summary = summarize_with_ai_3lines(content)
                    # 키워드 5개 추출
                    keywords = extract_keywords_5(content)
                else:
                    summary = "본문을 추출할 수 없습니다."
                    keywords = "키워드 추출 불가"
                
                results.append({
                    **news,
                    'summary': summary,
                    'keywords': keywords
                })
                
                progress_bar.progress((idx + 1) / len(news_with_content))
            
            status_text.empty()
            progress_bar.empty()
            st.success(f"✅ {len(results)}개의 기사를 처리했습니다.")
            
            # results를 세션 상태에 저장 (종합 리포트 생성 버튼에서 사용하기 위해)
            st.session_state.real_estate_results = results
            st.session_state.real_estate_keyword_final = final_keyword
            
            # 4단계: 전체 이슈 요약 (5줄)
            st.subheader("📊 4단계: 전체 이슈 요약 생성")
            with st.spinner("모든 기사를 종합하여 전체 이슈를 요약 중입니다..."):
                overall_summary = summarize_all_articles_5lines(results)
            
            st.success("✅ 전체 이슈 요약이 생성되었습니다.")
            
            # 전체 요약 표시
            st.subheader("📋 전체 이슈 요약 (5줄)")
            st.info(overall_summary)
            
            # CSV 저장
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            csv_filename = f"real_estate_{final_keyword}_{timestamp}.csv"
            csv_filepath = os.path.join('data', csv_filename)
            
            # CSV 데이터 준비
            csv_data = []
            for r in results:
                csv_data.append({
                    '키워드': r.get('keyword', final_keyword),
                    '제목': r['title'],
                    '언론사': r.get('press', '언론사 없음'),
                    '날짜': r.get('date', '날짜 없음'),
                    '요약_3줄': r.get('summary', '요약 없음').replace('\n', ' | '),
                    '핵심_키워드_5개': r.get('keywords', '키워드 없음'),
                    '링크': r['link'],
                    '수집_시간': r.get('scraped_at', '')
                })
            
            df = pd.DataFrame(csv_data)
            df.to_csv(csv_filepath, index=False, encoding='utf-8-sig')
            st.info(f"💾 CSV 파일이 저장되었습니다: {csv_filename}")
            
            # CSV 다운로드 버튼
            with open(csv_filepath, 'rb') as f:
                csv_data_bytes = f.read()
            
            st.download_button(
                label="📥 CSV 파일 다운로드",
                data=csv_data_bytes,
                file_name=csv_filename,
                mime="text/csv",
                key="download_csv"
            )
            
            # 결과 테이블
            st.subheader("📊 수집 결과")
            st.dataframe(df, use_container_width=True, hide_index=True)
            
            # 상세 보기
            st.subheader("📄 상세 보기")
            for idx, result in enumerate(results):
                with st.expander(f"{idx+1}. {result['title']}"):
                    st.write(f"**키워드:** {result.get('keyword', final_keyword)}")
                    st.write(f"**언론사:** {result.get('press', '언론사 없음')}")
                    st.write(f"**날짜:** {result.get('date', '날짜 없음')}")
                    st.write(f"**링크:** {result['link']}")
                    st.write(f"**요약 (3줄):**")
                    st.write(result.get('summary', '요약 없음'))
                    st.write(f"**핵심 키워드 (5개):** {result.get('keywords', '키워드 없음')}")
                    if result.get('content'):
                        st.write(f"**본문 미리보기:** {result['content'][:500]}...")
            
            # 차트 섹션 추가
            if len(results) > 0:
                st.subheader("📈 데이터 분석 차트")
                
                # 키워드 빈도수 바 차트
                all_keywords = []
                for result in results:
                    keywords_str = result.get('keywords', '')
                    if keywords_str and keywords_str != '키워드 추출 불가':
                        keywords_list = [k.strip() for k in keywords_str.split(',') if k.strip()]
                        all_keywords.extend(keywords_list)
                
                if all_keywords:
                    keyword_counter = Counter(all_keywords)
                    keyword_df = pd.DataFrame({
                        '키워드': list(keyword_counter.keys()),
                        '빈도수': list(keyword_counter.values())
                    }).sort_values('빈도수', ascending=False).head(10)
                    
                    fig_keywords = px.bar(
                        keyword_df, 
                        x='빈도수', 
                        y='키워드',
                        orientation='h',
                        title='키워드 빈도수 TOP 10',
                        labels={'빈도수': '빈도수', '키워드': '키워드'}
                    )
                    fig_keywords.update_layout(height=400)
                    st.plotly_chart(fig_keywords, use_container_width=True)
                
                # 언론사별 기사 수 바 차트
                press_list = [r.get('press', '언론사 없음') for r in results]
                press_counter = Counter(press_list)
                press_df = pd.DataFrame({
                    '언론사': list(press_counter.keys()),
                    '기사 수': list(press_counter.values())
                }).sort_values('기사 수', ascending=False)
                
                fig_press = px.bar(
                    press_df,
                    x='언론사',
                    y='기사 수',
                    title='언론사별 기사 수',
                    labels={'언론사': '언론사', '기사 수': '기사 수'}
                )
                fig_press.update_layout(height=400)
                st.plotly_chart(fig_press, use_container_width=True)
                
                # 날짜별 기사 수 추이 라인 차트
                date_list = []
                for r in results:
                    date_str = r.get('date', '날짜 없음')
                    # 날짜 파싱 시도
                    if date_str != '날짜 없음':
                        # "2024.01.20" 형식 또는 "1시간 전" 형식 처리
                        if '.' in date_str and len(date_str.split('.')) == 3:
                            try:
                                date_parts = date_str.split('.')
                                if len(date_parts) == 3:
                                    date_list.append(f"{date_parts[0]}-{date_parts[1]}-{date_parts[2]}")
                            except:
                                pass
                
                if date_list:
                    date_counter = Counter(date_list)
                    date_df = pd.DataFrame({
                        '날짜': list(date_counter.keys()),
                        '기사 수': list(date_counter.values())
                    })
                    date_df = date_df.sort_values('날짜')
                    
                    fig_date = px.line(
                        date_df,
                        x='날짜',
                        y='기사 수',
                        title='날짜별 기사 수 추이',
                        labels={'날짜': '날짜', '기사 수': '기사 수'},
                        markers=True
                    )
                    fig_date.update_layout(height=400)
                    st.plotly_chart(fig_date, use_container_width=True)
                else:
                    st.info("날짜 정보가 충분하지 않아 날짜별 추이 차트를 생성할 수 없습니다.")
    
    # 종합 리포트 생성 버튼 (메인 블록 밖으로 이동)
    if 'real_estate_results' in st.session_state and len(st.session_state.real_estate_results) > 0:
        st.subheader("📋 종합 리포트 생성")
        if st.button("종합 리포트 생성", type="primary", key="generate_report"):
            results = st.session_state.real_estate_results
            final_keyword = st.session_state.get('real_estate_keyword_final', '')
            
            with st.spinner("종합 리포트를 생성 중입니다..."):
                try:
                    report = generate_comprehensive_report(results, final_keyword)
                    
                    # 리포트 표시
                    st.success("✅ 종합 리포트가 생성되었습니다.")
                    
                    st.subheader("📄 전체 요약 문단")
                    st.write(report['overall_summary'])
                    
                    st.subheader("🔑 핵심 포인트 5개")
                    for idx, point in enumerate(report['key_points'], 1):
                        st.write(f"{idx}. {point}")
                    
                    st.subheader("🏷️ 주요 키워드 TOP 10")
                    if report['top_keywords']:
                        keyword_df_report = pd.DataFrame(report['top_keywords'])
                        st.dataframe(keyword_df_report, use_container_width=True, hide_index=True)
                    else:
                        st.info("키워드 정보가 없습니다.")
                    
                    # 리포트를 텍스트 파일로 저장
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    report_filename = f"report_{final_keyword}_{timestamp}.txt"
                    report_filepath = os.path.join('data', report_filename)
                    
                    report_text = f"""
{'='*80}
부동산 이슈 종합 리포트
{'='*80}

키워드: {final_keyword}
생성 일시: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
수집 기사 수: {len(results)}개

{'='*80}
전체 요약 문단
{'='*80}

{report['overall_summary']}

{'='*80}
핵심 포인트 5개
{'='*80}

"""
                    for idx, point in enumerate(report['key_points'], 1):
                        report_text += f"{idx}. {point}\n"
                    
                    report_text += f"""
{'='*80}
주요 키워드 TOP 10
{'='*80}

"""
                    for idx, kw_data in enumerate(report['top_keywords'], 1):
                        report_text += f"{idx}. {kw_data['keyword']} (빈도: {kw_data['count']})\n"
                    
                    report_text += f"""
{'='*80}
기사 목록
{'='*80}

"""
                    for idx, result in enumerate(results, 1):
                        report_text += f"\n[{idx}] {result['title']}\n"
                        report_text += f"언론사: {result.get('press', '언론사 없음')}\n"
                        report_text += f"날짜: {result.get('date', '날짜 없음')}\n"
                        report_text += f"요약: {result.get('summary', '요약 없음')}\n"
                        report_text += f"링크: {result['link']}\n"
                        report_text += "-" * 80 + "\n"
                    
                    # 파일 저장
                    with open(report_filepath, 'w', encoding='utf-8') as f:
                        f.write(report_text)
                    
                    st.info(f"💾 리포트가 저장되었습니다: {report_filename}")
                    
                    # 리포트 다운로드 버튼
                    with open(report_filepath, 'rb') as f:
                        report_data_bytes = f.read()
                    
                    st.download_button(
                        label="📥 리포트 다운로드 (TXT)",
                        data=report_data_bytes,
                        file_name=report_filename,
                        mime="text/plain",
                        key="download_report"
                    )
                except Exception as e:
                    logger.error(f"종합 리포트 생성 중 오류: {e}", exc_info=True)
                    st.error(f"❌ 종합 리포트 생성 중 오류가 발생했습니다: {str(e)}")


def download_data():
    """저장된 데이터 다운로드 페이지"""
    st.header("💾 저장된 데이터 다운로드")
    
    # data 디렉토리의 파일 목록 가져오기
    data_files = [f for f in os.listdir('data') if f.endswith('.json')]
    
    if not data_files:
        st.info("저장된 데이터가 없습니다.")
        return
    
    st.write(f"총 {len(data_files)}개의 파일이 저장되어 있습니다.")
    
    # 파일 선택
    selected_file = st.selectbox("다운로드할 파일 선택", data_files)
    
    if selected_file:
        filepath = os.path.join('data', selected_file)
        
        # 파일 정보 표시
        file_size = os.path.getsize(filepath)
        file_time = datetime.fromtimestamp(os.path.getmtime(filepath))
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("파일 크기", f"{file_size / 1024:.2f} KB")
        with col2:
            st.metric("수정 시간", file_time.strftime('%Y-%m-%d %H:%M:%S'))
        
        # 데이터 미리보기
        data = load_data(selected_file)
        st.subheader("데이터 미리보기")
        st.json(data[:3] if len(data) > 3 else data)  # 처음 3개만 미리보기
        
        # 다운로드 버튼
        with open(filepath, 'r', encoding='utf-8') as f:
            file_content = f.read()
        
        st.download_button(
            label="📥 파일 다운로드",
            data=file_content,
            file_name=selected_file,
            mime="application/json"
        )
        
        # 데이터프레임으로 보기
        if st.checkbox("데이터프레임으로 보기"):
            df = pd.DataFrame(data)
            st.dataframe(df, use_container_width=True)


def main():
    """메인 함수"""
    st.title("📰 뉴스 & 부동산 이슈 요약 대시보드")
    st.markdown("---")
    
    # 사이드바 메뉴
    st.sidebar.title("📋 메뉴")
    menu = st.sidebar.radio(
        "선택하세요",
        ["뉴스 검색 요약", "부동산 이슈 키워드 요약", "저장된 데이터 다운로드"]
    )
    
    # 메뉴에 따라 페이지 표시
    if menu == "뉴스 검색 요약":
        news_search_summary()
    elif menu == "부동산 이슈 키워드 요약":
        real_estate_summary()
    elif menu == "저장된 데이터 다운로드":
        download_data()
    
    # 사이드바 정보
    st.sidebar.markdown("---")
    st.sidebar.info("💡 **사용 방법**\n\n1. 뉴스 검색 요약: 키워드로 뉴스를 검색하고 AI로 요약합니다.\n2. 부동산 이슈 요약: 부동산 관련 뉴스를 자동으로 수집하고 요약합니다.\n3. 데이터 다운로드: 저장된 데이터를 확인하고 다운로드합니다.")


if __name__ == "__main__":
    main()
